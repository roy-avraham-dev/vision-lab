"""Apply hand-verified reorderings. Every fix must use exactly the same characters
as the text it replaces (only order may change), so no word is added or lost."""
import json, sys, collections
tag = sys.argv[1]
doc = json.load(open(f'out/{tag}.json'))
fixes = json.load(open(f'fixes_{tag}.json'))
MIR = str.maketrans(')]}>', '([{<')
norm = lambda s: collections.Counter(c for c in s.translate(MIR) if c not in ' *\n')  # mirrored brackets are one glyph pair
used = [0] * len(fixes)
def fix(t):
    if not t: return t
    for k, fx in enumerate(fixes):
        a, b = fx[0], fx[1]
        if a in t:
            assert norm(a) == norm(b), ('characters differ', a, b, norm(a) - norm(b), norm(b) - norm(a))
            t = t.replace(a, b); used[k] += 1
            if len(fx) > 2: EXTRA.append((b, fx[2]))
    return t
EXTRA = []
for blk in doc['blocks']:
    if 'text' in blk and blk['type'] != 'code': blk['text'] = fix(blk['text'])
    if blk['type'] == 'table':
        for r in blk['rows']:
            for c in r:
                for s in c:
                    if s['type'] in ('p', 'code'): s['text'] = fix(s['text'])
for blk in doc['blocks']:
    for b, attrs in EXTRA:
        if blk.get('text') == b: blk.update(attrs)
missing = [fixes[k][0] for k, u in enumerate(used) if not u]
assert not missing, ('unused fixes', missing)
json.dump(doc, open(f'out/{tag}.fixed.json', 'w'), ensure_ascii=False, indent=1)
print(tag, 'applied', sum(used), 'fixes')

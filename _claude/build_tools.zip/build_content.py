"""Turn the verified block list into the site's content structure:
module -> chapters -> sections (steps) + exercises with their matched solutions.
Every block keeps its original text; nothing is rewritten here."""
import json, re, sys, os, io, contextlib, signal, base64, traceback

tag = sys.argv[1]
src = json.load(open(f'out/{tag}.fixed.json'))
B = src['blocks']
# a sentence that the PDF wrapped right before a number like "0." was read as a numbered list item: glue it back
_m = []
for b in B:
    if _m and b['type'] == 'li' and _m[-1]['type'] == 'p' and _m[-1].get('text', '').rstrip().endswith(',') and re.match(r'^\d+\. ', b.get('text', '')):
        _m[-1] = dict(_m[-1], text=_m[-1]['text'].rstrip() + ' ' + b['text']); print('merged wrapped line:', b['text'][:40]); continue
    _m.append(b)
B = _m
# a code block that the PDF split across two pages (the second part starts indented) is one block
_m = []
for b in B:
    if _m and b['type'] == 'code' and _m[-1]['type'] == 'code' and b['text'][:1].isspace():
        _m[-1] = dict(_m[-1], text=_m[-1]['text'] + '\n' + b['text']); print('joined code split across pages'); continue
    _m.append(b)
B = _m

LATEX = re.compile(r'\\(begin|frac|mathbf|sqrt|sum|cdot|det|text|left|right|partial|sigma|log|nabla|exp|mu|theta|lambda|min|lim|qquad|quad|bigl|bigr|lfloor|Sigma|eta|gamma|dots)\b|\\\||\\,')

def classify_code(t):
    if LATEX.search(t): return 'tex'
    first = t.strip().split('\n')[0]
    if re.match(r'^(pip|jupyter|python)\b', first): return 'shell'
    if re.search(r'#include|std::|\bstruct \w+ \{|nvinfer1::|^public:|\bexplicit ', t): return 'cpp'
    if re.match(r'^(g\+\+|trtexec|nvcc|nsys|gst-launch|/usr/)', first) or first.startswith('./'): return 'shell'
    if re.search(r'System\.out|;\s*$|\bint \w+ =|\bfor \(int', t) and 'np.' not in t: return 'java'
    return 'python'

def depth(line):
    d = 0; q = None; i = 0
    while i < len(line):
        c = line[i]
        if q:
            if c == '\\': i += 1
            elif c == q: q = None
        elif c in '\'"': q = c
        elif c == '#': break
        elif c in '([{': d += 1
        elif c in ')]}': d -= 1
        i += 1
    return d, q
def rejoin(t):
    # a line that the PDF wrapped (inside open brackets or an open string) and that lost its indentation is glued back
    out = []
    bal = 0
    for line in t.split('\n'):
        if out and line and not line[0].isspace() and (bal > 0 or depth(out[-1])[1]):
            out[-1] = out[-1] + ' ' + line
        else:
            out.append(line)
        bal = sum(depth(l)[0] for l in out) if out else 0
    return '\n'.join(out)
def heal(t, bid):
    # m3: a wrapped comment's tail landed on its own line, a statement wrapped right after '=', or two statements were glued
    for _ in range(12):
        try: compile(t, 'x', 'exec'); return t
        except SyntaxError as e: ln = (e.lineno or 1) - 1
        L = t.split('\n')
        if ln > 0 and '#' in L[ln - 1] and not L[ln].startswith((' ', '\t')) and depth(L[ln - 1])[0] == 0:
            L[ln - 1] = L[ln - 1] + ' ' + L[ln].strip(); del L[ln]
        elif L[ln].rstrip().endswith(('=', ' -', ' +', ' *', ' /')) and ln + 1 < len(L):
            L[ln] = L[ln].rstrip() + ' ' + L[ln + 1].strip(); del L[ln + 1]
        elif ln > 0 and L[ln - 1].rstrip().endswith('='):
            L[ln - 1] = L[ln - 1].rstrip() + ' ' + L[ln].strip(); del L[ln]
        elif re.search(r'[)\]] [A-Za-z_][\w, ]* = ', L[ln]):
            m = re.search(r'[)\]] ([A-Za-z_][\w, ]* = )', L[ln]); ind = re.match(r'\s*', L[ln]).group(0)
            L[ln:ln + 1] = [L[ln][:m.start(1) - 1], ind + L[ln][m.start(1):]]
        else:
            print('heal: cannot fix', bid, ln + 1, L[ln][:80]); return t
        print('healed', bid, 'line', ln + 1); t = '\n'.join(L)
    return t
CODEFIX = json.load(open(f'codefix_{tag}.json')) if os.path.exists(f'codefix_{tag}.json') else []
SPLITS = [') res = get_sliced_prediction(', ') red_mask = ', ') print("otsu threshold:"', ') adapt = cv2.adaptiveThreshold(']
for k, b in enumerate(B):
    b['id'] = f'{tag}-b{k}'
    if b['type'] == 'code':
        b['lang'] = classify_code(b['text'])
        for a_, b_ in CODEFIX:
            if a_ in b['text']: b['text'] = b['text'].replace(a_, b_)
        if b['lang'] == 'python':
            t = rejoin(b['text'])
            for sp in SPLITS: t = t.replace(sp, ')\n' + sp[2:])
            if tag in ('m3', 'm4', 'm5', 'm6', 'm7'): t = heal(t, b['id'])
            try: compile(t, 'x', 'exec')
            except SyntaxError:
                if not re.search(r'\bimport\b|\bdef\b| = ', t): b['lang'] = 'text'
            b['text'] = t

def text(b): return b.get('text', '')

module = {'id': tag, 'title': '', 'meta': src.get('meta'), 'intro': [], 'chapters': [], 'solutions_intro': []}
i = 0
n = len(B)
if B[0]['type'] == 'h1':
    module['title'] = B[0]['text']; i = 1
    if ':' not in module['title'] and len(B) > 1 and B[1]['type'] == 'h2': module['title'] += ': ' + B[1]['text']  # subtitle on its own line; the h2 also stays in the intro

# split at h2
h2s = [k for k in range(n) if B[k]['type'] == 'h2']
def blocks(a, b): return B[a:b]
sol_h2 = next((k for k in h2s if 'פתרונות' in B[k]['text']), None)

chap_h2 = [k for k in h2s if re.match(r'^פרק \d+', B[k]['text'])]
first_chap = chap_h2[0]
module['intro'] = blocks(i, first_chap)

def ends(k, lst, default):
    later = [x for x in lst if x > k]
    return later[0] if later else default

for ck in chap_h2:
    ce = ends(ck, h2s, n)
    m = re.match(r'^פרק (\d+): (.*)$', B[ck]['text'])
    ch = {'n': int(m.group(1)), 'title': m.group(2), 'heading': B[ck], 'lead': [], 'sections': [], 'exercises': [], 'exercise_heading': None}
    h3s = [k for k in range(ck + 1, ce) if B[k]['type'] == 'h3']
    ch['lead'] = blocks(ck + 1, h3s[0] if h3s else ce)
    for sk in h3s:
        se = ends(sk, h3s, ce)
        title = B[sk]['text']
        if title.startswith('תרגילים לפרק') or title == 'תרגילים':
            ch['exercise_heading'] = B[sk]
            cur = None
            for b in blocks(sk + 1, se):
                mm = re.match(r'^\*\*(?:תרגיל )?(\d+\.\d+)( ?★+)?(?: \([^)]*\))?:?\*\*', text(b)) if b['type'] == 'p' else None
                if mm:
                    cur = {'id': mm.group(1), 'star': bool(mm.group(2)), 'blocks': [b], 'solution': []}
                    ch['exercises'].append(cur)
                elif cur:
                    cur['blocks'].append(b)
            continue
        mm = re.match(r'^(\d+\.\d+) (.*)$', title)
        ch['sections'].append({'id': mm.group(1), 'title': mm.group(2), 'heading': B[sk], 'blocks': blocks(sk + 1, se)})
    module['chapters'].append(ch)

# solutions
if sol_h2 is not None:
    h3s = [k for k in range(sol_h2 + 1, n) if B[k]['type'] == 'h3']
    module['solutions_heading'] = B[sol_h2]
    module['solutions_intro'] = blocks(sol_h2 + 1, h3s[0] if h3s else n)
    ex_by_id = {e['id']: e for c in module['chapters'] for e in c['exercises']}
    module['solution_chapter_headings'] = {}
    for sk in h3s:
        se = ends(sk, h3s, n)
        module['solution_chapter_headings'][B[sk]['text']] = B[sk]
        cur = None
        for b in blocks(sk + 1, se):
            mm2 = re.match(r'^\*\*(\d+\.\d+) ו־(\d+\.\d+):\*\*', text(b))
            if mm2 and mm2.group(1) in ex_by_id and mm2.group(2) in ex_by_id:
                cur = ex_by_id[mm2.group(1)]; cur['solution'].append(b); ex_by_id[mm2.group(2)]['solution_of'] = mm2.group(1); continue
            mm = re.match(r'^\*\*(\d+\.\d+)( ?★+)?(?: \([^)]*\))?:?\*\*', text(b))
            if mm and mm.group(1) in ex_by_id:
                cur = ex_by_id[mm.group(1)]; cur['solution'].append(b)
            elif cur:
                cur['solution'].append(b)
    missing = [e for e in ex_by_id.values() if not e['solution'] and not e.get('solution_of')]
    print('exercises:', len(ex_by_id), 'without solution:', [e['id'] for e in missing])

# accounting: every block must be placed exactly once
placed = []
def walk(x):
    if isinstance(x, dict):
        if 'id' in x and 'type' in x and x['id'].startswith(tag + '-b'): placed.append(x['id']); return
        for v in x.values(): walk(v)
    elif isinstance(x, list):
        for v in x: walk(v)
walk(module)
all_ids = [b['id'] for b in B]
dup = len(placed) - len(set(placed))
missing = set(all_ids) - set(placed) - {B[0]['id']}
print('blocks:', len(all_ids), 'placed:', len(set(placed)), 'duplicates:', dup, 'unplaced:', sorted(missing)[:10])
assert dup == 0 and not missing

# ---- precompute outputs of the Python code, chapter by chapter, in one session each ----
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

class TO(Exception): pass
def handler(s, f): raise TO()
signal.signal(signal.SIGALRM, handler)

import cv2
SHOWN = {}
def _imshow(name, im):
    SHOWN[name] = im.copy()
cv2.imshow = _imshow
_imwrite = cv2.imwrite
def _imwrite2(path, im, *a):
    SHOWN[path] = np.asarray(im).copy(); return _imwrite(path, im, *a)
cv2.imwrite = _imwrite2
cv2.waitKey = lambda *a, **k: -1
cv2.destroyAllWindows = lambda *a, **k: None
cv2.namedWindow = lambda *a, **k: None
cv2.setMouseCallback = lambda *a, **k: None
cv2.createTrackbar = lambda *a, **k: None
cv2.getTrackbarPos = lambda *a, **k: 0
RUNDIR = f'/tmp/run_{tag}'
os.makedirs(RUNDIR, exist_ok=True)
HERE = os.getcwd()
def shown_pngs():
    out = []
    for name, im in list(SHOWN.items())[:3]:
        im = np.asarray(im)
        if im.dtype != np.uint8: im = np.clip(im, 0, 255).astype(np.uint8)
        h, w = im.shape[:2]
        if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
        ok, buf = cv2.imencode('.png', im)
        if ok: out.append('data:image/png;base64,' + base64.b64encode(buf.tobytes()).decode())
    return out

SHARED_ENV = {'__name__': '__main__'}
def run_chapter(ch):
    env = SHARED_ENV if tag in ('m2', 'm4', 'm5', 'm6', 'm7') else {'__name__': '__main__'}
    os.chdir(RUNDIR)
    sys.path.insert(0, RUNDIR)
    setup = "import numpy as np\nimport cv2\nimport matplotlib\nimport matplotlib.pyplot as plt\nnp.random.seed(0)\nimg = (np.random.rand(480, 640, 3) * 255).astype(np.uint8)\ngray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)\n"
    if not env.get('_setup_done'): exec(setup, env); env['_setup_done'] = True
    codes = []
    for s in ch['sections']:
        for b in s['blocks']:
            if b['type'] == 'code' and b['lang'] == 'python': codes.append(b)
    for e in ch['exercises']:
        for b in e['blocks'] + e['solution']:
            if b['type'] == 'code' and b['lang'] == 'python': codes.append(b)
    ok = 0
    for b in codes:
        buf = io.StringIO()
        plt.close('all'); SHOWN.clear()
        try:
            signal.alarm(60)
            with contextlib.redirect_stdout(buf):
                exec(compile(b['text'], b['id'], 'exec'), env)
            signal.alarm(0)
            out = {'stdout': buf.getvalue()[:4000]}
            figs = []
            for num in plt.get_fignums():
                f = plt.figure(num); bio = io.BytesIO(); f.savefig(bio, format='png', dpi=80, bbox_inches='tight')
                figs.append('data:image/png;base64,' + base64.b64encode(bio.getvalue()).decode())
            figs = shown_pngs() + figs
            if figs: out['figs'] = figs[:3]
            b['output'] = out; ok += 1
        except TO:
            b['output'] = {'error': 'זמן הריצה ארוך מדי לתצוגה מוקדמת'}
        except Exception as ex:
            signal.alarm(0)
            b['output_error'] = f'{type(ex).__name__}: {ex}'
    os.chdir(HERE)
    return ok, len(codes)

plt.show = lambda *a, **k: None
# helper modules that the text asks the reader to save as files (scene.py from a solution, stab.py from chapter 11)
def code_of(blocks): return [b['text'] for b in blocks if b['type'] == 'code' and b.get('lang') == 'python']
for ch in module['chapters']:
    for e in ch['exercises']:
        for t in code_of(e['solution']):
            if 'def make_scene' in t: open(os.path.join(RUNDIR, 'scene.py'), 'w').write(t)
    if tag == 'm1' and ch['n'] == 11:
        parts = ['import cv2', 'import numpy as np']
        for sec in ch['sections']:
            if sec['id'] in ('11.3', '11.4'): parts += [t for t in code_of(sec['blocks']) if 'def ' in t]
        open(os.path.join(RUNDIR, 'stab.py'), 'w').write('\n\n'.join(parts))
if tag == 'm3':
    allcode = [b['text'] for ch in module['chapters'] for sec in ch['sections'] for b in sec['blocks'] if b['type'] == 'code' and b.get('lang') == 'python']
    for fname, key in [('geom.py', 'def look_at('), ('homography.py', 'def homography_dlt('), ('ground.py', 'def pixel_to_ground(')]:
        t = next(t for t in allcode if key in t)
        open(os.path.join(RUNDIR, fname), 'w').write(t); print('helper', fname)
if tag == 'm6':
    allcode = [b['text'] for ch in module['chapters'] for sec in ch['sections'] for b in sec['blocks'] if b['type'] == 'code' and b.get('lang') == 'python']
    for fname, key in [('onnx_mini.py', '# onnx_mini.py'), ('quant.py', '# quant.py')]:
        open(os.path.join(RUNDIR, fname), 'w').write(next(t for t in allcode if t.startswith(key))); print('helper', fname)
    import shutil, subprocess
    shutil.copy('/tmp/m6helpers/mlp.py', RUNDIR)
    print(subprocess.run(['python3', '/tmp/m6helpers/make.py', RUNDIR], capture_output=True, text=True).stdout.strip())
tot_ok = tot = 0
for ch in module['chapters']:
    a, c = run_chapter(ch); tot_ok += a; tot += c
print(f'python blocks precomputed: {tot_ok}/{tot}')

os.makedirs('site/content', exist_ok=True)
with open(f'site/content/{tag}.js', 'w') as f:
    f.write('window.CONTENT = window.CONTENT || {};\n')
    f.write(f'window.CONTENT[{json.dumps(tag)}] = ')
    json.dump(module, f, ensure_ascii=False)
    f.write(';\n')
print('written', os.path.getsize(f'site/content/{tag}.js'), 'bytes')

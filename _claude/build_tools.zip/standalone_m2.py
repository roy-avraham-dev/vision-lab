# Stand-alone additions for the code examples of module 2: writes site/content/m2_codefull.js,
# verifies every full script in a fresh process and an empty folder, and refreshes the precomputed outputs in m2.js.
import json, os, subprocess, sys, tempfile, base64, textwrap
PIP = 'אם PyCharm מסמן את `cv2` או את `numpy` באדום, הרץ פעם אחת בטרמינל שלו: `pip install opencv-python numpy`.'
IMP = {'code': 'import cv2\nimport numpy as np\n', 'say': 'שתי הספריות שהקוד משתמש בהן. ' + PIP}
def show(*names, extra=''):
    return {'code': extra + ''.join(f'cv2.imshow("{n}", {n})\n' for n in names) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()',
            'say': 'מציג את התוצאה: ' + ('חלון אחד' if len(names) == 1 else f'{len(names)} חלונות') + ' (' + ', '.join(f'`{n}`' for n in names) + '). לחיצה על מקש כלשהו, כשאחד החלונות בפוקוס, סוגרת אותם.'}
PAPER = 'gray = np.full((300, 400), 200, np.uint8)                                  # נייר בהיר\ncv2.putText(gray, "CV", (60, 200), cv2.FONT_HERSHEY_SIMPLEX, 5, 50, 20)    # טקסט כהה\n'
F = {
}

p = 'site/content/m2.js'; s = open(p, encoding='utf8').read(); k = s.index('= {', 40) + 2
d = json.loads(s[k:].rstrip().rstrip(';'))
blocks = {}
for ch in d['chapters']:
    for sec in ch['sections']:
        for b in sec['blocks']:
            if b['type'] == 'code': blocks[b['id']] = b
    for e in ch['exercises']:
        for b in e['blocks'] + e['solution']:
            if b['type'] == 'code': blocks[b['id']] = b
# ---- fixes of typos in the course code (the fix is announced in a note right after the block) ----
FIXES = {'m2-b123': [('num_workers=2) val_dl = DataLoader', 'num_workers=2)\nval_dl = DataLoader')], 'm2-b173': [('# torch.Size([8, 64,\n7, 7])', '# torch.Size([8, 64, 7, 7])')], 'm2-b212': [('#\nLinear(in_features=512, out_features=1000, bias=True)', '# Linear(in_features=512, out_features=1000, bias=True)')], 'm2-b309': [('import LinearLR, CosineAnnealingLR,\nSequentialLR', 'import LinearLR, CosineAnnealingLR, SequentialLR'), ('milestones= [5]', 'milestones=[5]')], 'm2-b431': [("%Y%m%d- %H%M%S", "%Y%m%d-%H%M%S")], 'm2-b524': [('EarlyStopping,\nRunLogger', 'EarlyStopping, RunLogger')]}
FIXNOTE = {'m2-b524': '**(תיקון של האתר:** בקורס, שורת ה־`import` מ־`metrics` נשברה לשתי שורות אחרי הפסיק — שגיאת תחביר. כאן היא בשורה אחת. שום דבר אחר לא שונה.)', 'm2-b431': '**(תיקון של האתר:** בקורס נכנס רווח בתוך תבנית התאריך, `"%Y%m%d- %H%M%S"`, ושמות התיקיות יצאו עם רווח באמצע. כאן הרווח הוסר. שום דבר אחר לא שונה.)', 'm2-b309': '**(תיקון של האתר:** בקורס, שורת ה־`import` הראשונה נשברה לשתי שורות אחרי הפסיק, וזו שגיאת תחביר (שורה שנגמרת בפסיק בלי סוגריים). כאן היא בשורה אחת. שום דבר אחר לא שונה.)', 'm2-b212': '**(תיקון של האתר:** בקורס, ההערה בסוף השורה `print(resnet.fc)` נשברה לשתי שורות, והשורה השנייה, `Linear(in_features=512, ...)`, נקראת כקוד ונכשלת (השם `Linear` לא מוגדר). כאן ההערה בשורה אחת. שום דבר אחר לא שונה.)', 'm2-b173': '**(תיקון של האתר:** בקורס, ההערה בסוף השורה האחרונה נשברה לשתי שורות, והשורה השנייה, `7, 7])`, היא שגיאת תחביר. כאן ההערה בשורה אחת. שום דבר אחר לא שונה.)', 'm2-b123': '**(תיקון של האתר:** בקורס, שורת ה־`train_dl` ושורת ה־`val_dl` הודבקו לשורה אחת, וזו שגיאת תחביר — הקוד לא רץ. כאן הן מופרדות. שום דבר אחר לא שונה.)'}
for ch in d['chapters']:
    for sec in ch['sections']:
        for i, b in enumerate(sec['blocks']):
            if b.get('id') in FIXES:
                for a, c in FIXES[b['id']]: b['text'] = b['text'].replace(a, c)
                nxt = sec['blocks'][i + 1] if i + 1 < len(sec['blocks']) else None
                if not (nxt and nxt.get('id') == b['id'] + '-fix'):
                    sec['blocks'].insert(i + 1, {'type': 'p', 'text': FIXNOTE[b['id']], 'id': b['id'] + '-fix'})

# ---- chapter 1: each block builds on the ones before it ----
_b17 = blocks['m2-b17']['text'].strip() + '\n'
_b22 = blocks['m2-b22']['text'].strip() + '\n'
_b27 = blocks['m2-b27']['text'].strip() + '\n'
P17 = {'code': _b17, 'say': 'הנתונים, האתחול והמעבר קדימה מסעיף 1.2 (`make_spiral`, `init`, `forward`).'}
P22 = {'code': _b22, 'say': 'סופטמקס, ההפסד והגרדיאנטים מסעיף 1.3 (`softmax`, `loss_and_grads`).'}
P27 = {'code': _b27, 'say': 'בדיקת הגרדיאנטים מסעיף 1.4. היא גם יוצרת את `X`, `y` ואת הרשת `p` שהאימון ממשיך ממנה.'}
F['m2-b17'] = {'post': [{'code': 'X, y = make_spiral()\np = init(2, 64, 3)\nz1, h, scores = forward(p, X)\nprint(X.shape, y.shape, z1.shape, h.shape, scores.shape)\nprint("hidden values set to 0 by ReLU:", round(float((h == 0).mean()), 2))', 'say': 'מריץ את שלוש הפונקציות ומדפיס את הצורות: 300 נקודות, 2 קואורדינטות, 64 נוירונים נסתרים, 3 ציונים. וכמה מהערכים הנסתרים ReLU איפס — בערך חצי.'}]}
F['m2-b22'] = {'pre': [P17], 'post': [{'code': 'X, y = make_spiral()\np = init(2, 64, 3)\nloss, g = loss_and_grads(p, X, y)\nprint(round(float(loss), 3), round(float(np.log(3)), 3))     # the first loss, and ln 3\nprint({k: v.shape for k, v in g.items()})', 'say': 'מחשב את ההפסד בתחילת האימון — קרוב ל־ln 3 — ומדפיס את הצורות של ארבעת הגרדיאנטים. כל גרדיאנט באותה צורה כמו הפרמטר שלו.'}]}
F['m2-b27'] = {'pre': [P17, P22]}
F['m2-b34'] = {'pre': [P17, P22, {'code': 'X, y = make_spiral()\np = init(2, 64, 3)\n', 'say': 'הנתונים והרשת ההתחלתית. בקורס הם נוצרים בקוד של סעיף 1.4 (בדיקת הגרדיאנטים); כאן — ישירות, בלי לחכות לבדיקה.'}],
    'post': [{'code': 'import matplotlib.pyplot as plt\n\nxx, yy = np.meshgrid(np.linspace(-1.1, 1.1, 300), np.linspace(-1.1, 1.1, 300))\ngrid = np.c_[xx.ravel(), yy.ravel()]\npred = forward(p, grid)[2].argmax(axis=1).reshape(xx.shape)\nplt.contourf(xx, yy, pred, alpha=0.3, cmap="brg")\nplt.scatter(X[:, 0], X[:, 1], c=y, s=12, cmap="brg")\nplt.title("decision regions after training")\nplt.show()', 'say': 'מצייר את האזורים שהרשת המאומנת נותנת לכל מחלקה: מסווגים רשת צפופה של נקודות על כל המישור, וצובעים לפי הניבוי. אמורות להופיע שלוש ספירלות צבעוניות שעוקבות אחרי הנקודות.'}]}

# ---- chapter 2 (PyTorch: run on the user's computer) ----
TORCH = {'code': 'import torch\nimport numpy as np\n', 'say': 'הספריות. אם PyCharm מסמן את `torch` באדום — צריך להתקין אותו פעם אחת, בטרמינל של PyCharm: `pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu` (הגרסה למעבד; לכרטיס מסך של NVIDIA — לפי ההוראות באתר של PyTorch).'}
PHOTO = {'code': 'import os\nimport cv2\nimport numpy as np\n\nif not os.path.exists("photo.jpg"):          # a test photo, if you have none of your own\n    demo = np.full((240, 320, 3), (200, 160, 90), np.uint8)\n    cv2.circle(demo, (160, 120), 70, (0, 140, 255), -1)\n    cv2.imwrite("photo.jpg", demo)\n', 'say': 'הקוד קורא תמונה בשם `photo.jpg`. אם אין לך אחת בתיקייה, השורות האלה יוצרות תמונת בדיקה (עיגול כתום על רקע כחלחל). אפשר לשים במקומה כל תמונה שלך באותו שם.'}
F['m2-b50'] = {'remote': True}
F['m2-b58'] = {'remote': True, 'pre': [TORCH]}
F['m2-b64'] = {'remote': True, 'pre': [TORCH, P17, P22]}
F['m2-b73'] = {'remote': True, 'pre': [TORCH]}
F['m2-b80'] = {'remote': True, 'pre': [PHOTO, TORCH]}
F['m2-b558'] = {'remote': True, 'pre': [{'code': 'import cv2\nimport numpy as np\nimport torch\n', 'say': 'הספריות.'}], 'post': [{'code': 'img = np.full((120, 160, 3), (200, 160, 90), np.uint8)\ncv2.circle(img, (80, 60), 35, (0, 140, 255), -1)\nrgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)\nt = torch.from_numpy(rgb).permute(2, 0, 1).float() / 255.0\nt = (t - torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)) / torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)\nback = tensor_to_bgr(t)\nprint(back.shape, back.dtype, int(np.abs(back.astype(int) - img.astype(int)).max()))   # the largest difference: 0 or 1 (rounding)\ncv2.imshow("back", np.hstack([img, back]))\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'בדיקה הלוך־חזור: תמונה → טנזור מנורמל (כמו בסעיף 2.5) → חזרה לתמונה. ההפרש הגדול ביותר בין המקור לתוצאה צריך להיות 0 או 1 (עיגול). החלון מציג את שתיהן זו ליד זו.'}]}

# ---- chapter 3 ----
_b102 = blocks['m2-b102']['text'].strip() + '\n'
_b108 = blocks['m2-b108']['text'].strip() + '\n'
_b113 = blocks['m2-b113']['text'].strip() + '\n'
_b113defs = _b113[:_b113.index('optimizer = torch.optim.Adam')]
P102 = {'code': _b102, 'say': 'המאגר והמטענים של סעיף 3.2.'}
P108 = {'code': _b108, 'say': 'המודל של סעיף 3.3, על ההתקן.'}
P113 = {'code': _b113defs + 'loss_fn = nn.CrossEntropyLoss()\n', 'say': 'שתי הפונקציות של הלולאה מסעיף 3.4 (`train_one_epoch`, `evaluate`) ופונקציית ההפסד.'}
F['m2-b102'] = {'remote': True, 'pre': [P17], 'post': [{'code': 'print(len(ds), len(train_ds), len(val_ds), len(train_dl), len(val_dl))   # examples, and batches per epoch\nxb, yb = next(iter(train_dl))\nprint(xb.shape, xb.dtype, yb.shape, yb.dtype)', 'say': 'כמה דוגמאות בכל חלק וכמה מנות בכל סבב, וצורות של מנה אחת: 64 נקודות של 2 מספרים, ו־64 תוויות.'}]}
F['m2-b108'] = {'remote': True, 'pre': [{'code': 'import torch\nfrom torch import nn\n', 'say': 'הספריות.'}], 'post': [{'code': 'print(model)\nprint(model(torch.zeros(5, 2, device=device)).shape)   # 5 points in, 5 rows of 3 scores out', 'say': 'מדפיס את מבנה המודל, ומריץ אותו על 5 נקודות כדי לוודא שהצורות נכונות.'}]}
F['m2-b113'] = {'remote': True, 'pre': [P17, P102, P108]}
F['m2-b123'] = {'remote': True, 'main': True, 'pre': [{'code': 'import torch\nfrom torch import nn\nfrom torch.utils.data import DataLoader, random_split\n\ndevice = "cuda" if torch.cuda.is_available() else "cpu"\n', 'say': 'הספריות וההתקן.'}, P113, {'code': '\ndef main():', 'say': '**חשוב ב־Windows:** `num_workers=2` מפעיל תהליכים נוספים שטוענים נתונים. ב־Windows כל תהליך כזה מריץ מחדש את הקובץ מההתחלה, ולכן הקוד שמתחיל את האימון חייב להיות בתוך פונקציה, שנקראת רק מ־`if __name__ == "__main__":` (בסוף). בלי זה — שגיאה "An attempt has been made to start a new process...". כך הורץ הקוד כאן.'}], 'post': [{'code': '\nif __name__ == "__main__":\n    main()', 'say': 'מריץ את `main` רק כשמריצים את הקובץ עצמו — לא כשתהליך עזר טוען אותו.'}]}
F['m2-b567'] = {'remote': True, 'pre': [P17, P102, P108, P113], 'post': [{'code': 'optimizer = MySGD(model.parameters(), lr=0.5)\nfor epoch in range(20):\n    train_loss = train_one_epoch(model, train_dl, optimizer, loss_fn, device)\n    val_loss, val_acc = evaluate(model, val_dl, loss_fn, device)\n    if epoch % 5 == 4:\n        print(epoch, round(train_loss, 3), round(val_acc, 3))', 'say': 'מאמן את הספירלות עם האופטימייזר שכתבת במקום של הספרייה. אם ההפסד יורד והדיוק עולה — הוא עובד.'}]}

REMOTE_STUB = ('try:\n    import cv2\n    cv2.imshow = lambda *a, **k: None\n    cv2.waitKey = lambda *a, **k: -1\n    cv2.destroyAllWindows = lambda *a, **k: None\nexcept ImportError:\n    pass\n'
               'import matplotlib\nmatplotlib.use("Agg")\n')
# ---- chapter 4 ----
F['m2-b144'] = {}
F['m2-b158'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}]}
F['m2-b167'] = {}
F['m2-b173'] = {'remote': True, 'pre': [{'code': 'import torch\nfrom torch import nn\n\ndevice = "cuda" if torch.cuda.is_available() else "cpu"\n', 'say': 'הספריות וההתקן (סעיף 2.4).'}], 'post': [{'code': 'print(model(x).shape)                                  # 8 images in, 8 rows of 10 scores out', 'say': 'מריץ את כל המודל על המנה: 10 ציונים לכל תמונה.'}]}

F['m2-b189'] = {}
F['m2-b203'] = {'remote': True, 'pre': [{'code': 'import torch\nfrom torch import nn\n', 'say': 'הספריות.'}], 'post': [{'code': 'same = BasicBlock(64, 64)\nprint(same.shortcut)                                   # Identity: x passes as it is\nprint(block.shortcut)                                  # a 1x1 conv with stride 2, and a normalization\nprint(sum(p.numel() for p in block.parameters()))       # the parameters of the block', 'say': 'משווה שני בלוקים: כשהגודל ומספר הערוצים לא משתנים, קו הדילוג הוא `Identity` — פשוט x. בבלוק של הסעיף (64 ל־128, צעד 2) הוא קונבולוציה של 1 על 1. ובסוף — כמה פרמטרים יש בבלוק.'}]}
F['m2-b212'] = {'remote': True}
F['m2-b219'] = {'remote': True, 'pre': [{'code': 'import torch\nfrom torch import nn\n', 'say': 'הספריות.'}], 'post': [{'code': 'blk = ConvNeXtBlock(96)\nx = torch.randn(2, 96, 56, 56)\nprint(blk(x).shape)                                    # the same shape as the input: needed for shortcut + x\nprint(sum(p.numel() for p in blk.parameters()))        # the parameters of one block\nprint(sum(p.numel() for p in blk.dwconv.parameters()), sum(p.numel() for p in blk.pw1.parameters()) + sum(p.numel() for p in blk.pw2.parameters()))   # spatial part vs channel part', 'say': 'מריץ בלוק של 96 ערוצים (הממד של השלב הראשון ב־ConvNeXt-T) על מנה: הפלט באותה צורה כמו הקלט — אחרת אי אפשר לחבר. אחר כך: כמה פרמטרים בבלוק, ואיך הם מתחלקים. הקונבולוציה המרחבית 7 על 7 זולה מאוד; רוב הפרמטרים בשתי שכבות ה־1 על 1.'}]}

F['m2-b234'] = {}
F['m2-b245'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}]}
F['m2-b251'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}, {'code': blocks['m2-b245']['text'].strip() + '\n', 'say': 'הקוד של סעיף 6.2: `softmax`, `self_attention`, והנתונים `X`, `Wq`, `Wk`, `Wv`, `out` שהקוד כאן משתמש בהם.'}]}
F['m2-b260'] = {'remote': True, 'pre': [{'code': 'import torch\nfrom torch import nn\n', 'say': 'הספריות.'}], 'post': [{'code': 'model = TinyViT()\nprint(sum(p.numel() for p in model.parameters()))      # parameters of the TinyViT of the course\nx = torch.randn(2, 3, 32, 32)\nprint(model.embed(x).flatten(2).transpose(1, 2).shape)   # 2 images, 64 patches, 192 numbers each', 'say': 'כמה פרמטרים יש ל־TinyViT של הקורס, והצורה אחרי שכבת השיכון: 64 טלאים (8 על 8) לכל תמונה, כל אחד וקטור של 192.'}]}

F['m2-b283'] = {}
F['m2-b290'] = {'remote': True, 'pre': [P17, P102, {'code': '# an imbalanced version of the spiral training set: only every 10th point of class 2 is kept\nkeep = [i for i in train_ds.indices if ds.y[i] != 2 or i % 10 == 0]\ntrain_ds = torch.utils.data.Subset(ds, keep)\ntrain_labels = ds.y[keep]\nnum_classes = 3\ndevice = "cuda" if torch.cuda.is_available() else "cpu"\n', 'say': 'הקוד של הסעיף צריך מאגר לא מאוזן ושלושה משתנים שהקורס לא מגדיר (`train_labels`, `num_classes`, `device`). כאן: הספירלות של פרק 3, כשמהמחלקה השלישית נשארת רק כל נקודה עשירית — מחלקה נדירה.'}],
            'post': [{'code': 'print(counts, weights)                                  # how many of each class, and the weight of each\nseen = torch.cat([yb for _, yb in train_dl])\nprint(torch.bincount(seen, minlength=num_classes))      # one epoch with the sampler: about balanced', 'say': 'מדפיס את מספר הדוגמאות והמשקל של כל מחלקה — לנדירה משקל גבוה — ואת מה שהמטען עם הדגימה המשוקללת באמת נתן בסבב אחד: בערך אותו מספר מכל מחלקה.'}]}
F['m2-b304'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}]}
F['m2-b309'] = {'remote': True, 'pre': [P17, P102, P108, P113], 'say': ''}

F['m2-b593'] = {'remote': True, 'pre': [{'code': 'import torch\n', 'say': 'הספרייה.'}], 'post': [{'code': 'torch.manual_seed(0)\nlogits, targets = torch.randn(8, 5), torch.randint(0, 5, (8,))\nprint(focal_loss(logits, targets, gamma=0.0).item(), F.cross_entropy(logits, targets).item())   # the same number (up to float32 rounding)\nprint(focal_loss(logits, targets, gamma=2.0).item())                                             # smaller', 'say': 'הבדיקה שהתרגיל מבקש: עם `gamma=0` ההפסד המומקד שווה לאנטרופיה הצולבת הרגילה — עד הספרה השביעית, כי הדרך דרך `exp(-ce)` מוסיפה עיגול זעיר של float32. עם `gamma=2` הוא קטן יותר, כי כל דוגמה מוכפלת במספר קטן מ־1.'}]}

F['m2-b324'] = {}
F['m2-b334'] = {'pre': [{'code': blocks['m2-b324']['text'].strip() + '\n', 'say': 'הקוד של סעיף 8.1: הנתונים (`x`, `y`, `xv`, `yv`) והפולינומים.'}]}
F['m2-b340'] = {'remote': True, 'pre': [{'code': 'import torch\nfrom torch import nn\n\nmodel = nn.Sequential(nn.Flatten(), nn.Linear(784, 256), nn.ReLU(), nn.Linear(256, 10))   # any model\n', 'say': 'הספריות ומודל כלשהו (כאן — הרשת המלאה של סעיף 3.6), כי הקורס מניח שיש `model`.'}], 'post': [{'code': 'print(optimizer.defaults["weight_decay"], optimizer.defaults["lr"])\nw = model[1].weight\nbefore = w.norm().item()\nfor _ in range(100):                      # no loss at all: only the decay acts\n    optimizer.zero_grad()\n    w.grad = torch.zeros_like(w)\n    optimizer.step()\nprint(round(before, 3), round(w.norm().item(), 3))   # the weights shrank', 'say': 'בדיקה של מה ש־`weight_decay` עושה: 100 צעדים עם גרדיאנט אפס — בלי שום הפסד — והמשקלים בכל זאת מתכווצים. זה העונש לבדו.'}]}
F['m2-b345'] = {'pre': [{'code': 'import numpy as np\n\nrng = np.random.default_rng(0)\n', 'say': 'NumPy, ומחולל המספרים האקראיים `rng` שהקוד משתמש בו (בקורס הוא נוצר בסעיף 8.1).'}]}
F['m2-b351'] = {'pre': [{'code': 'import numpy as np\n\nrng = np.random.default_rng(0)\n', 'say': 'NumPy ו־`rng`.'}]}
F['m2-b360'] = {'remote': True, 'pre': [{'code': 'import torch\nimport numpy as np\n', 'say': 'הספריות.'}], 'post': [{'code': 'from PIL import Image\nimg = Image.fromarray(np.random.default_rng(0).integers(0, 256, (300, 400, 3), dtype=np.uint8))   # any RGB photo\nprint(train_tf(img).shape, val_tf(img).shape)            # both 3 x 224 x 224\nprint(torch.equal(val_tf(img), val_tf(img)))             # validation: the same every time\nprint(torch.equal(train_tf(img), train_tf(img)))         # training: different every time', 'say': 'מריץ את שתי השרשראות על תמונה: שתיהן מוציאות <span class="ltr">3 × 224 × 224</span>. האימות נותן אותו טנזור בכל פעם (True), האימון — טנזור אחר בכל פעם (False). זה כל ההבדל.'}]}
F['m2-b366'] = {}

F['m2-b384'] = {'remote': True}
F['m2-b389'] = {'remote': True, 'pre': [{'code': blocks['m2-b384']['text'].strip() + '\n', 'say': 'הקוד של השלב הראשון (תחילת סעיף 9.1): המודל המאומן, ההקפאה והראש החדש.'}], 'post': [{'code': 'print([len(g["params"]) for g in optimizer.param_groups], [g["lr"] for g in optimizer.param_groups])   # two groups, two learning rates\nprint(sum(p.numel() for p in model.parameters() if p.requires_grad))                               # everything trains now', 'say': 'מדפיס כמה פרמטרים (טנזורים) יש בכל קבוצה ואת הקצב של כל אחת — 60 טנזורים בגוף בקצב 1e-4, ו־2 בראש בקצב 1e-3 — וכמה פרמטרים מתאמנים עכשיו: כולם.'}]}
F['m2-b398'] = {}
F['m2-b403'] = {'remote': True, 'pre': [P17, P102, P108, {'code': 'optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)\nloss_fn = nn.CrossEntropyLoss()\n', 'say': 'הלולאה של הסעיף צריכה מודל, מטען, אופטימייזר והפסד. כאן — אלה של פרק 3 (הספירלות). על מעבד, `enabled` כבוי: הקוד רץ בדיוק מלא, ואותו קוד ירוץ בדיוק מעורב על כרטיס.'}], 'post': [{'code': 'print(device, amp_dtype, scaler.is_enabled(), round(loss.item(), 3))   # on a CPU: no scaler, the same loop', 'say': 'מה נבחר במחשב הזה: ההתקן, פורמט חצי הדיוק, האם ה־scaler פעיל, וההפסד של המנה האחרונה — כדי לראות שהלולאה רצה.'}]}

F['m2-b418'] = {'remote': True, 'pre': [P17, P102], 'post': [{'code': 'set_seed(0)\na = torch.rand(3)\nset_seed(0)\nb = torch.rand(3)\nprint(a, torch.equal(a, b))                        # the same seed: the same numbers\nprint(next(iter(train_dl))[1][:10])                 # the first labels of the first batch', 'say': 'בודק את `set_seed`: אותו גרעין פעמיים — אותם מספרים אקראיים (True). ומדפיס את התוויות הראשונות במנה הראשונה של המטען עם המחולל שלו — בכל הרצה יצאו אותן תוויות.'}]}
F['m2-b422'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}]}
F['m2-b431'] = {}
F['m2-b435'] = {'pre': [{'code': blocks['m2-b431']['text'].strip().replace("%Y%m%d- %H%M%S", "%Y%m%d-%H%M%S") + '\n', 'say': 'הקוד של `RunLogger` מסעיף 10.2 — `compare` קוראת את התיקיות שהוא כותב.'}],
            'post': [{'code': 'import shutil\nshutil.rmtree("runs", ignore_errors=True)\nfor lr, accs in ((1e-3, [0.81, 0.85, 0.86]), (3e-4, [0.78, 0.83, 0.85]), (3e-3, [0.83, 0.86, 0.84])):\n    log = RunLogger("runs", {"lr": lr, "batch_size": 64, "seed": 0})\n    for ep, a in enumerate(accs):\n        log.log(epoch=ep, val_acc=a)\n    time.sleep(1.1)                               # a new second: a new folder name\ncompare("runs")', 'say': 'יוצר שלוש ריצות לדוגמה בתיקייה `runs` (עם מספרים מומצאים, בלי אימון — רק כדי שיהיה מה להשוות), ומריץ את `compare`: הטובה ביותר למעלה, לפי הדיוק <b>הטוב ביותר</b> בכל ריצה, לא האחרון.'}]}
F['m2-b609'] = {'remote': True, 'pre': [{'code': blocks['m2-b431']['text'].strip().replace("%Y%m%d- %H%M%S", "%Y%m%d-%H%M%S") + '\n', 'say': 'הקוד של `RunLogger` מסעיף 10.2.'}], 'post': [{'code': 'log = RunLogger("runs", cfg)\nlog.save_env()\nprint((log.dir / "env.json").read_text())', 'say': 'יוצר ריצה, קורא לשיטה החדשה, ומדפיס את הקובץ שנכתב.'}]}

F['m2-b455'] = {'pre': [P17, P22]}
F['m2-b461'] = {'pre': [P17, P22, {'code': 'X, y = make_spiral()\n', 'say': 'הנתונים, כמו בתחילת סעיף 11.1.'}]}
F['m2-b478'] = {'pre': [P17, P22, {'code': 'X, y = make_spiral()\n', 'say': 'הנתונים.'}]}
F['m2-b483'] = {'pre': [P17, P22, {'code': 'X, y = make_spiral()\n', 'say': 'הנתונים.'}]}
F['m2-b466'] = {'remote': True, 'pre': [P17, P102, P108, {'code': 'optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)\nloss_fn = nn.CrossEntropyLoss()\n', 'say': 'מודל, מטען, אופטימייזר והפסד — אלה של פרק 3 (הספירלות; המנה הראשונה היא 64 נקודות).'}]}
F['m2-b488'] = {'remote': True, 'pre': [P17, P102, P108, {'code': 'optimizer = torch.optim.Adam(model.parameters(), lr=1e-2)\nloss_fn = nn.CrossEntropyLoss()\nxb, yb = next(iter(train_dl))\nxb, yb = xb.to(device), yb.to(device)\noptimizer.zero_grad()\nloss = loss_fn(model(xb), yb)\n', 'say': 'מודל ומנה אחת מפרק 3, עם הפסד מחושב — כדי שיהיה על מה לקרוא ל־`backward`.'}], 'post': [{'code': 'print(round(float(total), 4))      # the total norm before clipping (returned by clip_grad_norm_)', 'say': 'מדפיס את הנורמה הכוללת שהפונקציה החזירה — זה המספר ששווה לרשום בכל צעד.'}]}


# ---- chapter 12: the project, as three files ----
def _defs_only(t, marker):
    return t[:t.index(marker)].rstrip() + '\n'
METRICS_PY = ('# metrics.py — the project of module 2, chapter 12 (sections 12.2 and 10.2)\n' + _defs_only(blocks['m2-b511']['text'], '\ny_true =')
              + '\n\n' + _defs_only(blocks['m2-b518']['text'], '\nes = EarlyStopping') + '\n\n'
              + _defs_only(blocks['m2-b431']['text'].replace("%Y%m%d- %H%M%S", "%Y%m%d-%H%M%S"), '\ncfg = {'))
TRAINER_PY = '# trainer.py — the project of module 2, chapter 12 (section 12.3)\n' + blocks['m2-b524']['text'].replace('EarlyStopping,\nRunLogger', 'EarlyStopping, RunLogger').strip() + '\n'
F['m2-b511'] = {}
F['m2-b518'] = {}
F['m2-b524'] = {'remote': True, 'files': {'metrics.py': METRICS_PY},
    'pre': [{'code': '# trainer.py needs metrics.py (section 12.2) in the same folder.\n', 'say': '**קובץ של הפרויקט.** `trainer.py` מייבא מ־`metrics.py` — שמור את שניהם באותה תיקייה (את `metrics.py` מורידים מסעיף 12.2, או בכפתור "הורד את הפרויקט").'}],
    'post': [{'code': '\nif __name__ == "__main__":                  # a quick check on the spirals of chapter 3 — not part of the file\n    import torch.nn as nn\n    from torch.utils.data import TensorDataset, DataLoader\n    torch.manual_seed(0)\n    t = torch.linspace(0, 1, 300); c = torch.arange(300) // 100\n    a = c * 4 + t * 4 + 0.2 * torch.randn(300)\n    X = torch.stack([t * torch.sin(a), t * torch.cos(a)], 1); y = c\n    dl = DataLoader(TensorDataset(X, y), batch_size=32, shuffle=True)\n    model = nn.Sequential(nn.Linear(2, 64), nn.ReLU(), nn.Linear(64, 3))\n    opt = torch.optim.Adam(model.parameters(), lr=1e-2)\n    tr = Trainer(model, nn.CrossEntropyLoss(), opt, None, {"patience": 3, "runs_dir": "runs"})\n    print("best", tr.fit(dl, dl, 15))\n    tr.report(dl, ["a", "b", "c"])', 'say': 'בדיקה קטנה שהמחלקה עובדת — לא חלק מהקובץ: הספירלות של פרק 3, רשת קטנה, 15 סבבים לכל היותר. אימון, עצירה מוקדמת, שמירה וטעינה של `best.pt`, ודוח עם מטריצת בלבול.'}]}
F['m2-b529'] = {'remote': True, 'main': True, 'files': {'metrics.py': METRICS_PY, 'trainer.py': TRAINER_PY},
    'jobfix': [('"epochs": 30', '"epochs": 4'), ('num_workers=2)', 'num_workers=0)'), ('\ndef main():', '\nimport sys\nclass _Tee:\n    def __init__(s, *f): s.f = f\n    def write(s, x):\n        for f in s.f: f.write(x); f.flush()\n    def flush(s): pass\nsys.stdout = _Tee(sys.stdout, open(r"C:\\Users\\Roey\\OneDrive\\Desktop\\קורס ראיה ממוחשבת -איתמר\\מעבדת הראייה\\_claude\\jobs\\b529_progress.txt", "w", encoding="utf8"))\n\ndef main():'), ('datasets.FashionMNIST("data"', 'datasets.FashionMNIST(os.path.join(os.path.expanduser("~"), ".course_data")')],
    'jobpost': '\nimport glob\nfor d in sorted(glob.glob("runs/*")):\n    print("RUN", os.path.basename(d))\n    for f in ("config.json", "metrics.csv", "confusion.csv"):\n        print("FILE", f)\n        print(open(os.path.join(d, f)).read())\n',
    'pre': [{'code': '# run_fashion.py — next to metrics.py and trainer.py (sections 12.2 and 12.3)\nimport os, random\nimport numpy as np\nimport torch\nfrom torch import nn\n\n\ndef set_seed(seed):                                  # chapter 10\n    random.seed(seed)\n    np.random.seed(seed)\n    torch.manual_seed(seed)\n    torch.cuda.manual_seed_all(seed)\n\n\n' + blocks['m2-b173']['text'][:blocks['m2-b173']['text'].index('\nmodel = SmallCNN()')].strip() + '\n\n', 'say': 'הקורס משתמש ב־`set_seed` (פרק 10) וב־`SmallCNN` (סעיף 4.6) בלי להגדיר אותם בקובץ. כאן הם מוגדרים בראשו, כדי שהקובץ ירוץ לבד.'},
            {'code': '\ndef main():', 'say': '**חשוב ב־Windows:** `num_workers=2` מפעיל תהליכים שמריצים את הקובץ מחדש — הקוד שמתחיל את האימון חייב להיות בתוך פונקציה, שנקראת רק מ־`if __name__ == "__main__":` (בסוף). בלי זה — שגיאה "An attempt has been made to start a new process...".'}],
    'post': [{'code': '\nif __name__ == "__main__":\n    main()', 'say': 'מריץ את `main` רק כשמריצים את הקובץ עצמו.'}]}
F['m2-b529']['note'] = '**איך הורץ במחשב שלך:** הקוד כאן הוא של הקורס (30 סבבים, `num_workers=2`). בהרצה שהפלט שלה מוצג הוחלפו שני ערכים בלבד: 4 סבבים, ו־`num_workers=0`. עם שני תהליכי טעינה הריצה לא הסתיימה בחצי שעה על המעבד; עם 0 — כ־100 שניות לסבב, 7 דקות בסך הכל. הנתונים נשמרו ב־`~/.course_data`.'
F['m2-b628'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}]}

def full(bid):
    f = F.get(bid, {}); body = blocks[bid]['text']
    if f.get('main'): body = '\n'.join('    ' + l if l.strip() else '' for l in body.split('\n'))      # the block becomes the body of main()
    return ''.join(x['code'] + '\n' for x in f.get('pre', [])) + body + ''.join('\n' + x['code'] for x in f.get('post', []))
HARNESS = textwrap.dedent('''
    import sys, json, base64, io, contextlib
    import cv2, numpy as np
    SHOWN = {}; CALLS = []
    def _imshow(name, im): SHOWN[name] = np.asarray(im).copy(); CALLS.append('imshow')
    cv2.imshow = _imshow
    _w = cv2.imwrite
    def _iw(path, im, *a): SHOWN[path] = np.asarray(im).copy(); return _w(path, im, *a)
    cv2.imwrite = _iw
    cv2.waitKey = lambda *a, **k: (CALLS.append('waitKey'), -1)[1]
    cv2.destroyAllWindows = lambda *a, **k: None
    cv2.namedWindow = lambda *a, **k: None
    cv2.createTrackbar = lambda *a, **k: None
    cv2.getTrackbarPos = lambda *a, **k: 0
    import os; sys.path.insert(0, os.getcwd())             # like running the file from its own folder
    src = open(sys.argv[1], encoding='utf8').read(); buf = io.StringIO(); err = None
    try:
        with contextlib.redirect_stdout(buf): exec(compile(src, 'script.py', 'exec'), {'__name__': '__main__'})
    except Exception as e: err = type(e).__name__ + ': ' + str(e)
    figs = []
    for name, im in list(SHOWN.items())[:3]:
        h, w = im.shape[:2]
        if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode('.png', im); figs.append('data:image/png;base64,' + base64.b64encode(b.tobytes()).decode())
    print(json.dumps({'stdout': buf.getvalue(), 'err': err, 'figs': figs, 'calls': CALLS}))
''')
open('/tmp/harness_sa.py', 'w').write(HARNESS)
ids = [b for b in blocks if b in F ]
bad = 0
for bid in ids:
    src = full(bid)
    if F[bid].get('remote'):                                        # PyTorch: runs on the user's computer through _claude/runner.py
        jsrc = src
        for a, b2 in F[bid].get('jobfix', []): assert a in jsrc, (bid, a); jsrc = jsrc.replace(a, b2)
        jsrc += F[bid].get('jobpost', '')
        fw = ''.join('open(%r, "w", encoding="utf8").write(%r)\n' % (n, c) for n, c in F[bid].get('files', {}).items())
        import hashlib; key = bid + '.' + hashlib.sha1((REMOTE_STUB + fw + jsrc).encode()).hexdigest()[:8]; ro = '/tmp/remote_out/' + key + '.out.json'
        if not os.path.exists(ro):
            os.makedirs('/mnt/user-data/outputs/jobs', exist_ok=True)
            job = REMOTE_STUB + fw + jsrc     # the script itself is the main module (DataLoader workers on Windows import it again)
            open('/mnt/user-data/outputs/jobs/' + key + '.py', 'w', encoding='utf8').write(job)
            print('PENDING', key); continue
        rr = json.load(open(ro, encoding='utf8'))
        if F[bid].get('jobpost') and '\nRUN ' in rr['stdout']: rr['stdout'] = rr['stdout'].split('\nRUN ')[0] + '\n'   # the job-only dump of the run folder is data for the labs, not output of the course code
        o = {'stdout': rr['stdout'], 'err': ('remote: ' + rr['stderr'][-600:]) if rr['code'] else None, 'figs': [], 'calls': []}
    else:
      with tempfile.TemporaryDirectory() as td:                      # empty folder, fresh interpreter: like a new PyCharm file
          open(os.path.join(td, 'script.py'), 'w', encoding='utf8').write(src)
          r = subprocess.run([sys.executable, '/tmp/harness_sa.py', 'script.py'], cwd=td, capture_output=True, text=True, timeout=120)
          try: o = json.loads(r.stdout.strip().splitlines()[-1])
          except Exception: o = {'err': 'harness: ' + r.stderr[-300:], 'stdout': '', 'figs': [], 'calls': []}
    shows = o['calls'].count('imshow'); waits = o['calls'].count('waitKey')
    status = 'OK ' if not o['err'] else 'ERR'
    if o['err']: bad += 1
    print(status, bid, '| stdout:', o['stdout'].strip().replace('\n', ' / ')[:70], '| windows:', shows, 'waitKey:', waits, '|', o['err'] or '')
    if not o['err']:
        out = {'stdout': o['stdout'][:4000]}
        if o['figs']: out['figs'] = o['figs']
        blocks[bid]['output'] = out
# a block that was run for real no longer says "(not run)": the note before it is updated (the course text is kept)
for ch in d['chapters']:
    for sec in ch['sections'] + [{'blocks': [b for e in ch['exercises'] for b in e['solution']]}]:
        bl = sec['blocks']
        for i, b in enumerate(bl[:-1]):
            nb = bl[i + 1]
            if b['type'] == 'p' and b['text'].strip() == '**(לא הורץ)**' and nb['type'] == 'code' and nb['id'] in F and F[nb['id']].get('remote') and any(f.startswith(nb['id'] + '.') and f.count('.') == 3 for f in os.listdir('/tmp/remote_out')):
                b['text'] = '**(בקורס: "לא הורץ". הורץ עכשיו — PyTorch 2.15, על מעבד, ב־Windows — והפלט למטה הוא מההרצה.)**'
if bad: sys.exit('some scripts failed')
open(p, 'w', encoding='utf8').write(s[:k] + json.dumps(d, ensure_ascii=False) + ';\n')
open('site/content/m2_codefull.js', 'w', encoding='utf8').write('/* Module 2 — additions that make each code example run on its own (generated by standalone_m2.py). */\n(window.LAYER.m2.codeFull = ' + json.dumps(F, ensure_ascii=False, indent=1) + ');\n')
print('written', len(F))

import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1200, 'height': 900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        async def go(s): await pg.goto('file:///home/claude/build/site/index.html#/m1/s/'+s); await pg.wait_for_timeout(600)
        async def shot(n): 
            el = await pg.query_selector('.tryit'); await el.screenshot(path=f'/tmp/t_{n}.png')
        await go('2.4'); await pg.click('.tryit button:has-text("הצג פתרון")'); await pg.wait_for_timeout(200); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1')); await shot('24')
        await go('3.3'); await pg.click('.tryit button:has-text("ליד חלון")'); await pg.click('.tryit button:has-text("הרץ את אוצו")'); await pg.wait_for_timeout(2600); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1')); await shot('33')
        await pg.click('.tryit button:has-text("תאורה אחידה")'); await pg.click('.tryit button:has-text("טקסט זעיר")'); await pg.click('.tryit button:has-text("הרץ את אוצו")'); await pg.wait_for_timeout(2600); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))
        await pg.click('.tryit button:has-text("טקסט רגיל")'); await pg.click('.tryit button:has-text("הרץ את אוצו")'); await pg.wait_for_timeout(2600); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))
        await go('2.6'); await pg.click('.tryit button:has-text("עצם נוסף")'); 
        await pg.eval_on_selector('.tryit input[type=range]', 'e=>{e.value=250;e.dispatchEvent(new Event("input"))}'); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1')); await shot('26')
        await pg.click('.tryit button:has-text("שקיעה")'); await pg.eval_on_selector('.tryit input[type=range]', 'e=>{e.value=0.8;e.dispatchEvent(new Event("input"))}'); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))
        await pg.click('.tryit button:has-text("אפור ולבן")'); await pg.eval_on_selector('.tryit input[type=range]', 'e=>{e.value=80;e.dispatchEvent(new Event("input"))}'); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))
        await pg.click('.tryit button:has-text("כהה מאוד")'); await pg.eval_on_selector('.tryit input[type=range]', 'e=>{e.value=80;e.dispatchEvent(new Event("input"))}'); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))
        await go('3.2'); await pg.click('.tryit button:has-text("מעשי")'); await shot('32')
        await go('1.3'); c = await pg.query_selector('.tryit canvas'); await c.scroll_into_view_if_needed(); bb = await c.bounding_box(); sx=bb['width']/200
        await pg.mouse.move(bb['x']+92*sx, bb['y']+62*sx); await pg.mouse.down(); await pg.mouse.move(bb['x']+128*sx, bb['y']+98*sx, steps=4); await pg.mouse.up()
        await pg.click('.tryit button:has-text("עיגול")'); await pg.eval_on_selector('.tryit input[type=range]', 'e=>{e.value=-1;e.dispatchEvent(new Event("input"))}')
        await pg.mouse.move(bb['x']+110*sx, bb['y']+81*sx); await pg.mouse.down(); await pg.mouse.move(bb['x']+113*sx, bb['y']+81*sx, steps=3); await pg.mouse.up()
        await pg.click('.tryit button:has-text("טקסט")'); await pg.mouse.click(bb['x']+98*sx, bb['y']+56*sx); await shot('13'); print(await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))
        await go('1.4'); await pg.click('.tryit button:has-text("בלי בדיקת ok")'); await pg.click('.tryit button:has-text("נגן")'); await pg.wait_for_timeout(1500); print((await pg.inner_text('.tryit >> nth=0 >> .say >> nth=-1'))[:80])
        print('ERRS', errs); await b.close()
asyncio.run(main())

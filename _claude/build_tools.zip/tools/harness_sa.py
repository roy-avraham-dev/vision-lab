
import sys, json, base64, io, contextlib
import cv2, numpy as np
SHOWN = {}; CALLS = []
def _imshow(name, im): SHOWN[name] = np.asarray(im).copy(); CALLS.append('imshow')
cv2.imshow = _imshow
_w = cv2.imwrite
def _iw(path, im, *a): SHOWN[path] = np.asarray(im).copy(); return _w(path, im, *a)
cv2.imwrite = _iw
cv2.waitKey = lambda *a, **k: (CALLS.append('waitKey'), -1)[1]
cv2.destroyAllWindows = lambda *a, **k: None
cv2.namedWindow = lambda *a, **k: None
cv2.createTrackbar = lambda *a, **k: None
cv2.getTrackbarPos = lambda *a, **k: 0
src = open(sys.argv[1], encoding='utf8').read(); buf = io.StringIO(); err = None
try:
    with contextlib.redirect_stdout(buf): exec(compile(src, 'script.py', 'exec'), {'__name__': '__main__'})
except Exception as e: err = type(e).__name__ + ': ' + str(e)
figs = []
for name, im in list(SHOWN.items())[:3]:
    h, w = im.shape[:2]
    if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
    ok, b = cv2.imencode('.png', im); figs.append('data:image/png;base64,' + base64.b64encode(b.tobytes()).decode())
print(json.dumps({'stdout': buf.getvalue(), 'err': err, 'figs': figs, 'calls': CALLS}))

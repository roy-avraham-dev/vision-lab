import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1200, 'height': 900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
        for n in (10,):
            await pg.goto(f'file:///home/claude/build/site/index.html#/m1/ex/{n}'); await pg.wait_for_timeout(900)
            print(n, 'cards', await pg.eval_on_selector_all('.ex','e=>e.length'), 'groups', await pg.eval_on_selector_all('h2.exgroup','e=>e.map(x=>x.innerText)'))
            for b_ in await pg.query_selector_all('.ex button[data-a=sol]'): await b_.click()
            await pg.wait_for_timeout(300)
            await pg.screenshot(path=f'/tmp/ex{n}.png', full_page=True)
        print([e for e in errs if 'ERR_' not in e][:5]); await b.close()
asyncio.run(main())

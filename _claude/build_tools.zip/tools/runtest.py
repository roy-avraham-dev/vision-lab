import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1200, 'height': 900}, permissions=['clipboard-read','clipboard-write'])
        pg = await ctx.new_page(); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/*jsdelivr*/**', lambda r: r.abort()); await pg.route('**/*unpkg*/**', lambda r: r.abort())
        await pg.goto('file:///home/claude/build/site/index.html#/m1/s/2.5'); await pg.wait_for_timeout(700)
        await pg.click('.codebox button[data-a=copy]'); await pg.wait_for_timeout(300)
        clip = await pg.evaluate('navigator.clipboard.readText()'); open('/tmp/clip.py','w',encoding='utf8').write(clip); print('clip lines', clip.count('\n')+1)
        await pg.click('.codebox button[data-a=run]'); await pg.wait_for_timeout(4000)
        t = await pg.inner_text('.codebox .live'); print(t[:400]); print('imgs', await pg.eval_on_selector_all('.codebox .live img','e=>e.length'))
        await (await pg.query_selector('.codebox')).screenshot(path='/tmp/c_run.png')
        print(errs); await b.close()
asyncio.run(main())

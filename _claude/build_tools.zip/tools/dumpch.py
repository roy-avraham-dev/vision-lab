import json,sys,re
tag=sys.argv[1]; n=int(sys.argv[2])
s=open(f'/home/claude/build/site/content/{tag}.js',encoding='utf8').read()
d=json.loads(s[s.index('= {')+2:].rstrip().rstrip(';'))
def bl(x,ind=''):
    t=x['type']
    if t=='table':
        print(ind+'[TABLE %s]'%x['id'])
        for r in x['rows']: print(ind+'   |', ' || '.join(' / '.join(('`%s`'%c['text'] if c['type']=='code' else c.get('text','')) for c in cell) for cell in r))
    elif t=='code': print(ind+'[code %s]\n%s'%(x['id'],x['text'])); 
    elif t=='img': print(ind+'[img %s %s]'%(x['id'],x['src']))
    else: print(ind+'[%s %s]'%(t,x['id']), x.get('text',''))
    if t=='code' and x.get('output'): print(ind+'  OUT:',repr(x['output'].get('stdout',''))[:400])
ch=[c for c in d['chapters'] if c['n']==n][0]
print('# CH',n,ch['title'])
for b in ch.get('lead',[]): bl(b)
for sec in ch['sections']:
    print('\n## SEC',sec['id'],sec['title'])
    for b in sec['blocks']: bl(b)
print('\n## EXERCISES')
for e in ch['exercises']:
    print('-- EX',e['id'],'star' if e['star'] else '')
    for b in e['blocks']: bl(b,'  ')
    print('  SOL:')
    for b in e['solution']: bl(b,'  ')

import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page()
        await pg.goto('file:///home/claude/build/site/index.html#/')
        await pg.wait_for_timeout(500)
        secs = await pg.evaluate("window.CONTENT.m1.chapters.flatMap(c=>c.sections.map(s=>[s.id, s.blocks.map(b=>b.id)]))")
        bad = 0; dropped_imgs = 0
        for sid, ids in secs:
            await pg.evaluate("window.__seen=[]"); await pg.evaluate(f"location.hash='#/m1/s/{sid}'"); await pg.wait_for_timeout(120)
            seen = await pg.evaluate("window.__seen.map(x=>x.replace(/-2$/,''))")
            want = set(ids); got = [x for x in seen]
            missing = [i for i in ids if i not in got]
            imgs = await pg.evaluate(f"window.CONTENT.m1.chapters.flatMap(c=>c.sections).find(s=>s.id=='{sid}').blocks.filter(b=>b.type=='img'||b.type=='caption').map(b=>b.id)")
            real_missing = [i for i in missing if i not in imgs]
            dropped_imgs += len([i for i in missing if i in imgs])
            dup = [i for i in set(got) if got.count(i) > 1 and not any(i == x for x in got if False)]
            # split paragraphs appear twice by design (id and id-2) -> ignore those
            if real_missing: bad += 1; print('MISSING', sid, real_missing)
        print('sections', len(secs), 'with missing text blocks:', bad, '| images replaced by a visual:', dropped_imgs)
        await b.close()
asyncio.run(main())

import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 900})
        bad=0
        for r in sys.argv[1].split(','):
            await pg.goto('file:///home/claude/build/site/index.html#' + r); await pg.wait_for_timeout(250)
            n = await pg.evaluate(r"""(document.body.innerText.match(/[\u0003\u0004-]/g)||[]).length""")
            if n: bad+=1; print(r, n)
        print('pages with control chars:', bad)
        await b.close()
asyncio.run(main())

import asyncio, sys
from playwright.async_api import async_playwright
ids = sys.argv[1].split(',')
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1200, 'height': 900})
        for s in ids:
            await pg.goto('file:///home/claude/build/site/index.html#/m2/s/' + s); await pg.wait_for_timeout(int(sys.argv[2]) if len(sys.argv)>2 else 700)
            el = await pg.query_selector('.tryit')
            if el: await el.screenshot(path=f'/tmp/w2_{s}.png')
        await b.close()
asyncio.run(main())

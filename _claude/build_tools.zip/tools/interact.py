import asyncio, sys, json
from playwright.async_api import async_playwright
routes = open(sys.argv[1]).read().split()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1300, 'height': 900})
        errs = []
        pg.on('pageerror', lambda e: errs.append(cur[0] + ' ' + str(e)))
        cur = ['']
        for h in routes:
            if '/s/' not in h: continue
            cur[0] = h
            await pg.goto('file:///home/claude/build/site/index.html#' + h); await pg.wait_for_timeout(300)
            await pg.evaluate("""() => {
              const ws = [...document.querySelectorAll('.tryit .w')];
              ws.forEach(w => {
                w.querySelectorAll('input[type=range]').forEach(r => { r.value = r.max; r.dispatchEvent(new Event('input')); r.value = r.min; r.dispatchEvent(new Event('input')); r.value = (+r.min + +r.max)/2; r.dispatchEvent(new Event('input')); });
                w.querySelectorAll('button').forEach(bt => { if (!/נגן/.test(bt.textContent)) bt.click(); });
                w.querySelectorAll('canvas').forEach(c => { const r = c.getBoundingClientRect(); c.dispatchEvent(new MouseEvent('click', { clientX: r.left + r.width / 3, clientY: r.top + r.height / 2, bubbles: true })); });
                w.querySelectorAll('svg rect, svg g').forEach((x, i) => { if (i < 30) x.dispatchEvent(new MouseEvent('click', { bubbles: true })); });
              });
            }""")
            await pg.wait_for_timeout(200)
            n = await pg.evaluate("document.querySelectorAll('.err').length")
            if n: errs.append(h + ' widget err')
        print(json.dumps(errs, ensure_ascii=False, indent=0) if errs else 'NO ERRORS')
        await b.close()
asyncio.run(main())

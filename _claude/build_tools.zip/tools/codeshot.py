import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1200, 'height': 900}); errs=[]
        pg.on('pageerror', lambda e: errs.append(str(e)))
        for s in sys.argv[1].split(','):
            await pg.goto('file:///home/claude/build/site/index.html#/m1/s/' + s); await pg.wait_for_timeout(700)
            els = await pg.query_selector_all('.codebox')
            for i, el in enumerate([e for e in els if await e.is_visible()][:2]): await el.screenshot(path=f'/tmp/c_{s}_{i}.png')
            print(s, len(els), 'expected shown:', await pg.eval_on_selector_all('.codeout.expected', 'e=>e.length'))
        print(errs); await b.close()
asyncio.run(main())

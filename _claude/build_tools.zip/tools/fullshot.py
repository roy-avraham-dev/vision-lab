import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 900})
        for r in sys.argv[1].split(','):
            await pg.goto('file:///home/claude/build/site/index.html#' + r); await pg.wait_for_timeout(900)
            await pg.screenshot(path='/tmp/fs' + r.replace('/', '_') + '.png', full_page=True)
        await b.close()
asyncio.run(main())

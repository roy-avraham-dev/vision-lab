#!/bin/bash
cd /home/claude/build/site && rm -f /mnt/user-data/outputs/site_update.zip && zip -qr /mnt/user-data/outputs/site_update.zip . && cd .. && rm -f /mnt/user-data/outputs/build_tools.zip && zip -qr /mnt/user-data/outputs/build_tools.zip *.py *.json *.sh tools routes*.txt CLAUDE_PLAYBOOK.md && cp CLAUDE_PLAYBOOK.md /mnt/user-data/outputs/CLAUDE_PLAYBOOK.md && echo packed

import json,sys
d=json.load(open(sys.argv[1])); a=int(sys.argv[2]); b=int(sys.argv[3])
print('META',d['meta'])
for x in d['blocks'][a:b]:
    if x['type']=='table':
        print('[TABLE p%d hdr=%s]'%(x['page'],x['header']))
        for r in x['rows']: print('   |', ' || '.join(' / '.join(('`%s`'%s['text'] if s['type']=='code' else s['text']) for s in c) for c in r))
    elif x['type']=='code': print('[code p%d]\n%s'%(x['page'],x['text']))
    else: print('[%s p%d%s]'%(x['type'],x['page'],(' L%d'%x['level']) if 'level' in x else ''), x.get('text', x.get('src')))

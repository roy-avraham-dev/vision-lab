# Stand-alone additions for the code examples of module 4: writes site/content/m4_codefull.js,
# verifies every full script in a fresh process and an empty folder, and refreshes the precomputed outputs in m4.js.
import json, os, subprocess, sys, tempfile, base64, textwrap
PIP = 'אם PyCharm מסמן את `cv2` או את `numpy` באדום, הרץ פעם אחת בטרמינל שלו: `pip install opencv-python numpy`.'
IMP = {'code': 'import cv2\nimport numpy as np\n', 'say': 'שתי הספריות שהקוד משתמש בהן. ' + PIP}
def show(*names, extra=''):
    return {'code': extra + ''.join(f'cv2.imshow("{n}", {n})\n' for n in names) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()',
            'say': 'מציג את התוצאה: ' + ('חלון אחד' if len(names) == 1 else f'{len(names)} חלונות') + ' (' + ', '.join(f'`{n}`' for n in names) + '). לחיצה על מקש כלשהו, כשאחד החלונות בפוקוס, סוגרת אותם.'}
NP = {'code': 'import numpy as np\n', 'say': 'NumPy. אם PyCharm מסמן אותה באדום: `pip install numpy`.'}
F = {}
# ---------------- chapter 1
F['m4-b22'] = {'post': [{'code': '\nb = [100, 50, 140, 130]\nprint(yolo_to_xyxy(xyxy_to_yolo(b, 640, 480), 640, 480))   # there and back\nprint(xyxy_to_coco(b))', 'say': 'הבדיקה שהסעיף מתאר במילים — "המרה הלוך וחזור מחזירה בדיוק את (100, 50, 140, 130)" — כקוד: פינות ← YOLO ← פינות. ועוד המרה לפורמט COCO, שהקוד מגדיר ולא מדפיס.'}]}
F['m4-b365'] = {'post': [{'code': '\nprint(clip_box([-10, 20, 50, 60], 640, 480))\nprint(clip_box([700, 20, 750, 60], 640, 480))', 'say': 'הקוד של הפתרון רק מגדיר את הפונקציה. שתי השורות מריצות את שתי הבדיקות של השאלה: המלבן הראשון נחתך בקצה השמאלי, והשני כולו מחוץ לתמונה — None.'}]}
# ---------------- chapter 2
F['m4-b54'] = {'post': [{'code': '\ndets = [[0, 0, 10, 10], [2, 2, 12, 12], [50, 50, 60, 60]]\ngts = [[0, 0, 10, 10], [48, 52, 58, 62]]\nM = iou_matrix(dets, gts)\nprint(M.shape)\nprint(M.round(3))', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה. כאן שלושה זיהויים מול שני מלבני אמת: טבלה בצורה ‎(3, 2)‎. בשורה השנייה והשלישית ‎0.471‎ — אותה הזזה של שני פיקסלים מסעיף 2.2.'}]}
F['m4-b374'] = {'post': [{'code': '\nprint(giou([0, 0, 10, 10], [20, 0, 30, 10]))\nprint(giou([0, 0, 10, 10], [40, 0, 50, 10]))\nprint(giou([0, 0, 10, 10], [5, 0, 15, 10]))     # overlapping: the empty part of the enclosing box is small', 'say': 'הקוד של הפתרון רק מגדיר את הפונקציה. שתי השורות הראשונות הן המקרים של השאלה (‏−0.333 ו־−0.6), והשלישית — זוג חופף מתרגיל 2.1: שם ה־GIoU קרוב לחפיפה הרגילה (0.333 פחות 0.333·0, כי המלבן העוטף מלא).'}]}
# ---------------- chapter 3
IOU_SAY = 'NumPy, והפונקציה `iou_matrix` מסעיף 2.3 — הקוד של הסעיף קורא לה. ' + "אם PyCharm מסמן את `numpy` באדום: `pip install numpy`."
F['m4-b73'] = {'pre': [{'code': 'B54_LATER', 'say': IOU_SAY}], 'post': [{'code': '\nB = [[100, 100, 200, 200], [110, 105, 210, 205], [300, 300, 380, 380], [105, 95, 195, 190], [305, 310, 385, 390]]\nS = [0.9, 0.8, 0.75, 0.7, 0.6]\nfor thr in (0.5, 0.7, 0.8):\n    print(thr, nms(B, S, thr))', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה. כאן חמשת המלבנים של סעיף 3.3, בשלושה ספים — המעקב של הסעיף ושל תרגיל 3.1: ‎[0, 2]‎, ‎[0, 2, 4]‎ וכל החמישה.'}]}
F['m4-b90'] = {'pre': [{'code': 'B54_LATER', 'say': IOU_SAY}, {'code': 'B73_LATER', 'say': 'הפונקציה `nms` מסעיף 3.2 — `batched_nms` קוראת לה.'}], 'post': [{'code': '\nboxes = [[100, 100, 200, 200], [102, 101, 201, 199], [300, 300, 380, 380]]\nscores = [0.9, 0.85, 0.7]\nprint(nms(boxes, scores))                            # one class for all: the second box is removed\nprint(batched_nms(boxes, scores, [0, 1, 0]))         # box 1 is another class: kept', 'say': 'הבדיקה שהפתרון מתאר במילים: שני מלבנים כמעט זהים. בסינון רגיל השני נמחק; כשהוא ממחלקה אחרת — שניהם נשמרים.'}]}
F['m4-b383'] = {'pre': [{'code': 'B54_LATER', 'say': IOU_SAY}], 'post': [{'code': '\nboxes = [[100, 100, 160, 260], [115, 100, 175, 260], [101, 102, 161, 258]]   # two people (IoU 0.6) and a duplicate of the first\nkeep, s = soft_nms(boxes, [0.9, 0.85, 0.8])\nprint(keep)\nprint(np.round(s, 3))', 'say': 'הקוד של הפתרון רק מגדיר את הפונקציה. כאן שני האנשים של סעיף 3.4 (חפיפה 0.6) וכפילות של הראשון: כולם נשארים ברשימה, אבל הכפילות יורדת לציון נמוך והאדם השני — רק בחצי בערך. סף ציון של 0.3 היה משאיר בדיוק את שני האנשים. (טבלת 200 הסצנות של הפתרון נבנתה עם כלי המדידה של פרק 4; ההדמיה של סעיף 3.4 מריצה ניסוי דומה.)'}]}
# ---------------- chapter 4
F['m4-b106'] = {'pre': [{'code': 'B54_LATER', 'say': IOU_SAY}], 'post': [{'code': '\n# the example of section 4.2: four ground-truth boxes, five detections\nprint(round(ap_from(np.array([0.95, 0.9, 0.8, 0.6, 0.3]), np.array([True, False, True, False, True]), 4), 3))\n\n# and the whole way, on one image: two cars, three detections (one duplicate)\ngts = [[100, 100, 150, 125], [300, 200, 346, 221]]\ndets = [[101, 100, 151, 126], [103, 99, 152, 124], [299, 201, 345, 222]]\nscores, tp = match(dets, [0.9, 0.6, 0.8], gts)\nprint(scores, tp)\nprint(round(ap_from(scores, tp, len(gts)), 3))\n\n# the duplicate is now in the middle of the list, not at its end\nscores, tp = match(dets, [0.9, 0.85, 0.8], gts)\nprint(scores, tp, round(ap_from(scores, tp, len(gts)), 3))', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציות. השורה הראשונה מריצה את `ap_from` על הדוגמה של 4.2 — ‎0.571‎, כמו בסעיף. אחר כך כל הדרך על תמונה אחת: שני רכבים ושלושה זיהויים, אחד מהם כפילות. הכפילות (ציון 0.6) נספרת כפספוס, כי הרכב כבר נתפס — אבל ה־AP עדיין 1: הפספוס בתחתית הרשימה, אחרי ששני הרכבים כבר נמצאו (זה תרגיל 4.2). בהרצה האחרונה הכפילות מקבלת ציון 0.85, בין שני הרכבים — ועכשיו ה־AP יורד.'}]}
# ---------------- chapter 5
F['m4-b137'] = {'post': [{'code': '\n# the round trip of the section: every cell centre inside (200, 150, 290, 230), stride 16\nbox = np.array([200, 150, 290, 230.0])\ncx, cy = make_grid(640, 640, 16)\ninside = (cx > box[0]) & (cx < box[2]) & (cy > box[1]) & (cy < box[3])\nprint("cell centres inside:", inside.sum())\nltrb = np.stack([cx - box[0], cy - box[1], box[2] - cx, box[3] - cy], 1) / 16   # encode: what the head should predict\nback = decode(ltrb, 640, 640, 16)[inside]\nprint("all decode back to the box:", np.allclose(back, box))\n\n# exercise 5.2: row 10, column 12, stride 32\npred = np.zeros((20 * 20, 4)); pred[10 * 20 + 12] = [1.5, 0.75, 2.0, 1.25]\nprint(decode(pred, 640, 640, 32)[10 * 20 + 12])', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציות. כאן הבדיקה שהסעיף מתאר: 25 מרכזי תאים בתוך המלבן, ומכל אחד הקידוד והפענוח מחזירים אותו בדיוק. ובסוף — תרגיל 5.2: ‎(352, 312, 464, 376)‎.'}]}
F['m4-b150'] = {'skiprun': True, 'note': '**זה לא קוד פייתון** — זה קובץ תיאור מאגר. שמור אותו בשם `drone.yaml`, ושנה את `path` לתיקייה של המאגר שלך. מבנה התיקיות שהספרייה מצפה לו: `images/train`, `images/val`, ולצדן `labels/train`, `labels/val` — קובץ תיוג בפורמט YOLO (פרק 1) לכל תמונה, באותו שם.'}
F['m4-b154'] = {'local': True, 'skiprun': True, 'note': '**רץ רק במחשב, עם מאגר משלך.** צריך `pip install ultralytics`, את `drone.yaml` מהקוד הקודם, ותמונה בשם `frame.jpg` בתיקייה של הקובץ. המשקלות `yolo26n.pt` יורדים אוטומטית בהרצה הראשונה. על מעבד בלבד האימון איטי מאוד — לבדיקה מהירה קבע `epochs=3`. אם אין לך מאגר, אפשר לנסות את הקוד עם `data="coco8.yaml"` — מאגר זעיר של שמונה תמונות שהספרייה מורידה בעצמה (ואז גם `names` שונה).'}
# ---------------- chapter 6
F['m4-b173'] = {'pre': [{'code': 'B54_LATER', 'say': 'הפונקציה `iou_matrix` מסעיף 2.3 — הקוד של הסעיף קורא לה. ואם PyCharm מסמן את `scipy` באדום: `pip install scipy`.'}], 'post': [{'code': '\nprint(cost.round(3))     # the whole table: one row per query, one column per object', 'say': 'תוספת: כל מטריצת העלויות. בשורות 0 ו־1, מול עצם 0: ‎−0.613‎ ו־‎−0.529‎ — שתי שאילתות טובות, ורק אחת מקבלת את העצם.'}]}
F['m4-b406'] = {'pre': [NP], 'post': [{'code': '\nimport time\nfrom scipy.optimize import linear_sum_assignment\n\nrng = np.random.default_rng(0)\nagree = 0\nfor _ in range(200):\n    n = int(rng.integers(2, 7))\n    C = rng.uniform(0, 10, (n, n))\n    r, c = linear_sum_assignment(C)\n    agree += abs(brute_assign(C) - C[r, c].sum()) < 1e-9\nprint("agree:", agree, "/ 200")\nfor n in (7, 8, 9):\n    C = rng.uniform(0, 10, (n, n))\n    t0 = time.perf_counter(); brute_assign(C)\n    print(n, round(time.perf_counter() - t0, 2), "s")\nC = rng.uniform(0, 10, (300, 300))\nt0 = time.perf_counter(); linear_sum_assignment(C)\nprint("hungarian 300 x 300:", round(time.perf_counter() - t0, 4), "s")', 'say': 'הבדיקה שהפתרון מתאר: 200 מטריצות אקראיות בגדלים 2 עד 6, הסכמה עם `linear_sum_assignment`, ואז זמנים בגדלים 7 עד 9 — כל צעד מכפיל בערך בגודל. בסוף ההונגרי על 300 על 300. הזמנים במחשב שלך יהיו אחרים מאלה שכאן.'}]}
# ---------------- chapter 7
F['m4-b202'] = {'post': [{'code': '\nprint(len(tiles(4000, 3000)))            # the section: 8 columns x 6 rows\nprint(len(tiles(1920, 1080)), tiles(1920, 1080))   # exercise 7.1\nprint(len(tiles(4000, 3000, ov=0.1)))    # exercise 7.3: 10% overlap', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה. שלוש הבדיקות: ‎48‎ אריחים בצילום של הסעיף, ‎8‎ בתרגיל 7.1 (עם הפינות עצמן), ו־‎42‎ עם חפיפה של 10% (תרגיל 7.3).'}]}
F['m4-b212'] = {'local': True, 'skiprun': True, 'note': '**רץ רק במחשב.** צריך `pip install sahi ultralytics`, את `best.pt` שאימנת בפרק 5 (או `yolo26n.pt` לניסיון), ותמונה בשם `frame.jpg` בתיקייה של הקובץ. כדי לראות את התוצאה: `res.export_visuals(export_dir=".")` שומר תמונה עם המלבנים.'}
F['m4-b415'] = {'pre': [NP], 'post': [{'code': '\n# a car cut by a tile border: a partial box from the left tile, a full one from its neighbour\nboxes = [[624, 1385, 676, 1409], [624, 1386, 640, 1408], [100, 100, 120, 120]]\nscores = np.array([0.9, 0.5, 0.8])\nprint(ios_matrix(boxes[:1], boxes[1:2]).round(3))     # IoS: almost 1\nkept, s = merge_ios(boxes, scores)\nprint(kept, s)', 'say': 'הקוד של הפתרון רק מגדיר את הפונקציות. כאן הרכב מההדמיה של 7.4: מלבן חלקי (16 פיקסלים מתוך 52) ומלבן מלא. ה־IoS ביניהם ‎1‎, והאיחוד משאיר שני מלבנים — הרכב והעצם הנפרד. (את הניסוי על 30 התמונות של 7.3 מריצה ההדמיה של סעיף 7.3.)'}]}
# ---------------- chapter 8
LEAK_PRE = "import numpy as np\n\n# the experiment of the section: 40 videos x 100 frames; one label per video, a weak true signal,\n# and a unique 'look' for every video\nrng = np.random.default_rng(0)\nlook = rng.normal(0, 3, (40, 8))\nlabel_v = np.arange(40) % 2\nvideo_id = np.repeat(np.arange(40), 100)\ny = label_v[video_id]\nX = look[video_id] + rng.normal(0, 0.15, (4000, 8))\nX[:, 0] += 0.35 * (2 * y - 1)            # the weak true signal\n"
F['m4-b242'] = {'pre': [{'code': LEAK_PRE, 'say': 'הקוד של הסעיף מניח שכבר יש `X`, `y` ו־`video_id`. השורות האלה בונות את הנתונים של הניסוי בסעיף: 40 סרטונים של 100 פריימים, תווית אחת לכל סרטון, סימן אמיתי חלש ו"מראה" ייחודי לכל סרטון.'}],
    'post': [{'code': '\nprint(len(set(video_id[te])), "test videos,", len(te), "test frames")\n\n# the table of the section: random split by frames vs split by videos, kNN, ten splits each\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.neighbors import KNeighborsClassifier\nfor name in ("random frames", "by video"):\n    acc = []\n    for seed in range(10):\n        if name == "random frames":\n            a, b = train_test_split(np.arange(len(X)), test_size=0.25, random_state=seed)\n        else:\n            a, b = next(GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=seed).split(X, y, groups=video_id))\n        acc.append(KNeighborsClassifier(5).fit(X[a], y[a]).score(X[b], y[b]))\n    print(name, round(np.mean(acc), 3), "+-", round(np.std(acc), 3))', 'say': 'אחרי הפיצול: כמה סרטונים וכמה פריימים בבדיקה. ואז הטבלה של הסעיף — עשר חלוקות לכל דרך, עם מסווג שכנים קרובים. הנתונים כאן נבנו מחדש, ולכן המספרים קרובים לשל הקורס (1.000 מול 0.546) ולא זהים.'}]}
F['m4-b424'] = {'pre': [{'code': "import numpy as np\n\n# 40 videos, 6 of them at night (the exercise)\nrng = np.random.default_rng(0)\nvideo_id = np.repeat(np.arange(40), 50)\nnight_v = np.zeros(40, int); night_v[rng.choice(40, 6, replace=False)] = 1\nis_night = night_v[video_id]\nX = rng.normal(size=(len(video_id), 4))\n", 'say': 'הקוד של הפתרון מניח `X`, `is_night` ו־`video_id`. השורות האלה בונות 40 סרטונים, שישה מהם של לילה, כמו בתרגיל.'}]}
# ---------------- chapter 9
F['m4-b258'] = {'pre': [{'code': 'B54_LATER', 'say': IOU_SAY}], 'post': [{'code': '\n# the four cases of exercise 9.1 (class 0 = car, 1 = person), plus a hit\ngts = np.array([[100, 100, 200, 160], [300, 100, 400, 160], [500, 100, 560, 220]], float)\ngcls = np.array([0, 0, 1])\ndets = np.array([[101, 101, 201, 161],      # hits car 0\n                 [102, 99, 199, 160],       # the same car again: duplicate\n                 [500, 120, 560, 220],      # "car" on the person: class\n                 [350, 100, 450, 160],      # a car shifted by 50: localization\n                 [700, 400, 740, 440]], float)   # nothing there: background\ndcls = np.array([0, 0, 0, 0, 0])\nscores = np.array([0.9, 0.8, 0.7, 0.6, 0.5])\nkinds, used, size = analyze(dets, dcls, scores, gts, gcls)\nprint(kinds)\nprint(used, size)', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה. כאן חמישה זיהויים, אחד מכל סוג: פגיעה, כפילות, בלבול (רכב על אדם), מיקום (רכב מוזז ב־50 פיקסלים — חפיפה 0.33) ורקע. שימו לב לשורה השנייה: הרכב השני לא נתפס (המלבן שלו הוזז), והאדם לא נתפס (קיבל מלבן "רכב") — שתי החמצות, מעבר לשני הפספוסים.'}]}
F['m4-b433'] = {'pre': [{'code': 'B54_LATER', 'say': IOU_SAY}], 'post': [{'code': '\ngts = np.array([[100, 100, 200, 160], [300, 100, 400, 160], [500, 100, 560, 220]], float)\ngcls = np.array([0, 0, 1])\ndets = np.array([[101, 101, 201, 161], [500, 120, 560, 220], [700, 400, 740, 440]], float)\ndcls = np.array([0, 0, 1])\nprint(confusion(dets, dcls, gts, gcls, K=2))\n# rows: car, person, background   columns: car, person, not found', 'say': 'הדוגמה הקטנה שהפתרון מתאר: פגיעה (רכב), בלבול (רכב על אדם), החמצה (הרכב השני) ופספוס רקע — כל אחד בתא שלו. סכום כל שורת מחלקה = מספר העצמים שלה.'}]}
# ---------------- chapter 10
F['m4-b279'] = {'post': [{'code': '\n# simulated records like the section: 2,000 objects, recall by altitude and time of day\nimport random\nrandom.seed(4)\np = {(40, "day"): 0.88, (80, "day"): 0.82, (120, "day"): 0.67, (40, "night"): 0.66, (80, "night"): 0.50, (120, "night"): 0.37}\nrecords = []\nfor _ in range(2000):\n    alt, tod = random.choice([40, 80, 120]), random.choice(["day", "night"])\n    records.append((alt, tod, random.random() < p[(alt, tod)]))\nprint("overall", round(sum(r[2] for r in records) / len(records), 2))\nrecall_by_slice(records)', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה. כאן 2,000 רשומות מדומות שנבנו לפי הטבלה של הסעיף, הרגישות הכוללת — ‎0.65‎ בערך — ואז הפירוק: לכל פרוסה מספר הדוגמאות והרגישות. (המספרים קרובים לטבלה של הסעיף, כי הנתונים נבנו ממנה; מדגם אקראי אחר.)'}]}
# ---------------- chapter 11
RAW16 = "import numpy as np\n\n# a simulated 16-bit thermal frame, like the experiment of the section:\n# background around 7,500, a warm person 400 units above it, and a small hot engine at 16,000\nrng = np.random.default_rng(0)\nraw16 = (7500 + rng.normal(0, 40, (512, 640))).astype(np.uint16)\nyy, xx = np.mgrid[0:512, 0:640]\nperson = (yy - 250) ** 2 / 9 ** 2 + (xx - 320) ** 2 / 6 ** 2 < 1\nraw16[person] = 7900\nraw16[100:108, 500:508] = 16000\n"
F['m4-b308'] = {'pre': [{'code': RAW16, 'say': 'הקוד של הסעיף מניח שכבר יש `raw16`. השורות האלה בונות תמונה תרמית מדומה של 16 ביטים כמו בניסוי של הסעיף: רקע סביב 7,500, אדם 400 יחידות מעליו, ומנוע קטן ב־16,000.'}],
    'post': [{'code': '\n# the table of the section: person vs background after each conversion\ndef minmax(raw):\n    r = raw.astype(np.float32)\n    return ((r - r.min()) / (r.max() - r.min()) * 255).astype(np.uint8)\n\nfor name, img in (("min-max", minmax(raw16)), ("percentiles 1..99", img8)):\n    p, b = img[person].mean(), img[~person].mean()\n    print(name, " person", round(float(p), 1), " background", round(float(b), 1), " difference", round(float(p - b), 1))\nprint(img3.shape, img3.dtype)\n\n# exercise 11.2: a higher upper percentile\nfor hi in (99.9, 99.99):\n    im = pstretch(raw16, 1, hi)\n    print(hi, round(float(im[person].mean()), 1), round(float(im[~person].mean()), 1))', 'say': 'הטבלה של הסעיף על התמונה המדומה: ההפרש בין אדם לרקע גדל פי 10 בערך, והאדם רווי (255). אחר כך הצורה של התמונה בשלושה ערוצים, ותרגיל 11.2 — אחוזון עליון של 99.9 ו־99.99. כאן האדם והמנוע יחד תופסים רק 0.07% מהתמונה: ב־99.9 הסף עדיין נופל ברעש של הרקע, והאדם רווי; ב־99.99 הסף כבר בתוך המנוע — והכול נדחס שוב, כמו במינימום־מקסימום. המספרים של הקורס שונים (שם האדם גדול יותר), והמסקנה זהה: סף לפי אחוזון תלוי במה שיש בתמונה.'}]}
F['m4-b448'] = {'local': True, 'skiprun': True, 'pre': [{'code': 'import torch\nimport torchvision\n\nmodel = torchvision.models.resnet18(weights="DEFAULT")\nmodel.eval()\nx = torch.rand(1, 1, 224, 224)                  # a grey image\nwith torch.no_grad():\n    before = model(x.repeat(1, 3, 1, 1))         # the old way: the channel copied three times\n', 'say': 'הקוד של הפתרון מניח `model`. השורות האלה טוענות רשת ResNet18 מאומנת (מודול 2), ומריצות אותה על תמונת אפור עם הערוץ משוכפל — כדי להשוות אחר כך.'}],
    'post': [{'code': 'with torch.no_grad():\n    after = model(x)                             # the new layer takes one channel\nprint(torch.allclose(before, after, atol=1e-4))', 'say': 'הבדיקה שהפתרון מתאר: הפלט של הרשת עם השכבה החדשה (ערוץ אחד) שווה לפלט המקורי עם הערוץ המשוכפל, עד שגיאת עיגול — `True`.'}],
    'note': '**רץ רק במחשב** — צריך `torch` ו־`torchvision` (מודול 2). המשקלות של ResNet18 יורדים בהרצה הראשונה.'}
# ---------------- chapter 12
F['m4-b336'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'הקוד של הסעיף משתמש ב־`np.nonzero` ו־`np.argmax`, אבל מייבא רק את `cv2` — בקובץ חדש זו שגיאת `NameError`. השורה מוסיפה את הייבוא. ' + PIP}],
    'post': [{'code': '\n# the experiment of the section: a 40 x 20 object and one extra pixel far away\nm = np.zeros((100, 100), bool)\nm[20:40, 30:70] = True\nm[60, 80] = True\nprint("raw box:          ", mask_to_box(m))\nprint("largest component:", mask_to_box(largest_component(m)))\nprint("empty mask:       ", mask_to_box(np.zeros((10, 10), bool)))\n\nvis = cv2.cvtColor(m.astype(np.uint8) * 255, cv2.COLOR_GRAY2BGR)\nx1, y1, x2, y2 = mask_to_box(m)\ncv2.rectangle(vis, (x1, y1), (x2 - 1, y2 - 1), (0, 0, 255), 1)          # red: the raw box\nx1, y1, x2, y2 = mask_to_box(largest_component(m))\ncv2.rectangle(vis, (x1, y1), (x2 - 1, y2 - 1), (255, 0, 0), 1)          # blue: after largest_component\nvis = cv2.resize(vis, (400, 400), interpolation=cv2.INTER_NEAREST)\ncv2.imshow("mask and boxes", vis)\ncv2.waitKey(0)\ncv2.destroyAllWindows()',
              'say': 'הקוד של הסעיף רק מגדיר את הפונקציות. כאן הניסוי שהסעיף מתאר: עצם של 40 על 20 ופיקסל נוסף אחד. המלבן הגולמי ‎(30, 20, 81, 61)‎, ואחרי הרכיב הגדול ‎(30, 20, 70, 40)‎ — בדיוק. השורה השלישית — מסכה ריקה: `None`. ובחלון: המסכה מוגדלת פי 4, המלבן הגולמי באדום והמתוקן בכחול (‏`x2 - 1` כי `cv2.rectangle` מצייר עד הפיקסל האחרון <i>כולל</i>, והמלבן שלנו נגמר אחריו).'}]}
F['m4-b342'] = {'local': True, 'skiprun': True, 'pre': [{'code': 'B336_LATER', 'say': 'הקוד של הסעיף קורא ל־`mask_to_box` ול־`largest_component` מסעיף 12.2 — הן כאן, עם הייבוא של NumPy שחסר שם.'}],
    'note': '**רץ רק במחשב.** צריך `pip install ultralytics` ותמונה בשם `frame.jpg` בתיקייה של הקובץ. המשקלות `sam2.1_b.pt` יורדות אוטומטית בהרצה הראשונה (כמה מאות מגה־בייט); שמות המשקלות משתנים בין גרסאות הספרייה — אם השם לא נמצא, בדוק בתיעוד של ultralytics אילו גרסאות SAM נתמכות. שנה את `[512, 300]` לנקודה שנמצאת על עצם בתמונה שלך — הקואורדינטות הן ‎(x, y)‎ בפיקסלים. על מעבד בלבד כל הרצה לוקחת כמה שניות.'}
#@@CH@@

p = 'site/content/m4.js'; s = open(p, encoding='utf8').read(); k = s.index('= {', 40) + 2
d = json.loads(s[k:].rstrip().rstrip(';'))
blocks = {}
for ch in d['chapters']:
    for sec in ch['sections']:
        for b in sec['blocks']:
            if b['type'] == 'code': blocks[b['id']] = b
    for e in ch['exercises']:
        for b in e['blocks'] + e['solution']:
            if b['type'] == 'code': blocks[b['id']] = b
for _b, _f in F.items():
    for _x in _f.get('pre', []):
        if _x['code'] == 'B54_LATER': _x['code'] = blocks['m4-b54']['text'] + '\n'
        elif _x['code'] == 'B73_LATER': _x['code'] = blocks['m4-b73']['text'] + '\n'
        elif _x['code'] == 'B336_LATER': _x['code'] = 'import numpy as np\n' + blocks['m4-b336']['text'] + '\n'
def full(bid):
    f = F.get(bid, {}); return ''.join(x['code'] + '\n' for x in f.get('pre', [])) + blocks[bid]['text'] + ''.join('\n' + x['code'] for x in f.get('post', []))
HARNESS = textwrap.dedent('''
    import sys, json, base64, io, contextlib
    import cv2, numpy as np
    SHOWN = {}; CALLS = []
    def _imshow(name, im): SHOWN[name] = np.asarray(im).copy(); CALLS.append('imshow')
    cv2.imshow = _imshow
    _w = cv2.imwrite
    def _iw(path, im, *a): SHOWN[path] = np.asarray(im).copy(); return _w(path, im, *a)
    cv2.imwrite = _iw
    cv2.waitKey = lambda *a, **k: (CALLS.append('waitKey'), -1)[1]
    cv2.destroyAllWindows = lambda *a, **k: None
    cv2.namedWindow = lambda *a, **k: None
    cv2.createTrackbar = lambda *a, **k: None
    cv2.getTrackbarPos = lambda *a, **k: 0
    import os; sys.path.insert(0, os.getcwd())             # like running the file from its own folder
    src = open(sys.argv[1], encoding='utf8').read(); buf = io.StringIO(); err = None
    try:
        with contextlib.redirect_stdout(buf): exec(compile(src, 'script.py', 'exec'), {'__name__': '__main__'})
    except Exception as e: err = type(e).__name__ + ': ' + str(e)
    figs = []
    for name, im in list(SHOWN.items())[:3]:
        h, w = im.shape[:2]
        if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode('.png', im); figs.append('data:image/png;base64,' + base64.b64encode(b.tobytes()).decode())
    print(json.dumps({'stdout': buf.getvalue(), 'err': err, 'figs': figs, 'calls': CALLS}))
''')
open('/tmp/harness_sa.py', 'w').write(HARNESS)
ids = [b for b in blocks if b in F ]
bad = 0
for bid in ids:
    src = full(bid)
    if F[bid].get('skiprun'): print('SKIP', bid, '(needs libraries that are not installed here)'); continue
    with tempfile.TemporaryDirectory() as td:                      # empty folder, fresh interpreter: like a new PyCharm file
        open(os.path.join(td, 'script.py'), 'w', encoding='utf8').write(src)
        r = subprocess.run([sys.executable, '/tmp/harness_sa.py', 'script.py'], cwd=td, capture_output=True, text=True, timeout=120)
        try: o = json.loads(r.stdout.strip().splitlines()[-1])
        except Exception: o = {'err': 'harness: ' + r.stderr[-300:], 'stdout': '', 'figs': [], 'calls': []}
    shows = o['calls'].count('imshow'); waits = o['calls'].count('waitKey')
    status = 'OK ' if not o['err'] else 'ERR'
    if o['err']: bad += 1
    print(status, bid, '| stdout:', o['stdout'].strip().replace('\n', ' / ')[:70], '| windows:', shows, 'waitKey:', waits, '|', o['err'] or '')
    if not o['err']:
        out = {'stdout': o['stdout'][:4000]}
        if o['figs']: out['figs'] = o['figs']
        blocks[bid]['output'] = out
if bad: sys.exit('some scripts failed')
open(p, 'w', encoding='utf8').write(s[:k] + json.dumps(d, ensure_ascii=False) + ';\n')
open('site/content/m4_codefull.js', 'w', encoding='utf8').write('/* Module 4 — additions that make each code example run on its own (generated by standalone_m4.py). */\n(window.LAYER.m4.codeFull = ' + json.dumps(F, ensure_ascii=False, indent=1) + ');\n')
print('written', len(F))

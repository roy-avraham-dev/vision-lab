import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1300, 'height': 1000})
        for i, h in enumerate(sys.argv[1].split(',')):
            await pg.goto('file:///home/claude/build/site/index.html#' + h); await pg.wait_for_timeout(700)
            await pg.screenshot(path=f'/home/claude/build/full_{i}.png', full_page=True)
        await b.close()
asyncio.run(main())

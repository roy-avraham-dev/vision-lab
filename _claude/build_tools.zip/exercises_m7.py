# Module 6: levels and question explanations for the course exercises, plus supplementary exercises
# that cover the sections the original sets do not reach. Validates every automatic check (starter must fail,
# solution must pass) and every solution script, then writes site/content/m7_exercises.js.
import json, subprocess, sys, tempfile, os

# ---------- the course's own exercises: level (1 warm-up, 2 practice, 3 challenge), section, and what the question asks ----------
META = {}

def T(task, starter, body, solved):
    return {'task': task, 'starter': starter, 'body': body, 'solved': solved}

IMPORTS = 'import cv2\nimport numpy as np\n\n'
SHOW = lambda *n: ''.join(f'cv2.imshow("{x}", {x})\n' for x in n) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()'

X = []
META.update({
 '1.1': (1, '1.2', '**זה חישוב ביד.** **נתון:** שני וקטורים מהדוגמה של הסעיף. **מה לעשות:** מכפלה, אורכים וקוסינוס. **איך תדע שהצלחת:** ‏0.582 — וההדמיה של 1.2 מראה את אותו מספר.'),
 '1.2': (1, '1.2', '**זו שאלת הבנה.** **נתון:** שיכון התמונה כפול 10. **מה לעשות:** לומר מה קורה לקוסינוס ולמכפלה בלי נרמול, ולמה זה חשוב בחיפוש. **איך תדע שהצלחת:** הקוסינוס לא זז — וההדמיה של 1.2 (מתג "תמונה × 10") מראה את זה.'),
 '1.3': (1, '1.1', '**זו שאלת השוואה.** **נתון:** מחלקה אחת נוספת למזהה של 80. **מה לעשות:** מה עושים בסגור ומה בפתוח. **איך תדע שהצלחת:** תזכיר גם את הכיול של הסף בפתוח — וההדמיה של 1.1 מראה את שני העולמות.'),
 '1.4': (3, '1.2', '**זו שאלת חשיבה.** **נתון:** משפט שהוא בדיוק שיכון התמונה. **מה לעשות:** לומר מה יקרה לסדר, ומה המסקנה לבחירת הרשימה. **איך תדע שהצלחת:** תסביר שסיווג פתוח בוחר מתוך הרשימה — וההדמיה של 1.2 מראה את הגניבה.'),
 '2.1': (1, '2.2', '**זה חישוב.** **נתון:** מודל שכל הציונים שלו שווים. **מה לעשות:** ההפסד ל־B = 4 ו־B = 128. **איך תדע שהצלחת:** ‏<span class="ltr">ln B</span> — ‏1.386 ו־4.852.'),
 '2.2': (2, '2.1', '**זו הערכה.** **נתון:** 24 צירופים ומנה של 128. **מה לעשות:** כמה פעמים כל צירוף, ומה רצפת ההפסד. **איך תדע שהצלחת:** כ־5.3 פעמים, רצפה של כ־1.67 — וההדמיה של 2.1 מחשבת את זה למנה אקראית.'),
 '2.3': (2, '2.2', '**זו שאלת הבנה.** **נתון:** ההפסד הסימטרי. **מה לעשות:** להסביר מה קורה עם כיוון אחד בלבד. **איך תדע שהצלחת:** תזכיר כיתוב "רכזת", ולמה זה פוגע בחיפוש.'),
 '2.4': (3, '2.2', '**זה גזירה.** **נתון:** ההפסד מתמונה לטקסט. **מה לעשות:** להראות שהנגזרת לפי הציונים היא <span class="ltr">(P − I)/B</span> ולפרש. **איך תדע שהצלחת:** תפרש סימן וגודל של כל תא — וההדמיה של 2.2 מציירת את המטריצה הזו.'),
})
X += [
 # ------------------------------------------------ chapter 1
 {'id': '1.5', 'ch': 1, 'level': 2, 'sec': '1.2',
  'q': ['סיווג פתוח בשתי פונקציות. השלם את <code class="ltr">cosine(a, b)</code> (מטריצת קוסינוסים בין שורות של <span class="ltr">a</span> לשורות של <span class="ltr">b</span>) ואת <code class="ltr">classify(images, texts, names)</code>, שמחזירה לכל תמונה את שם המשפט הקרוב ביותר.',
        '**א.** על הדוגמה של הסעיף — מה מקבלים?', '**ב.** מה יקרה אם אחד המשפטים יהיה וקטור אפסים, ואיך תגן מזה?'],
  'hints': ['<code class="ltr">a / np.linalg.norm(a, axis=-1, keepdims=True)</code>.', '<code class="ltr">argmax(1)</code> על מטריצת הקוסינוסים.'],
  'sol': ['**א.** ‏<span class="ltr">"a red car"</span>.', '**ב.** חלוקה באפס — <span class="ltr">nan</span>, ו־argmax יחזיר תוצאה מקרית. מגינים עם <span class="ltr">np.maximum(norm, 1e-12)</span>, ובודקים מראש שאין משפט ריק (במודל הזעיר של פרק 3, משפט בלי אף מילה מוכרת).'],
  'test': T('השלם את cosine ואת classify.',
            'import numpy as np\n\ndef cosine(a, b):\n    return a @ b.T     # TODO: normalize\n\ndef classify(images, texts, names):\n    return [names[0] for _ in images]     # TODO\n',
            "import numpy as np\nimg = np.array([[0.9, 0.1, 0.4]])\nT_ = np.array([[1.0, 0.0, 0.5], [0.0, 1.0, 0.0], [0.2, 0.1, 1.0]])\nc = cosine(img, T_)\nassert np.allclose(np.round(c, 3), [[0.994, 0.101, 0.582]]), f'הקוסינוסים של הסעיף: 0.994, 0.101, 0.582; קיבלתי {np.round(c, 3)}'\nassert np.allclose(cosine(10 * img, T_), c), 'קוסינוס לא תלוי באורך'\nassert classify(np.array([[0.0, 0.0, 2.0], [0.1, 3.0, 0.0]]), T_, ['car', 'person', 'truck']) == ['truck', 'person']",
            'import numpy as np\n\ndef cosine(a, b):\n    a = a / np.maximum(np.linalg.norm(a, axis=-1, keepdims=True), 1e-12)\n    b = b / np.maximum(np.linalg.norm(b, axis=-1, keepdims=True), 1e-12)\n    return a @ b.T\n\ndef classify(images, texts, names):\n    return [names[i] for i in cosine(images, texts).argmax(1)]\n')},
 {'id': '1.6', 'ch': 1, 'level': 2, 'sec': '1.1',
  'q': ['השכבה האחרונה כעמודות מטקסט. השלם את <code class="ltr">add_class(W, names, vec, name)</code>: ‏<span class="ltr">W</span> היא מטריצה בצורה <span class="ltr">(d, C)</span> של עמודות מנורמלות, ו־<span class="ltr">vec</span> שיכון של משפט חדש. מחזירה <span class="ltr">(W2, names2)</span> עם עמודה נוספת — מנורמלת — בסוף.',
        '**א.** למה חייבים לנרמל את העמודה החדשה?', '**ב.** במסווג סגור עם הטיה <span class="ltr">b</span> לכל מחלקה — איזו הטיה תיתן לעמודה החדשה, ולמה זו שאלה קשה?'],
  'hints': ['<code class="ltr">np.concatenate([W, v[:, None]], axis=1)</code>.', 'נרמל את <span class="ltr">vec</span> לפני ההוספה.'],
  'sol': ['**א.** אחרת הציון של המחלקה החדשה יהיה מוכפל באורך שלה, והיא תנצח (או תפסיד) בגלל אורך ולא בגלל דמיון — בדיוק תרגיל 1.2.', '**ב.** ההטיות במסווג סגור נלמדו ומשקפות גם את השכיחות של כל מחלקה באימון. למחלקה חדשה אין שכיחות נלמדת — ולכן במודל פתוח אין הטיה לכל מחלקה, ובמקומה יש סף (פרק 6.4) שמכיילים על דוגמאות.'],
  'test': T('השלם את add_class.',
            'import numpy as np\n\ndef add_class(W, names, vec, name):\n    return W, names     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nW = rng.normal(size=(8, 3)); W /= np.linalg.norm(W, axis=0)\nW2, n2 = add_class(W, ['a', 'b', 'c'], 5 * rng.normal(size=8), 'new')\nassert W2.shape == (8, 4) and n2 == ['a', 'b', 'c', 'new'], f'צורה (8, 4) ושם חדש בסוף; קיבלתי {W2.shape} {n2}'\nassert np.allclose(np.linalg.norm(W2, axis=0), 1), 'כל העמודות מנורמלות'\nassert np.allclose(W2[:, :3], W), 'העמודות הישנות לא משתנות'",
            'import numpy as np\n\ndef add_class(W, names, vec, name):\n    v = vec / np.linalg.norm(vec)\n    return np.concatenate([W, v[:, None]], axis=1), list(names) + [name]\n')},
 {'id': '1.7', 'ch': 1, 'level': 2, 'sec': '1.3',
  'q': ['**זו שאלת תכנון.** לכל משימה במערכת הדגל — איזו משפחה (מקודדים משותפים, מזהה פתוח, מודל שפה־ראייה) תבחר, ולמה לא את האחרות?',
        {'table': [['משימה', 'משפחה?'], ['למצוא בארכיון של 40 שעות את הקטעים עם "משאית אדומה"', '?'], ['להתריע בזמן אמת כשמופיע "אדם עם תיק גב" — כולל מיקום בפריים', '?'], ['לתאר למפעיל מה קורה בפריים שהמערכת סימנה', '?'], ['לספור רכבים עוברים — אותן שמונה מחלקות כל יום', '?']]}],
  'hints': ['מה המשימה צריכה: ציון לפריים, מיקום, או משפט?', 'השורה האחרונה — האם בכלל צריך עולם פתוח?'],
  'sol': ['ארכיון — מקודדים משותפים: וקטור אחד לכל פריים, פעם אחת, וחיפוש במכפלה (פרק 6); מזהה פתוח על 40 שעות יקר בהרבה ולא צריך מיקום. התראה עם מיקום — מזהה פתוח (פרק 7): צריך קופסה. תיאור למפעיל — מודל שפה־ראייה (פרק 8), רק על פריימים שכבר סומנו, כי הוא איטי ועלול להמציא. ספירת רכבים — מזהה סגור (מודול 4, פרק 9): מחלקות קבועות, ומודל סגור מדויק ומהיר יותר עליהן.']},
 {'id': '1.8', 'ch': 1, 'level': 2, 'sec': '1.2',
  'q': ['המלכודת של תרגיל 1.2, בחיפוש. השלם את <code class="ltr">search(index, q, k, normalize)</code>: מחזירה את האינדקסים של <span class="ltr">k</span> השורות ב־<span class="ltr">index</span> עם הציון הגבוה מול <span class="ltr">q</span> — במכפלה סקלרית, או (עם <span class="ltr">normalize=True</span>) בקוסינוס.',
        '**א.** בבדיקה, לתמונה אחת יש וקטור ארוך במיוחד ולא קשור לשאילתה. איפה היא מופיעה בכל אחת מהשיטות?', '**ב.** איפה בצינור עדיף לנרמל — בכל חיפוש, או פעם אחת?'],
  'hints': ['<code class="ltr">np.argsort(-scores)[:k]</code>.', 'נרמל את השורות של האינדקס ואת השאילתה.'],
  'sol': ['**א.** בלי נרמול — ראשונה, בגלל האורך; עם נרמול — לא בעשרה הראשונים.', '**ב.** פעם אחת, כשבונים את האינדקס (ומשאילתה פעם אחת) — ואז החיפוש הוא מכפלה בלבד, וזה מה שעושים בפרק 6.'],
  'test': T('השלם את search.',
            'import numpy as np\n\ndef search(index, q, k, normalize):\n    return np.argsort(-(index @ q))[:k]     # TODO: normalize\n',
            "import numpy as np\nrng = np.random.default_rng(1)\nq = rng.normal(size=16)\nidx = rng.normal(size=(200, 16))\nidx[:10] = q + 0.3 * rng.normal(size=(10, 16))\nbad = rng.normal(size=16); bad -= bad @ q / (q @ q) * q; idx[150] = 40 * bad + 2 * q\nr0 = search(idx, q, 10, False)\nassert 150 in r0[:1], 'בלי נרמול, הוקטור הארוך צריך להופיע ראשון'\nr1 = search(idx, q, 10, True)\nassert 150 not in r1, 'עם נרמול הוא לא בעשרה הראשונים'\nassert set(r1) == set(range(10)), f'עם נרמול — עשר התמונות הקרובות באמת; קיבלתי {sorted(r1)}'",
            'import numpy as np\n\ndef search(index, q, k, normalize):\n    if normalize:\n        index = index / np.linalg.norm(index, axis=1, keepdims=True)\n        q = q / np.linalg.norm(q)\n    return np.argsort(-(index @ q))[:k]\n')},
 {'id': '1.9', 'ch': 1, 'level': 3, 'sec': '1.1',
  'q': ['**אתגר — הטוב משני העולמות.** נקודת הבונוס של שאלת הראיון: לאתחל מסווג סגור משיכוני הטקסט, ולכוונן על מעט דוגמאות. השלם את <code class="ltr">finetune(W0, X, y, steps=200, lr=0.5, scale=10)</code>: רגרסיה לוגיסטית רב־מחלקתית על <span class="ltr">scale · X @ W</span> (X מנורמל), שמתחילה מ־<span class="ltr">W0</span> ומחזירה את <span class="ltr">W</span> אחרי ירידה בשיפוע.',
        '**א.** בבדיקה יש דוגמה <i>אחת</i> לכל מחלקה. מה הדיוק של אתחול מטקסט בלי אימון, של אתחול אקראי עם אימון, ושל אתחול מטקסט עם אימון? ומה קורה עם חמש דוגמאות לכל מחלקה?', '**ב.** למה האתחול מטקסט עוזר כשיש מעט דוגמאות, ופחות כשיש הרבה?'],
  'hints': ['<span class="ltr">P = softmax(scale · X @ W)</span>; ‏<span class="ltr">grad = scale · X.T @ (P − Y) / n</span>.', '<span class="ltr">Y</span> — מטריצת one-hot מ־<span class="ltr">y</span>.'],
  'sol': ['**א.** בבדיקה, עם דוגמה אחת: מטקסט בלבד 73.7%; אקראי עם הדוגמה — 65.1%; מטקסט עם כוונון — 80.1%, הטוב ביותר (בממוצע על חמישה זרעים: 81% / 70% / 84%). עם חמש דוגמאות (ממוצע על חמישה זרעים): ‏88% מול 90% — הפער כמעט נעלם.', '**ב.** עם מעט דוגמאות, נקודת ההתחלה קובעת כמעט הכול — והטקסט מכיל ידע על המחלקה שחמש תמונות לא מכילות. עם הרבה דוגמאות, הנתונים מספיקים לבד, והאתחול נשכח. זו הסיבה שהשיטה הזו מופיעה כבונוס בפרק 9: מתחילים פתוח, ומתכנסים לסגור.'],
  'test': T('השלם את finetune.',
            'import numpy as np\n\ndef finetune(W0, X, y, steps=200, lr=0.5, scale=10):\n    return W0     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nd, C = 16, 4\nproto = rng.normal(size=(C, d))\ntext = proto + 0.9 * rng.normal(size=(C, d))\ndef sample(n):\n    y = np.repeat(np.arange(C), n); X = proto[y] + 1.2 * rng.normal(size=(len(y), d)); return X / np.linalg.norm(X, axis=1, keepdims=True), y\nXtr, ytr = sample(1); Xte, yte = sample(300)\nW0 = (text / np.linalg.norm(text, axis=1, keepdims=True)).T\nacc = lambda W: ((Xte @ W).argmax(1) == yte).mean()\nWr = rng.normal(size=(d, C)) * 0.1\na0, ar, at = acc(W0), acc(finetune(Wr, Xtr, ytr)), acc(finetune(W0, Xtr, ytr))\nassert at > a0, f'כוונון צריך לשפר את האתחול מטקסט: {a0:.3f} ← {at:.3f}'\nassert at > ar, f'אתחול מטקסט צריך לנצח אתחול אקראי עם אותה דוגמה אחת: {ar:.3f} מול {at:.3f}'\nprint('text only %.3f   random + 1 example %.3f   text + 1 example %.3f' % (a0, ar, at))",
            'import numpy as np\n\ndef finetune(W0, X, y, steps=200, lr=0.5, scale=10):\n    W = W0.copy(); n, C = len(X), W.shape[1]\n    Y = np.eye(C)[y]\n    for _ in range(steps):\n        Z = scale * X @ W\n        P = np.exp(Z - Z.max(1, keepdims=True)); P /= P.sum(1, keepdims=True)\n        W -= lr * scale * X.T @ (P - Y) / n\n    return W\n')},
 # ------------------------------------------------ chapter 2
 {'id': '2.5', 'ch': 2, 'level': 1, 'sec': '2.2',
  'q': ['**חישוב ביד, מנה של שני זוגות.** מטריצת הקוסינוסים היא <span class="ltr">[[0.8, 0.2], [0.2, 0.8]]</span>, וקנה המידה 5.',
        '**א.** מה ההסתברות שהשורה הראשונה נותנת לכיתוב הנכון?', '**ב.** מה ההפסד (שני הכיוונים שווים כאן — למה)?', '**ג.** מה יקרה להפסד אם קנה המידה יהיה 20?'],
  'hints': ['הציונים: 4 ו־1. ‏<span class="ltr">e⁴ / (e⁴ + e¹)</span>.', 'המטריצה סימטרית.'],
  'sol': ['**א.** ‏<span class="ltr">e³ / (e³ + 1) ≈ 0.953</span>.', '**ב.** ‏<span class="ltr">−ln 0.953 ≈ 0.049</span>. המטריצה סימטרית, ולכן השורות והעמודות זהות.', '**ג.** ציונים 16 ו־4: ‏<span class="ltr">−ln(1/(1 + e⁻¹²)) ≈ 6·10⁻⁶</span> — כמעט אפס. קנה מידה גדול מחדד; בגלל זה מאמנים אותו, ובגלל זה גם מגבילים אותו (ב־100) — אחרת ההסתברויות קשות מדי והאימון לא יציב.']},
 {'id': '2.6', 'ch': 2, 'level': 1, 'sec': '2.1',
  'q': ['**חישוב קצר על הנתונים.** 4 צורות, 4 צבעים, 2 גדלים, וארבעה צירופים של צורה וצבע מחוץ לאימון.',
        '**א.** כמה מחלקות יש לסיווג ללא דוגמאות של פרק 4? כמה מהן לא נראו באימון?', '**ב.** כמה כיתובים שונים יכולים להופיע באימון (ארבעה נוסחים)?', '**ג.** מה הסיכוי שמנה של 128 לא מכילה אף "large red circle"?'],
  'hints': ['<span class="ltr">4 · 4 · 2</span>.', 'הסיכוי לא לקבל צירוף מסוים בדגימה אחת: <span class="ltr">23/24</span>.'],
  'sol': ['**א.** 32 מחלקות; 8 לא נראו (ארבעה צירופים × 2 גדלים).', '**ב.** ‏<span class="ltr">24 · 4 = 96</span>.', '**ג.** ‏<span class="ltr">(23/24)¹²⁸ ≈ 0.0043</span> — כמעט תמיד הוא שם, בממוצע 5.3 פעמים. זה לא "קצת כפילויות" — זה המצב הרגיל.']},
 {'id': '2.7', 'ch': 2, 'level': 2, 'sec': '2.2',
  'q': ['תרגיל 2.4 בקוד, ובדיקה שהנגזרת נכונה — ההרגל של סעיף 3.4. השלם את <code class="ltr">grad_logits(L)</code>: הנגזרת של ההפסד מתמונה לטקסט (<span class="ltr">mean of −log softmax on the diagonal</span>) לפי מטריצת הציונים <span class="ltr">L</span>. הבדיקה משווה לנגזרת מספרית.',
        '**א.** למה הנגזרת המספרית היא בדיקה כל כך חזקה?', '**ב.** מה סכום כל שורה של הנגזרת, ולמה?'],
  'hints': ['<span class="ltr">P = softmax(L, axis=1)</span>.', '<span class="ltr">(P − I) / B</span>.'],
  'sol': ['**א.** היא לא תלויה בשום נוסחה שכתבנו — רק בהפסד עצמו. כל טעות בגזירה (סימן, חלוקה, שחלוף) מתגלה מיד.', '**ב.** אפס: ‏<span class="ltr">Σ P = 1</span> ו־<span class="ltr">Σ I = 1</span> בכל שורה. הגדלת כל הציונים בשורה באותו מספר לא משנה את הסיווג — ולכן לא משנה את ההפסד.'],
  'test': T('השלם את grad_logits.',
            'import numpy as np\n\ndef grad_logits(L):\n    return np.zeros_like(L)     # TODO\n',
            "import numpy as np\ndef loss(L):\n    A = L - L.max(1, keepdims=True); A = A - np.log(np.exp(A).sum(1, keepdims=True))\n    return -np.diag(A).mean()\nrng = np.random.default_rng(0)\nL = 5 * rng.normal(size=(6, 6))\nG = grad_logits(L)\nnum = np.zeros_like(L); h = 1e-6\nfor i in range(6):\n    for j in range(6):\n        E = np.zeros_like(L); E[i, j] = h\n        num[i, j] = (loss(L + E) - loss(L - E)) / (2 * h)\nassert np.abs(G - num).max() < 1e-6, f'הנגזרת צריכה להתאים לנגזרת המספרית; הפרש {np.abs(G - num).max():.2e}'\nassert np.allclose(G.sum(1), 0), 'סכום כל שורה אפס'",
            'import numpy as np\n\ndef grad_logits(L):\n    P = np.exp(L - L.max(1, keepdims=True)); P /= P.sum(1, keepdims=True)\n    return (P - np.eye(len(L))) / len(L)\n')},
 {'id': '2.8', 'ch': 2, 'level': 2, 'sec': '2.1',
  'q': ['רצפת ההפסד, בסימולציה. השלם את <code class="ltr">floor(B, n_combos, trials=200, seed=0)</code>: דוגמת <span class="ltr">trials</span> מנות של B צירופים אקראיים (מתוך <span class="ltr">n_combos</span>), ולכל מנה מחשבת את ההפסד של מודל מושלם — שמחלק את ההסתברות שווה בין הכפילויות: לכל שורה <span class="ltr">ln n</span>, כש־n הוא מספר הפעמים שהצירוף שלה מופיע במנה. מחזירה את הממוצע.',
        '**א.** מה יוצא ל־B = 128 ו־24 צירופים? השווה ל־<span class="ltr">ln(128/24)</span>.', '**ב.** למה הסימולציה גבוהה מעט מההערכה?'],
  'hints': ['<code class="ltr">np.bincount(rng.integers(0, n_combos, B))</code>.', 'כל צירוף שמופיע n פעמים תורם <span class="ltr">n · ln n</span>; מחלקים ב־B.'],
  'sol': ['**א.** כ־1.76 מול 1.67.', '**ב.** ‏<span class="ltr">n · ln n</span> קמורה: מנות לא אחידות (צירוף אחד 11 פעמים, אחר פעמיים) נותנות ממוצע גבוה ממה שמנה אחידה הייתה נותנת. ובאימון האמיתי — קצת נמוך יותר, כי ארבעת הנוסחים מבדילים בין כיתובים של אותו צירוף.'],
  'test': T('השלם את floor.',
            'import numpy as np\n\ndef floor(B, n_combos, trials=200, seed=0):\n    return np.log(B / n_combos)     # TODO: simulate\n',
            "import numpy as np\nf = floor(128, 24)\nassert 1.70 < f < 1.82, f'ל־128 ו־24: כ־1.76; קיבלתי {f:.3f}'\nassert abs(floor(4, 1) - np.log(4)) < 1e-9, 'צירוף אחד במנה של 4: ln 4'\nassert floor(8, 10**9) < 1e-6, 'בלי כפילויות — רצפה אפס'",
            'import numpy as np\n\ndef floor(B, n_combos, trials=200, seed=0):\n    rng = np.random.default_rng(seed); out = []\n    for _ in range(trials):\n        n = np.bincount(rng.integers(0, n_combos, B))\n        n = n[n > 0]\n        out.append((n * np.log(n)).sum() / B)\n    return float(np.mean(out))\n')},
 {'id': '2.9', 'ch': 2, 'level': 3, 'sec': '2.2',
  'q': ['**אתגר — ללמוד את קנה המידה.** מנה קבועה של שיכונים שכבר "למדו" (האלכסון גבוה, אבל לא 1), ופרמטר אחד: <span class="ltr">t = ln s</span>. השלם את <code class="ltr">learn_scale(U, V, t0=np.log(10), lr=0.1, steps=300, t_max=np.log(100))</code>: ירידה בשיפוע על t של ההפסד הניגודי הסימטרי, עם חיתוך ל־<span class="ltr">t_max</span>. מחזירה <span class="ltr">(s, losses)</span>.',
        '**א.** לאן מגיע s, ומה קורה להפסד?', '**ב.** למה מאמנים <span class="ltr">ln s</span> ולא s, ולמה החיתוך ב־100?'],
  'hints': ['<span class="ltr">dLoss/dt = s · Σ(G ⊙ C)</span>, כש־G היא נגזרת ההפסד לפי הציונים (שני הכיוונים, ממוצע) ו־C הקוסינוסים.', 'כיוון טקסט ← תמונה: אותה נוסחה על <span class="ltr">C.T</span>.'],
  'sol': ['**א.** בבדיקה: s עולה מ־10 לכ־83, וההפסד יורד מ־0.33 ל־0.013. כשהאלכסון באמת גבוה מכל השאר, הגדלת s רק מחדדת. אם יש שליליים קשים מעל האלכסון, s מתייצב בערך שבו הוא מאזן בין חידוד הנכונים לענישה על הטעויות.', '**ב.** s חייב להיות חיובי, ו־<span class="ltr">ln s</span> חופשי בכל הממשי — צעד שווה משנה את s ביחס קבוע. החיתוך: s גדול מאוד הופך את ההסתברויות לקשות (0 או 1), השיפועים מתפוצצים או מתאפסים, והאימון לא יציב — בפרק 3 קנה המידה עלה מ־10 ל־15 בשישה סבבים.'],
  'test': T('השלם את learn_scale.',
            'import numpy as np\n\ndef learn_scale(U, V, t0=np.log(10), lr=0.1, steps=300, t_max=np.log(100)):\n    return np.exp(t0), []     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nB, d = 16, 32\nU = rng.normal(size=(B, d)); U /= np.linalg.norm(U, axis=1, keepdims=True)\nV = U + 0.3 * rng.normal(size=(B, d)); V /= np.linalg.norm(V, axis=1, keepdims=True)\ns, losses = learn_scale(U, V)\nassert len(losses) == 300, 'הפסד אחד לכל צעד'\nassert s > 15 and losses[-1] < losses[0], f'קנה המידה צריך לעלות וההפסד לרדת: s={s:.1f}, {losses[0]:.3f} ← {losses[-1]:.3f}'\nassert s <= 100 + 1e-6, 'החיתוך ב־100'",
            'import numpy as np\n\ndef learn_scale(U, V, t0=np.log(10), lr=0.1, steps=300, t_max=np.log(100)):\n    C = U @ V.T; B = len(C); t = t0; losses = []\n    def sm(A):\n        A = A - A.max(1, keepdims=True); E = np.exp(A); return E / E.sum(1, keepdims=True)\n    for _ in range(steps):\n        s = np.exp(t); P1, P2 = sm(s * C), sm(s * C.T); I = np.eye(B)\n        losses.append(float((-np.log(np.diag(P1)).mean() - np.log(np.diag(P2)).mean()) / 2))\n        G = ((P1 - I) + (P2 - I).T) / (2 * B)\n        t = min(t - lr * s * (G * C).sum(), t_max)\n    return float(np.exp(t)), losses\n')},
]

META.update({
 '3.1': (1, '3.3', '**זה חישוב.** **נתון:** המבנה של שני המגדלים. **מה לעשות:** לספור פרמטרים. **איך תדע שהצלחת:** ‏450,848 ו־1,728 — וההדמיה של 3.3 מחשבת אותם לכל גודל.'),
 '3.2': (1, '3.2', '**זו שאלת הבנה.** **נתון:** <code class="ltr">d_word</code> וממד היציאה. **מה לעשות:** להסביר מה חייב להיות שווה ומה לא. **איך תדע שהצלחת:** תצביע על <span class="ltr">W3</span> ועל המכפלה בין המגדלים.'),
 '3.3': (2, '3.2', '**זו שאלת דוגמה נגדית.** **נתון:** מגדל הטקסט של הקורס. **מה לעשות:** שני משפטים שונים עם אותו וקטור, ומה פותר את זה. **איך תדע שהצלחת:** ההדמיה של 3.2 תיתן קוסינוס 1 בדיוק.'),
 '3.4': (3, '3.5', '**זו שאלת הסבר.** **נתון:** הפסד של 2.355 בסבב הראשון. **מה לעשות:** להשוות לניחוש ולהסביר. **איך תדע שהצלחת:** ‏<span class="ltr">ln 128 = 4.852</span>, ותסביר ממוצע על סבב — הגרף בהדמיה של 3.4 מראה אותו.'),
})
X += [
 {'id': '3.5', 'ch': 3, 'level': 1, 'sec': '3.1',
  'q': ['**זו שאלת תכנון ניסוי.** בנתונים יש ארבעה צירופים של צורה וצבע שלא באימון — אחד לכל צורה ואחד לכל צבע.',
        '**א.** למה בחרו בדיוק ארבעה, כך שכל צורה וכל צבע "מאבדים" צירוף אחד בלבד?', '**ב.** מה היה קורה לניסוי אם היו מוציאים את כל המשולשים?', '**ג.** ומה אם היו מוציאים רק תמונות של משולש כחול <i>גדול</i>, ומשאירים קטנים?'],
  'hints': ['מה המודל צריך לראות כדי שתהיה לו בכלל הזדמנות להכליל?', 'בסעיף ג: מה בדיוק נבדק אז?'],
  'sol': ['**א.** כדי שכל מושג לחוד יופיע הרבה באימון — משולש בשלושה צבעים, כחול בשלוש צורות. רק <i>הצירוף</i> חסר. זו בדיקה של הרכבה, לא של מושג חדש.', '**ב.** אז "משולש" היה מילה שהמודל מעולם לא ראה תמונה שלה — שום מודל לא יכול לזהות אותו, והניסוי היה בודק משהו אחר (וחסר תוחלת).', '**ג.** זו בדיקה קלה יותר: המודל ראה משולש כחול, רק בגודל אחר. הצירוף צורה־צבע כבר נלמד, והשאלה הופכת להכללה בגודל — כנראה מצליחה, ולא אומרת כלום על הרכבה.']},
 {'id': '3.6', 'ch': 3, 'level': 2, 'sec': '3.4',
  'q': ['הנגזרת דרך הנרמול — הלב של שני המגדלים. <span class="ltr">u = z / ‖z‖</span>. השלם את <code class="ltr">norm_back(z, du)</code>, שמחזירה <span class="ltr">dz</span> לכל שורה: <span class="ltr">(du − u·(u·du)) / ‖z‖</span>. הבדיקה משווה לנגזרת מספרית — ההרגל של סעיף 3.4.',
        '**א.** למה הנגזרת "מאבדת" את הרכיב שבכיוון של u?', '**ב.** מה קורה לנגזרת כש־‖z‖ קטן מאוד, ולמה זה מסוכן?'],
  'hints': ['<span class="ltr">n = ‖z‖</span> לכל שורה, <span class="ltr">u = z / n</span>.', '<span class="ltr">(u * du).sum(1, keepdims=True)</span>.'],
  'sol': ['**א.** הגדלה של z בכיוון של עצמו לא משנה את u — רק את האורך, שהנרמול מוחק. לכן השיפוע בכיוון הזה אפס.', '**ב.** הנגזרת גדלה כמו <span class="ltr">1/‖z‖</span> — וקטור קרוב לאפס מקבל עדכונים ענקיים ולא יציבים. בפועל זה כמעט לא קורה (ReLU ושכבה ליניארית נותנות וקטורים לא זעירים), אבל מוסיפים <span class="ltr">ε</span> קטן לנורמה במימושים אמיתיים.'],
  'test': T('השלם את norm_back.',
            'import numpy as np\n\ndef norm_back(z, du):\n    return du / np.linalg.norm(z, axis=1, keepdims=True)     # TODO: remove the component along u\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nz = rng.normal(size=(4, 6)); w = rng.normal(size=(4, 6))\nf = lambda z: (w * (z / np.linalg.norm(z, axis=1, keepdims=True))).sum()\nG = norm_back(z, w)\nnum = np.zeros_like(z); h = 1e-6\nfor i in range(4):\n    for j in range(6):\n        E = np.zeros_like(z); E[i, j] = h; num[i, j] = (f(z + E) - f(z - E)) / (2 * h)\nassert np.abs(G - num).max() < 1e-6, f'הנגזרת צריכה להתאים לנגזרת המספרית; הפרש {np.abs(G - num).max():.2e}'\nassert np.allclose((G * z).sum(1), 0), 'אין רכיב בכיוון של z'",
            'import numpy as np\n\ndef norm_back(z, du):\n    n = np.linalg.norm(z, axis=1, keepdims=True); u = z / n\n    return (du - u * (u * du).sum(1, keepdims=True)) / n\n')},
 {'id': '3.7', 'ch': 3, 'level': 2, 'sec': '3.2',
  'q': ['מגדל הטקסט, בלי השכבה הליניארית. השלם את <code class="ltr">bag(E, idx, sentence)</code>: ‏<span class="ltr">E</span> — טבלת שיכונים (שורה 0 = לא מוכר), ‏<span class="ltr">idx</span> — מילון ממילה למספר. מחזירה את ממוצע השורות של מילות המשפט. משפט ריק — וקטור אפסים.',
        '**א.** למה הממוצע (ולא הסכום)?', '**ב.** משפט שכולו מילים לא מוכרות — מה יוצא, ולמה זה מסוכן בחיפוש?'],
  'hints': ['<code class="ltr">[idx.get(w, 0) for w in sentence.split()]</code>.', '<code class="ltr">E[ids].mean(0)</code>.'],
  'sol': ['**א.** כדי שמשפט ארוך לא יקבל וקטור ארוך — אחרי הנרמול זה כמעט לא משנה, אבל לפני השכבה הליניארית זה שומר על סדר גודל קבוע. ובכל זאת, מילים כמו "a photo of" "מדללות" את המשמעות — לכן נוסחים שונים נותנים וקטורים קצת שונים.', '**ב.** השורה 0 בלבד — אותו וקטור לכל משפט לא מוכר. בחיפוש, "purple pentagon" ו־"silver drone" יחזירו בדיוק את אותן תמונות, עם ציון שנראה סביר. במערכת אמיתית מתריעים כשאין אף מילה מוכרת.'],
  'test': T('השלם את bag.',
            'import numpy as np\n\ndef bag(E, idx, sentence):\n    return E[0]     # TODO\n',
            "import numpy as np\nE = np.arange(12.0).reshape(4, 3)\nidx = {'red': 1, 'circle': 2, 'a': 3}\nassert np.allclose(bag(E, idx, 'a red circle'), E[[3, 1, 2]].mean(0)), 'ממוצע השורות של המילים'\nassert np.allclose(bag(E, idx, 'circle red a'), bag(E, idx, 'a red circle')), 'הסדר לא משנה'\nassert np.allclose(bag(E, idx, 'a purple circle'), E[[3, 0, 2]].mean(0)), 'מילה לא מוכרת — שורה 0'\nassert np.allclose(bag(E, idx, ''), 0), 'משפט ריק — אפסים'",
            'import numpy as np\n\ndef bag(E, idx, sentence):\n    ids = [idx.get(w, 0) for w in sentence.split()]\n    return E[ids].mean(0) if ids else np.zeros(E.shape[1])\n')},
 {'id': '3.8', 'ch': 3, 'level': 2, 'sec': '3.5',
  'q': ['המדד שבמקום ההפסד. השלם את <code class="ltr">recall_at_k(U, V, labels, k)</code>: לכל תמונה (שורה ב־<span class="ltr">U</span>), האם בין <span class="ltr">k</span> הכיתובים הקרובים (שורות ב־<span class="ltr">V</span>) יש כיתוב עם <i>אותה תווית</i> — לא בהכרח הכיתוב שלה. מחזירה את השבר.',
        '**א.** למה בודקים "אותה תווית" ולא "אותו אינדקס"?', '**ב.** מה היה יוצא אם היינו בודקים "אותו אינדקס" על מנה עם כפילויות?'],
  'hints': ['<code class="ltr">np.argsort(-(U @ V.T), axis=1)[:, :k]</code>.', 'השווה את התוויות של העמודות שנבחרו לתווית של השורה.'],
  'sol': ['**א.** כי כפילויות הן כיתובים נכונים באותה מידה — "red large circle" של תמונה אחרת מתאר את התמונה הזו בדיוק כמו "שלה".', '**ב.** מדד נמוך באופן מלאכותי — בדיוק כמו ההפסד: המודל היה "נענש" על בחירה בכיתוב נכון של תמונה אחרת. בבדיקה, אותו מודל מקבל 100% בדרך הראשונה ו־10% בשנייה.'],
  'test': T('השלם את recall_at_k.',
            'import numpy as np\n\ndef recall_at_k(U, V, labels, k):\n    top = np.argsort(-(U @ V.T), axis=1)[:, :k]\n    return float(np.mean([i in top[i] for i in range(len(U))]))     # TODO: same label, not same index\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nprotos = rng.normal(size=(4, 8)); labels = list(rng.integers(0, 4, 40))\nU = protos[labels] + 0.05 * rng.normal(size=(40, 8)); V = protos[labels] + 0.05 * rng.normal(size=(40, 8))\nU /= np.linalg.norm(U, axis=1, keepdims=True); V /= np.linalg.norm(V, axis=1, keepdims=True)\nr = recall_at_k(U, V, labels, 1)\nassert r == 1.0, f'כל תמונה מוצאת כיתוב מאותה תווית: 1.0; קיבלתי {r}'\nV2 = V.copy(); V2[:] = V[::-1]; lab2 = labels[::-1]\nassert recall_at_k(U, V, [0] * 40, 1) == 1.0",
            'import numpy as np\n\ndef recall_at_k(U, V, labels, k):\n    top = np.argsort(-(U @ V.T), axis=1)[:, :k]\n    labels = np.asarray(labels)\n    return float(np.mean([(labels[top[i]] == labels[i]).any() for i in range(len(U))]))\n')},
 {'id': '3.9', 'ch': 3, 'level': 3, 'sec': '3.5',
  'q': ['**אתגר — מנות בלי כפילויות.** השלם את <code class="ltr">unique_batches(labels, B, seed=0)</code>: מחזירה רשימה של מנות (רשימות של אינדקסים) שבכל אחת אין שתי דוגמאות עם אותה תווית, וכל אינדקס מופיע לכל היותר פעם אחת. כל מנה בגודל <span class="ltr">min(B, number of labels)</span>.',
        '**א.** מה גודל המנה המקסימלי אצלנו, ומה זה אומר על הרעיון "פשוט לאמן בלי כפילויות"?', '**ב.** מה עושים בנתונים אמיתיים, שבהם "כפילות" היא עניין של מידה?'],
  'hints': ['קבץ את האינדקסים לפי תווית, וערבב כל קבוצה.', 'בכל מנה — אחד מכל אחת מ־B תוויות, שנבחרות מבין התוויות שעוד יש להן דוגמאות.'],
  'sol': ['**א.** 24 — מספר הצירופים. מנה של 24 בלי כפילויות אפשרית, אבל אז יש רק 23 שליליים לכל תמונה, והם קלים. יש מתח בין "שליליים רבים וקשים" (מנה גדולה) לבין "בלי שליליים מדומים". אצלנו הכפילויות לא מזיקות לסיווג — הן רק מציבות רצפה להפסד.', '**ב.** מסננים כפילויות קרובות מראש (לפי דמיון של שיכונים), מורידים משקל לזוגות עם כיתוב זהה, או עוברים להפסד סיגמואידי שבו שלילי מדומה רק מוסיף עונש קטן (פרק 5.2).'],
  'test': T('השלם את unique_batches.',
            'def unique_batches(labels, B, seed=0):\n    return [list(range(i, min(i + B, len(labels)))) for i in range(0, len(labels), B)]     # TODO\n',
            "import random\nrnd = random.Random(1)\nlabels = [rnd.randrange(24) for _ in range(2000)]\nbs = unique_batches(labels, 128)\nassert bs and all(len(b) == 24 for b in bs), f'כל מנה בגודל 24 (מספר התוויות); קיבלתי {set(len(b) for b in bs)}'\nassert all(len({labels[i] for i in b}) == len(b) for b in bs), 'אין שתי דוגמאות עם אותה תווית במנה'\nflat = [i for b in bs for i in b]\nassert len(flat) == len(set(flat)), 'כל אינדקס לכל היותר פעם אחת'\nassert len(bs) >= 60, f'מנצלים את רוב הנתונים; {len(bs)} מנות'",
            'import random\nfrom collections import defaultdict\n\ndef unique_batches(labels, B, seed=0):\n    rnd = random.Random(seed); groups = defaultdict(list)\n    for i, l in enumerate(labels):\n        groups[l].append(i)\n    for g in groups.values():\n        rnd.shuffle(g)\n    size = min(B, len(groups)); out = []\n    while True:\n        alive = [l for l in groups if groups[l]]\n        if len(alive) < size:\n            return out\n        alive.sort(key=lambda l: -len(groups[l]))\n        out.append([groups[l].pop() for l in alive[:size]])\n')},
]

META.update({
 '4.1': (1, '4.2', '**זו שאלת הבנה.** **נתון:** 100% על צבע בצירופים שלא נראו. **מה לעשות:** להסביר למה צבע כן נלמד בנפרד. **איך תדע שהצלחת:** תזכיר שצבע מזוהה מערוץ אחד בכל צורה — וההדמיה של 4.2 מראה "רק צבע" מול "רק צורה".'),
 '4.2': (2, '4.3', '**זו שאלת חיזוי.** **נתון:** מודל הרוויה. **מה לעשות:** לומר מה קורה לצורה לבנה או אפורה. **איך תדע שהצלחת:** תזהה שרוויה אפס = צורה בלתי נראית — וההדמיה של 3.1 (קלט רוויה) מראה למה.'),
 '4.3': (2, '4.2', '**זה קוד קצר.** **נתון:** התחזיות על הצירופים שלא נראו. **מה לעשות:** מטריצת בלבול קטנה לכל צירוף. **איך תדע שהצלחת:** תראה את אותו דפוס כמו בהדמיה של 4.2 — הצבע נשמר, הצורה מתפזרת.'),
 '4.4': (3, '4.4', '**זה תכנון ניסוי.** **נתון:** תמונה עם שתי צורות ושני כיתובים מוחלפים. **מה לעשות:** לנבא מה יעשה המודל שלנו ולמה. **איך תדע שהצלחת:** ‏50% בדיוק — וההדמיה של 4.4 מראה קוסינוס 1 בין שני משפטים כאלה.'),
})
X += [
 {'id': '4.5', 'ch': 4, 'level': 1, 'sec': '4.1',
  'q': ['**חישוב עלות.** סיווג ללא דוגמאות עם 32 מחלקות וארבעה נוסחים, על ארכיון של 100,000 פריימים.',
        '**א.** כמה פעמים מריצים את מגדל הטקסט? ואת מגדל התמונה?', '**ב.** מה הצורה של <span class="ltr">T</span>, ושל מטריצת הציונים?', '**ג.** מוסיפים מחלקה אחת. מה צריך לחשב מחדש?'],
  'hints': ['<span class="ltr">T</span> מחושבת פעם אחת.', 'מחלקה חדשה = שורה חדשה ב־<span class="ltr">T</span>.'],
  'sol': ['**א.** מגדל הטקסט: <span class="ltr">32 · 4 = 128</span> משפטים, פעם אחת. מגדל התמונה: 100,000 פעמים — הוא כל העלות.', '**ב.** ‏<span class="ltr">T</span>: ‏<span class="ltr">(32, 32)</span> — 32 מחלקות × 32 ממדים. הציונים: ‏<span class="ltr">(100000, 32)</span>.', '**ג.** רק ארבעה משפטים — שורה אחת ב־<span class="ltr">T</span>, ומכפלה אחת של כל השיכונים בשורה החדשה. את שיכוני התמונות שומרים — וזה בדיוק האינדקס של פרק 6.']},
 {'id': '4.6', 'ch': 4, 'level': 1, 'sec': '4.3',
  'q': ['**חישוב ביד.** הרוויה של פיקסל ב־<code class="ltr">prep_chroma</code> היא <span class="ltr">max − min</span> על שלושת הערוצים (בטווח 0–1). חשב לכל פיקסל:',
        {'table': [['פיקסל (RGB, ‏0–255)', 'רוויה?'], ['רקע אפור (110, 110, 110)', '?'], ['אדום (220, 40, 40)', '?'], ['כחול (40, 70, 220)', '?'], ['צהוב (230, 210, 40)', '?'], ['לבן (250, 250, 250)', '?']]},
        '**ב.** מה המשמעות לצורה לבנה (תרגיל 4.2)?'],
  'hints': ['<span class="ltr">(max − min) / 255</span>.'],
  'sol': ['אפור — 0; אדום — ‏<span class="ltr">180/255 = 0.71</span>; כחול — ‏0.71; צהוב — ‏<span class="ltr">190/255 = 0.75</span>; לבן — 0. שלושת הצבעים כמעט זהים במפה — זה כל הרעיון.', '**ב.** צורה לבנה היא אפס במפה — בלתי נראית, בדיוק כמו הרקע. רק התמונה הזעירה (8 על 8) יודעת שיש שם משהו בהיר. תכונה שבנינו ביד פתרה בעיה אחת ופתחה נקודה עיוורת.']},
 {'id': '4.7', 'ch': 4, 'level': 2, 'sec': '4.1',
  'q': ['סיווג ללא דוגמאות עם איסוף נוסחים. השלם את <code class="ltr">class_matrix(encode_text, classes, templates)</code>: לכל נוסח — משפט לכל מחלקה ו־<code class="ltr">encode_text</code> (שמחזיר שורות מנורמלות); ממוצע על הנוסחים; <b>ונרמול מחדש</b>. מחזירה מטריצה של שורה לכל מחלקה.',
        '**א.** בבדיקה, מקודד מזויף מחזיר וקטורים שונים לנוסחים שונים. מה אורך השורות לפני הנרמול מחדש?', '**ב.** מתי השמטת הנרמול מחדש משנה את התוצאה?'],
  'hints': ['<code class="ltr">np.stack([encode_text([...]) for t in templates]).mean(0)</code>.', 'נרמל כל שורה.'],
  'sol': ['**א.** פחות מ־1 — ממוצע של וקטורי יחידה שלא מצביעים לאותו כיוון. ככל שהנוסחים שונים יותר, השורה קצרה יותר.', '**ב.** לתמונה אחת ובאותו מספר נוסחים לכל מחלקה — הסדר לא משתנה... כמעט: מחלקות שהנוסחים שלהן "מסכימים" יותר יקבלו שורה ארוכה יותר — ויתרון. וכשמשווים לסף (פרק 6), כל הציונים קטנים מדי.'],
  'test': T('השלם את class_matrix.',
            'import numpy as np\n\ndef class_matrix(encode_text, classes, templates):\n    return encode_text([templates[0].format(c) for c in classes])     # TODO: all templates, mean, renormalize\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nbase = {c: rng.normal(size=8) for c in ['cat', 'dog', 'car']}\ndef enc(sents):\n    out = []\n    for s in sents:\n        c = s.split()[-1]; v = base[c] + 0.8 * np.random.default_rng(abs(hash(s)) % 1000).normal(size=8)\n        out.append(v / np.linalg.norm(v))\n    return np.array(out)\nT_ = class_matrix(enc, ['cat', 'dog', 'car'], ['a photo of a {}', 'a blurry {}', 'one {}'])\nassert T_.shape == (3, 8), f'שורה לכל מחלקה; קיבלתי {T_.shape}'\nassert np.allclose(np.linalg.norm(T_, axis=1), 1), 'נרמול מחדש אחרי הממוצע'\nref = np.stack([enc([t.format(c) for c in ['cat', 'dog', 'car']]) for t in ['a photo of a {}', 'a blurry {}', 'one {}']]).mean(0)\nassert np.allclose(T_, ref / np.linalg.norm(ref, axis=1, keepdims=True)), 'ממוצע על כל הנוסחים'",
            'import numpy as np\n\ndef class_matrix(encode_text, classes, templates):\n    T = np.stack([encode_text([t.format(c) for c in classes]) for t in templates]).mean(0)\n    return T / np.linalg.norm(T, axis=1, keepdims=True)\n')},
 {'id': '4.8', 'ch': 4, 'level': 2, 'sec': '4.3',
  'q': ['למה הרוויה עובדת — במספרים. השלם את <code class="ltr">chroma_map(img)</code> (מפת רוויה של 24 על 24, כמו החלק הראשון של <code class="ltr">prep_chroma</code>). הבדיקה מציירת משולש אדום ומשולש כחול <i>באותו מקום</i>, ומשווה את ההפרש ביניהם בפיקסלים ובמפת הרוויה.',
        '**א.** פי כמה ההפרש קטן במפת הרוויה?', '**ב.** למה כאן הוא אפס, ובנתונים של המודול רק קרוב לאפס?'],
  'hints': ['<span class="ltr">xf = img.astype(np.float32) / 255</span>.', '<code class="ltr">cv2.resize(xf.max(2) - xf.min(2), (24, 24), interpolation=cv2.INTER_AREA)</code>.'],
  'sol': ['**א.** בבדיקה — ההפרש בפיקסלים 0.137 בממוצע, ובמפת הרוויה <b>אפס בדיוק</b>: לשני הצבעים של הבדיקה אותה רוויה, ‏<span class="ltr">180/255</span>.', '**ב.** בבדיקה הוא אפס. בנתונים של המודול הוא קטן אבל לא אפס: הצבע של כל צורה מקבל רעש של ±20, ולצהוב רוויה מעט שונה (0.75). המודל רואה "כמעט אותו דבר", וזה מספיק כדי שגלאי משולש אחד ישרת את כל הצבעים.'],
  'test': T('השלם את chroma_map.',
            'import numpy as np, cv2\n\ndef chroma_map(img):\n    return cv2.resize(img.astype(np.float32) / 255, (24, 24), interpolation=cv2.INTER_AREA).mean(2)     # TODO\n',
            "import numpy as np, cv2\ndef tri(col):\n    im = np.full((32, 32, 3), 110, np.uint8)\n    cv2.fillPoly(im, [np.array([(16, 5), (5, 27), (27, 27)], np.int32)], col)\n    return im\nr, b = tri((40, 40, 220)), tri((220, 70, 40))\nm = chroma_map(r)\nassert m.shape == (24, 24), f'מפה של 24 על 24; קיבלתי {m.shape}'\nassert abs(m[0, 0]) < 1e-6, 'רקע אפור — רוויה אפס'\ndpix = np.abs(r.astype(float) / 255 - b.astype(float) / 255).mean()\ndch = np.abs(chroma_map(r) - chroma_map(b)).mean()\nassert dch < dpix / 10, f'במפת הרוויה ההפרש קטן לפחות פי 10: {dpix:.4f} מול {dch:.4f}'\nprint('pixels %.4f   chroma %.4f   ratio %.0f' % (dpix, dch, dpix / max(dch, 1e-9)))",
            'import numpy as np, cv2\n\ndef chroma_map(img):\n    xf = img.astype(np.float32) / 255\n    return cv2.resize(xf.max(2) - xf.min(2), (24, 24), interpolation=cv2.INTER_AREA)\n')},
 {'id': '4.9', 'ch': 4, 'level': 3, 'sec': '4.4',
  'q': ['**אתגר — לזהות כישלון של הרכבה אוטומטית.** השלם את <code class="ltr">composition_failures(labels, preds, thr=0.5)</code>: ‏<span class="ltr">labels</span> ו־<span class="ltr">preds</span> — רשימות של <span class="ltr">(shape, color)</span>. מחזירה רשימה ממוינת של צירופים שבהם הדיוק המלא מתחת ל־<span class="ltr">thr</span>, <b>אבל</b> הדיוק של הצורה לבדה על כל הנתונים וגם של הצבע לבדו מעל <span class="ltr">thr</span> — כלומר המודל יודע כל מושג לחוד, ונכשל רק בצירוף.',
        '**א.** למה צריך את שני התנאים, ולא רק "דיוק נמוך בצירוף"?', '**ב.** איך תשתמש בזה כתנאי קבלה למטרה חדשה במילים (פרק 10)?'],
  'hints': ['דיוק צורה כללי: על כל הדוגמאות שבהן הצורה האמיתית היא <span class="ltr">sh</span>, כמה פעמים הצורה החזויה נכונה.', 'קבץ לפי צירוף עם <code class="ltr">defaultdict(list)</code>.'],
  'sol': ['**א.** דיוק נמוך בצירוף יכול לנבוע גם ממושג שהמודל לא יודע בכלל (צורה שאף פעם לא זוהתה) — זו בעיה אחרת, עם תיקון אחר (נתונים על המושג). כישלון של הרכבה הוא בדיוק המצב של פרק 4.2: כל מושג מזוהה, והצירוף לא.', '**ב.** לפני שמשתמשים במשפט חדש ("טנדר לבן"), מריצים על סט בדיקה עם התוויות של כל מושג לחוד ושל הצירוף. אם הצירוף מסומן — לא סומכים על המודל הפתוח במטרה הזו: מוסיפים דוגמאות, או מעבירים את המטרה לגלאי סגור (פרק 9).'],
  'test': T('השלם את composition_failures.',
            'def composition_failures(labels, preds, thr=0.5):\n    return []     # TODO\n',
            "import random\nrnd = random.Random(0)\nS, C = ['circle', 'square', 'triangle'], ['red', 'blue', 'green']\nlabels, preds = [], []\nfor _ in range(3000):\n    s, c = rnd.choice(S), rnd.choice(C); labels.append((s, c))\n    if (s, c) == ('triangle', 'blue'):\n        preds.append((rnd.choice(['circle', 'square']), 'blue'))\n    elif s == 'square' and rnd.random() < 0.9:\n        preds.append(('circle', c))\n    else:\n        preds.append((s, c))\nr = composition_failures(labels, preds)\nassert r == [('triangle', 'blue')], f'רק משולש כחול הוא כישלון של הרכבה (ריבוע — המושג עצמו לא נלמד); קיבלתי {r}'",
            'from collections import defaultdict\n\ndef composition_failures(labels, preds, thr=0.5):\n    by_combo, by_shape, by_color = defaultdict(list), defaultdict(list), defaultdict(list)\n    for l, p in zip(labels, preds):\n        by_combo[l].append(l == p); by_shape[l[0]].append(l[0] == p[0]); by_color[l[1]].append(l[1] == p[1])\n    acc = lambda v: sum(v) / len(v)\n    return sorted(k for k, v in by_combo.items()\n                  if acc(v) < thr and acc(by_shape[k[0]]) > thr and acc(by_color[k[1]]) > thr)\n')},
]

META.update({
 '5.1': (1, '5.2', '**זה חישוב.** **נתון:** מנה של 128. **מה לעשות:** לספור תאים חיוביים ושליליים, ודיוק של "לא" על הכול. **איך תדע שהצלחת:** ‏99.2% — ותסביר למה זה מדד חסר ערך.'),
 '5.2': (1, '5.1', '**זה חישוב.** **נתון:** s = 15.6, ‏b = −5.31. **מה לעשות:** מאיזה קוסינוס ההסתברות עוברת חצי. **איך תדע שהצלחת:** ‏0.34 — וההדמיה של 5.1 (כפתור "הערכים שהמודל למד") מסמנת אותו.'),
 '5.3': (2, '5.1', '**זה חישוב והסבר.** **נתון:** ארבעה כיתובים זהים. **מה לעשות:** ההפסד המינימלי, ולמה בטבלה 2.773. **איך תדע שהצלחת:** ‏2.249 מול <span class="ltr">16 · ln 2 / 4</span> — וההדמיה של 5.1 (זוגות זהים) מחשבת את השני.'),
 '5.4': (3, '5.3', '**זה תכנון ניסוי.** **נתון:** התוצאה של מנה 512 עם סיגמואיד. **מה לעשות:** ניסוי שמפריד בין שתי השערות. **איך תדע שהצלחת:** תשווה במספר צעדים — וההדמיה של 5.3 מאפשרת להריץ אותו.'),
})
X += [
 {'id': '5.5', 'ch': 5, 'level': 1, 'sec': '5.2',
  'q': ['**חישוב ביד — "אף אחד מהם".** תמונה ושלושה משפטים, אף אחד לא מתאים. הקוסינוסים: 0.12, ‏0.08, ‏0.05; קנה מידה 15.6, הטיה −5.31.',
        '**א.** מה ההסתברויות בסיווג על השורה (softmax על <span class="ltr">s · cos</span>)?', '**ב.** ובסיגמואיד לכל זוג?', '**ג.** איזה מהשניים מאפשר להחליט "אין כאן אף אחד", ולמה?'],
  'hints': ['ציונים: 1.87, ‏1.25, ‏0.78.', 'סיגמואיד: <span class="ltr">1 / (1 + e^(−(s·cos + b)))</span>.'],
  'sol': ['**א.** בערך 0.53, ‏0.29, ‏0.18 — מסתכם ל־1, ו"הזוכה" מקבל יותר מחצי.', '**ב.** בערך 0.031, ‏0.017, ‏0.011 — כולם נמוכים.', '**ג.** הסיגמואיד: הוא עונה על כל זוג לחוד, ולכן כולם יכולים להיות "לא". הסיווג על השורה חייב לחלק 1 בין המשפטים — הוא אף פעם לא אומר "אף אחד".']},
 {'id': '5.6', 'ch': 5, 'level': 1, 'sec': '5.3',
  'q': ['**קריאת ניסוי.** בטבלה של 5.3, מנה של 512 עם 15 סבבים נותנת לסיגמואיד 83.4% על צירופים שלא נראו. בנתונים יש 20,000 תמונות.',
        '**א.** כמה צעדי עדכון יש ב־15 סבבים, במנה של 128 ובמנה של 512?', '**ב.** כמה סבבים צריך במנה של 512 כדי להשוות במספר צעדים?', '**ג.** במנה של 8 — כמה צעדים, ולמה ייתכן ששם הבעיה היא משהו אחר?'],
  'hints': ['צעדים בסבב: <span class="ltr">⌊20000 / B⌋</span>.', 'במנה של 8 — כמה שליליים יש לכל תמונה?'],
  'sol': ['**א.** 128: ‏<span class="ltr">156 · 15 = 2,340</span>; ‏512: ‏<span class="ltr">39 · 15 = 585</span>.', '**ב.** 60 סבבים (פי 4) — בדיוק תרגיל 5.4.', '**ג.** ‏<span class="ltr">2,500 · 15 = 37,500</span> צעדים — הרבה. שם הבעיה אחרת: רק 7 שליליים לכל תמונה, ורובם קלים — המודל לא מקבל "שאלות קשות". שני ההפסדים חלשים שם.']},
 {'id': '5.7', 'ch': 5, 'level': 2, 'sec': '5.1',
  'q': ['הנגזרת של ההפסד הסיגמואידי — ובדיקה מספרית. השלם את <code class="ltr">sigmoid_grads(C, s, b)</code>: ‏<span class="ltr">C</span> מטריצת הקוסינוסים, וההפסד <span class="ltr">Σ ln(1 + e^(−y·(s·C + b))) / B</span>. מחזירה <span class="ltr">(dC, ds, db)</span>.',
        '**א.** מה הסימן של <span class="ltr">db</span> בתחילת אימון עם <span class="ltr">b = 0</span>, ולמה?', '**ב.** למה ההטיה מתחילה ב־−5 או −10?'],
  'hints': ['לכל תא: <span class="ltr">g = −y · σ(−y·z) / B</span>, עם <span class="ltr">z = s·C + b</span>.', '<span class="ltr">dC = s·g</span>, ‏<span class="ltr">ds = Σ g·C</span>, ‏<span class="ltr">db = Σ g</span>.'],
  'sol': ['**א.** חיובי — כלומר הירידה בשיפוע <i>מקטינה</i> את b. עם b = 0 כל תא מקבל הסתברות חצי; יש פי B יותר שליליים, והם דוחפים את ההטיה למטה.', '**ב.** כדי שהמודל לא יבזבז את הצעדים הראשונים על הזזת ההטיה: מתחילים קרוב למקום שבו היא תהיה ממילא.'],
  'test': T('השלם את sigmoid_grads.',
            'import numpy as np\n\ndef sigmoid_grads(C, s, b):\n    return np.zeros_like(C), 0.0, 0.0     # TODO\n',
            "import numpy as np\ndef loss(C, s, b):\n    Y = 2 * np.eye(len(C)) - 1; return np.logaddexp(0, -Y * (s * C + b)).sum() / len(C)\nrng = np.random.default_rng(0)\nC = np.tanh(rng.normal(size=(5, 5))); s, b = 7.0, -3.0\ndC, ds, db = sigmoid_grads(C, s, b)\nh = 1e-6\nnum = np.zeros_like(C)\nfor i in range(5):\n    for j in range(5):\n        E = np.zeros_like(C); E[i, j] = h; num[i, j] = (loss(C + E, s, b) - loss(C - E, s, b)) / (2 * h)\nassert np.abs(dC - num).max() < 1e-6, 'dC לא מתאים לנגזרת המספרית'\nassert abs(ds - (loss(C, s + h, b) - loss(C, s - h, b)) / (2 * h)) < 1e-6, 'ds'\nassert abs(db - (loss(C, s, b + h) - loss(C, s, b - h)) / (2 * h)) < 1e-6, 'db'\nassert sigmoid_grads(np.zeros((8, 8)), 10, 0.0)[2] > 0, 'עם b = 0, הנגזרת לפי b חיובית'",
            'import numpy as np\n\ndef sigmoid_grads(C, s, b):\n    B = len(C); Y = 2 * np.eye(B) - 1; Z = s * C + b\n    g = -Y / (1 + np.exp(Y * Z)) / B\n    return s * g, float((g * C).sum()), float(g.sum())\n')},
 {'id': '5.8', 'ch': 5, 'level': 2, 'sec': '5.2',
  'q': ['למה אפשר לחשב את ההפסד הסיגמואידי במקטעים — בקוד. השלם את <code class="ltr">chunked_sigmoid_loss(U, V, s, b, k)</code>: מחשבת את אותו הפסד כמו <code class="ltr">sigmoid_loss</code> של הסעיף, אבל בלי לבנות את כל המטריצה — רק מקטעים של <span class="ltr">k</span> שורות של U מול <span class="ltr">k</span> שורות של V בכל פעם.',
        '**א.** למה אי אפשר לעשות את אותו הדבר בהפסד הניגודי?', '**ב.** מה הזיכרון המרבי שהגרסה שלך צריכה לציונים?'],
  'hints': ['לולאה כפולה על מקטעים; בכל מקטע — התוויות הן 1 רק אם השורה והעמודה הן אותו אינדקס.', '<span class="ltr">Y = np.where(i_idx[:, None] == j_idx[None, :], 1, -1)</span>.'],
  'sol': ['**א.** בהפסד הניגודי, כל תא נכנס למכנה של השורה שלו — צריך את <i>כל</i> השורה לפני שאפשר לחשב את ההסתברות של התא. אפשר לצבור מכנים במקטעים (כמו במימושים יעילים של קשב), אבל זה דורש שני מעברים ותקשורת של סכומים; בסיגמואיד כל תא נגמר בעצמו.', '**ב.** ‏<span class="ltr">k × k</span> — במקום <span class="ltr">B × B</span>. עם B של 32,000 ו־k של 1,000: פי אלף פחות.'],
  'test': T('השלם את chunked_sigmoid_loss.',
            'import numpy as np\n\ndef chunked_sigmoid_loss(U, V, s, b, k):\n    Z = s * U @ V.T + b     # TODO: no full matrix\n    Y = 2 * np.eye(len(U)) - 1\n    return np.logaddexp(0, -Y * Z).sum() / len(U)\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nU = rng.normal(size=(40, 8)); U /= np.linalg.norm(U, axis=1, keepdims=True)\nV = U + 0.3 * rng.normal(size=(40, 8)); V /= np.linalg.norm(V, axis=1, keepdims=True)\nY = 2 * np.eye(40) - 1; ref = np.logaddexp(0, -Y * (10 * U @ V.T - 5)).sum() / 40\nfor k in (1, 7, 40):\n    got = chunked_sigmoid_loss(U, V, 10, -5, k)\n    assert abs(got - ref) < 1e-9, f'מקטעים של {k}: {got} מול {ref}'\nimport inspect\nsrc = inspect.getsource(chunked_sigmoid_loss)\nassert 'U @ V.T' not in src.replace(' ', '').replace('U@V.T', 'U @ V.T') or 'for' in src, 'בלי לבנות את כל המטריצה'",
            'import numpy as np\n\ndef chunked_sigmoid_loss(U, V, s, b, k):\n    B = len(U); total = 0.0\n    for i0 in range(0, B, k):\n        for j0 in range(0, B, k):\n            i = np.arange(i0, min(i0 + k, B)); j = np.arange(j0, min(j0 + k, B))\n            Z = s * U[i] @ V[j].T + b\n            Y = np.where(i[:, None] == j[None, :], 1, -1)\n            total += np.logaddexp(0, -Y * Z).sum()\n    return total / B\n')},
 {'id': '5.9', 'ch': 5, 'level': 3, 'sec': '5.1',
  'q': ['**אתגר — תרגיל 5.3 במספרים.** כשכל B הכיתובים בשורה זהים, המודל יכול רק לתת לכל התאים אותה הסתברות p. השלם את <code class="ltr">best_p(B)</code> — מחשבת את ההפסד <span class="ltr">L(p) = −[B · ln p + (B² − B) · ln(1 − p)] / B</span> על רשת דקה של p, ומחזירה <span class="ltr">(p*, L(p*))</span>. ואת <code class="ltr">loss_at_half(B)</code> — ההפסד כש־<span class="ltr">p = 0.5</span>.',
        '**א.** מה יוצא ל־B = 4? השווה ל־2.249 ול־2.773.', '**ב.** מה p* באופן כללי, ולמה?', '**ג.** למה זה הסבר טוב לבחירת ההטיה ההתחלתית?'],
  'hints': ['<code class="ltr">ps = np.linspace(1e-4, 1 - 1e-4, 100001)</code>.', 'ב־<span class="ltr">p = 0.5</span>: <span class="ltr">B² · ln 2 / B</span>.'],
  'sol': ['**א.** ‏<span class="ltr">p* = 0.25</span>, ‏<span class="ltr">L = 2.249</span>; וב־0.5: ‏<span class="ltr">4 · ln 2 = 2.773</span> — שתי השורות של התרגיל.', '**ב.** ‏<span class="ltr">p* = 1/B</span> — שיעור החיוביים בשורה. כשאי אפשר להבדיל בין התאים, ההסתברות הטובה ביותר היא השכיחות.', '**ג.** במנה אמיתית שיעור החיוביים הוא <span class="ltr">1/B</span> — קטן. הסתברות התחלתית של <span class="ltr">σ(b) ≈ 1/B</span> פירושה <span class="ltr">b ≈ −ln B</span>: ל־B של כמה אלפים — בערך −8 עד −10. בדיוק הבחירה של המאמר.'],
  'test': T('השלם את best_p ואת loss_at_half.',
            'import numpy as np\n\ndef best_p(B):\n    return 0.5, 0.0     # TODO\n\ndef loss_at_half(B):\n    return 0.0     # TODO\n',
            "import numpy as np\np, L = best_p(4)\nassert abs(p - 0.25) < 1e-3 and abs(L - 2.249) < 1e-3, f'ל־B = 4: p = 0.25, L = 2.249; קיבלתי {p:.4f}, {L:.4f}'\nassert abs(loss_at_half(4) - 2.773) < 1e-3, 'ב־p = 0.5: 2.773'\nassert abs(best_p(32)[0] - 1 / 32) < 1e-3, 'p* = 1/B'",
            'import numpy as np\n\ndef best_p(B):\n    ps = np.linspace(1e-4, 1 - 1e-4, 100001)\n    L = -(B * np.log(ps) + (B * B - B) * np.log(1 - ps)) / B\n    i = L.argmin()\n    return float(ps[i]), float(L[i])\n\ndef loss_at_half(B):\n    return B * B * np.log(2) / B\n')},
]

META.update({
 '6.1': (1, '6.5', '**זה חישוב.** **נתון:** 10 שעות, פריים לשנייה, 768 ממדים. **מה לעשות:** זיכרון ב־32 וב־16 סיביות. **איך תדע שהצלחת:** ‏110.6 ו־55.3 MB — המחשבון של 6.5 נותן אותם.'),
 '6.2': (2, '6.3', '**זה קוד קצר.** **נתון:** <code class="ltr">search</code> ומערך זמנים. **מה לעשות:** סינון לטווח זמנים. **איך תדע שהצלחת:** מסכה של <span class="ltr">−inf</span> לפני המיון.'),
 '6.3': (2, '6.5', '**זו שאלת תכנון.** **נתון:** עשרה פריימים רצופים מאותה סצנה. **מה לעשות:** להציע שיפור. **איך תדע שהצלחת:** דיכוי שכנים בזמן — ותרגיל 6.7 מממש אותו.'),
 '6.4': (3, '6.4', '**זו שאלת תכנון.** **נתון:** כיסוי של 57.6% בסף 0.5. **מה לעשות:** שיטת כיול עם מעט תיוג, והסיכון בה. **איך תדע שהצלחת:** תזכיר רעש של סף על מעט דוגמאות — וההדמיה של 6.4 מראה כמה הסף הנכון משתנה בין מטרות.'),
})
X += [
 {'id': '6.5', 'ch': 6, 'level': 1, 'sec': '6.1',
  'q': ['**זו שאלת בחירה.** לכל מערכת — איזה מודל מהטבלה של 6.1, ולמה?',
        {'table': [['מערכת', 'מודל?'], ['חיפוש בארכיון של צוות שמחפש באנגלית, בשרת עם כרטיס חזק', '?'], ['התראה בזמן אמת על "רכב חשוד" לפי משפט בעברית, על מחשב קצה', '?'], ['מחקר שחייב לדעת על אילו נתונים המודל אומן', '?']]}],
  'hints': ['מה חשוב בכל שורה: שפה, סף, גודל, שקיפות?'],
  'sol': ['ארכיון באנגלית בשרת — כל אחד יעבוד, כי דירוג לא צריך סף; SigLIP או SigLIP 2 (מדויקים יותר בגדלים דומים), ואפשר מודל גדול. התראה בעברית על מחשב קצה — SigLIP 2 בסיסי: סיגמואידי (סף), רב־לשוני (בלי תרגום), וקטן. מחקר עם נתונים ידועים — OpenCLIP, שאומן על נתונים פתוחים.']},
 {'id': '6.6', 'ch': 6, 'level': 1, 'sec': '6.2',
  'q': ['**זו שאלת חיזוי.** הרצת את הקוד של 6.2 ויצא <span class="ltr">[[0.083, 0.0004]]</span>.',
        '**א.** האם יש בתמונה טנדר לבן? מה אתה יכול לומר בביטחון, ומה לא?', '**ב.** חבר החליף את <code class="ltr">torch.sigmoid</code> ב־<code class="ltr">softmax</code> על השורה. מה ייצא, ומה הלך לאיבוד?', '**ג.** חבר אחר הוריד את <code class="ltr">padding="max_length"</code>. למה זה מסוכן אם אין שגיאה?'],
  'hints': ['השווה את שני הערכים זה לזה, לא לחצי.', 'softmax על שני ציונים — תמיד מסתכם ל־1.'],
  'sol': ['**א.** המשפט הראשון קרוב לתמונה הרבה יותר מהשני (פי 200 בהסתברות) — כנראה יש טנדר לבן. אבל 0.083 לבד לא אומר "8% ביטחון": ההסתברויות במודלי הבסיס קטנות גם כשהם צודקים. החלטה דורשת סף שכויל על הנתונים שלכם.', '**ב.** משהו כמו <span class="ltr">[0.995, 0.005]</span> — נראה בטוח מאוד, אבל רק "יחסית למשפט השני". אם אף משפט לא מתאים — softmax עדיין ייתן לאחד מהם הסתברות גבוהה. הלך לאיבוד הציון המוחלט — כל היתרון של SigLIP.', '**ג.** המודל אומן על טקסט מרופד ל־64; קלט באורך אחר הוא קלט שהוא לא ראה. הציונים זזים בשקט — בדיוק סוג הבאג של "המזהה מוצא פחות אחרי ייצוא" במודול 6. מאמתים מול דוגמה עם תוצאה ידועה.']},
 {'id': '6.7', 'ch': 6, 'level': 2, 'sec': '6.5',
  'q': ['תרגיל 6.3 בקוד: דיכוי שכנים בזמן. השלם את <code class="ltr">temporal_nms(scores, times, gap, k)</code>: עוברת על הפריימים מהציון הגבוה לנמוך, ובוחרת פריים רק אם אין פריים שכבר נבחר במרחק של פחות מ־<span class="ltr">gap</span> שניות. עוצרת אחרי <span class="ltr">k</span>. מחזירה את האינדקסים שנבחרו, לפי הסדר.',
        '**א.** במה זה דומה ל־NMS של מודול 4, ובמה שונה?', '**ב.** איך תבחר את <span class="ltr">gap</span>?'],
  'hints': ['<code class="ltr">for i in np.argsort(-scores):</code>.', 'בדוק <code class="ltr">all(abs(times[i] - times[j]) >= gap for j in chosen)</code>.'],
  'sol': ['**א.** אותו אלגוריתם חמדני — מהגבוה לנמוך, ודילוג על מה שחופף לנבחר. רק ש"חפיפה" כאן היא מרחק בזמן, לא IoU של קופסאות.', '**ב.** לפי אורך אירוע טיפוסי: אם משאית עוברת בפריים במשך עשר שניות — ‏<span class="ltr">gap</span> של עשר עד עשרים שניות. ובארכיון של כמה קבצים — המרחק נמדד רק בתוך אותו קובץ.'],
  'test': T('השלם את temporal_nms.',
            'import numpy as np\n\ndef temporal_nms(scores, times, gap, k):\n    return list(np.argsort(-scores)[:k])     # TODO: suppress neighbours in time\n',
            "import numpy as np\ntimes = np.arange(100.0)\nscores = np.zeros(100); scores[40:46] = [0.9, 0.95, 0.93, 0.91, 0.8, 0.7]; scores[10] = 0.85; scores[80:83] = [0.6, 0.65, 0.62]\nr = temporal_nms(scores, times, 10, 3)\nassert [int(i) for i in r] == [41, 10, 81], f'שלושה אירועים שונים: 41, 10, 81; קיבלתי {list(r)}'\nassert len(temporal_nms(scores, times, 0.5, 5)) == 5, 'עם מרווח קטן — חמישה פריימים'",
            'import numpy as np\n\ndef temporal_nms(scores, times, gap, k):\n    chosen = []\n    for i in np.argsort(-scores):\n        if all(abs(times[i] - times[j]) >= gap for j in chosen):\n            chosen.append(int(i))\n            if len(chosen) == k:\n                break\n    return chosen\n')},
 {'id': '6.8', 'ch': 6, 'level': 2, 'sec': '6.4',
  'q': ['כיול סף למטרה חדשה. השלם את <code class="ltr">pick_threshold(probs, labels, min_precision)</code>: מבין הספים האפשריים (ערכי <span class="ltr">probs</span> עצמם), מחזירה את <i>הנמוך ביותר</i> שבו הדיוק (מבין <span class="ltr">probs ≥ t</span>) לפחות <span class="ltr">min_precision</span> — כלומר הכיסוי הגבוה ביותר שעומד בדרישת הדיוק. אם אין כזה — <span class="ltr">None</span>.',
        '**א.** למה הנמוך ביותר?', '**ב.** בבדיקה, מכיילים על 50 דוגמאות ובודקים על 2,000. מה קורה לדיוק, ולמה משאירים מרווח?'],
  'hints': ['מיין את ההסתברויות מהגבוהה לנמוכה; דיוק מצטבר = <code class="ltr">np.cumsum(labels_sorted) / np.arange(1, n + 1)</code>.', 'הסף הוא ההסתברות במקום האחרון שבו הדיוק עדיין מספיק.'],
  'sol': ['**א.** סף נמוך = יותר פריימים נבחרים = כיסוי גבוה. מבין כל הספים שעומדים בדיוק — רוצים את זה שמפספס הכי מעט.', '**ב.** בבדיקה (זרע 0): דרשנו 95% על 50 דוגמאות, וקיבלנו 89.4% על 2,000 האחרות. סף שנבחר על מעט דוגמאות "מתאים את עצמו" אליהן — במיוחד הנמוך ביותר, שנקבע לפי דוגמה אחת. (בזרעים אחרים יצא 100% — וזה בדיוק הרעש.) לכן דורשים בכיול דיוק גבוה מהנדרש (מרווח), ומכיילים מחדש כשמצטברות תוויות.'],
  'test': T('השלם את pick_threshold.',
            'import numpy as np\n\ndef pick_threshold(probs, labels, min_precision):\n    return 0.5     # TODO\n',
            "import numpy as np\nprobs = np.array([0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3]); labels = np.array([1, 1, 0, 1, 1, 0, 0])\nassert pick_threshold(probs, labels, 0.8) == 0.5, f'בסף 0.5 הדיוק 4/5 = 0.8 — הנמוך ביותר שעומד; קיבלתי {pick_threshold(probs, labels, 0.8)}'\nassert pick_threshold(probs, labels, 1.0) == 0.8\nassert pick_threshold(np.array([0.9, 0.8]), np.array([0, 0]), 0.5) is None, 'אין סף שעומד בדרישה'\nrng = np.random.default_rng(0)\ny = rng.random(2050) < 0.3; p = np.clip(0.25 * y + 0.5 * rng.random(2050), 0, 1)\nt = pick_threshold(p[:50], y[:50], 0.95)\nprec = y[50:][p[50:] >= t].mean()\nprint('threshold %.3f   precision on the other 2,000: %.3f' % (t, prec))",
            'import numpy as np\n\ndef pick_threshold(probs, labels, min_precision):\n    o = np.argsort(-probs); p, y = probs[o], np.asarray(labels)[o]\n    prec = np.cumsum(y) / np.arange(1, len(y) + 1)\n    ok = np.where(prec >= min_precision)[0]\n    return float(p[ok[-1]]) if len(ok) else None\n')},
 {'id': '6.9', 'ch': 6, 'level': 3, 'sec': '6.4',
  'q': ['**אתגר — להוריד את מה שמשותף לכל השאילתות.** בשיכון של משפט יש חלק "כללי" — כיוון שמשותף לכל משפט כמו "a photo of ..." — ובשיכון של כל תמונה יש רכיב באותו כיוון. החלק הזה מוסיף לכל הציונים של שאילתה היסט שתלוי בשאילתה. הרעיון של שאילתת רקע: לקודד משפט כללי (<span class="ltr">bg</span>, למשל "a photo"), ולהוריד מהשאילתה את הרכיב שלה בכיוון שלו. השלם את <code class="ltr">best_f1_threshold(scores, labels)</code> (הסף עם F1 מרבי) ואת <code class="ltr">relative(index, q, bg)</code> — הציונים מול <span class="ltr">q − (q·bg)·bg</span>.',
        '**א.** בבדיקה יש שתי שאילתות עם רכיב כללי שונה. כמה רחוקים הספים הטובים שלהן בציונים הגולמיים, וכמה ביחסיים?', '**ב.** מתי הטריק הזה לא יעזור?'],
  'hints': ['F1 לכל סף: <span class="ltr">2·tp / (2·tp + fp + fn)</span>; עבור על הציונים עצמם כספים.', '<span class="ltr">q2 = q − (q @ bg) * bg</span>, ואז <span class="ltr">index @ q2</span>.'],
  'sol': ['**א.** בבדיקה, בציונים הגולמיים הספים רחוקים — בערך ההפרש בין הרכיבים הכלליים של השאילתות; ביחסיים הם כמעט זהים. סף אחד מתאים לשתיהן.', '**ב.** כשההבדל בין השאילתות הוא לא היסט אלא "חדות" (שאילתה אחת מפרידה טוב ואחרת לא), או כשהכיוון הכללי עצמו נושא מידע שימושי לשאילתה. ותמיד: מאמתים על הנתונים שלכם — הטריק מקטין את הבעיה, לא מבטל את הצורך בכיול.'],
  'test': T('השלם את best_f1_threshold ואת relative.',
            'import numpy as np\n\ndef best_f1_threshold(scores, labels):\n    return 0.0     # TODO\n\ndef relative(index, q, bg):\n    return index @ q     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nn, d = 3000, 16\nbg = rng.normal(size=d); bg /= np.linalg.norm(bg)\nths = []\nfor off in (0.2, 1.2):\n    t = rng.normal(size=d); t -= (t @ bg) * bg; t /= np.linalg.norm(t)\n    q = t + off * bg\n    index = 0.3 * rng.normal(size=(n, d)) + 1.0 * bg\n    y = rng.random(n) < 0.2; index[y] += 0.8 * t\n    ths.append((best_f1_threshold(index @ q, y), best_f1_threshold(relative(index, q, bg), y)))\nraw_gap, rel_gap = abs(ths[0][0] - ths[1][0]), abs(ths[0][1] - ths[1][1])\nassert raw_gap > 0.5 and rel_gap < raw_gap / 4, f'הספים היחסיים צריכים להיות קרובים בהרבה: {ths}'\nprint('raw thresholds %.3f / %.3f    relative %.3f / %.3f' % (ths[0][0], ths[1][0], ths[0][1], ths[1][1]))",
            'import numpy as np\n\ndef best_f1_threshold(scores, labels):\n    o = np.argsort(-scores); s, y = scores[o], np.asarray(labels)[o]\n    tp = np.cumsum(y); fp = np.cumsum(~y); fn = y.sum() - tp\n    f1 = 2 * tp / (2 * tp + fp + fn)\n    return float(s[f1.argmax()])\n\ndef relative(index, q, bg):\n    return index @ (q - (q @ bg) * bg)\n')},
]

META.update({
 '7.1': (1, '7.1', '**זו שאלת הבנה.** **נתון:** הצעות לפי רוויה. **מה לעשות:** שתי דוגמאות לעצמים שיפוספסו. **איך תדע שהצלחת:** תזכיר עצם לא רווי, ועצמים שנבלעים או מתפרקים — וגם שכיסוי ההצעות הוא תקרה למזהה.'),
 '7.2': (2, '7.2', '**זה קוד קצר.** **נתון:** ציונים ותיוג של 50 חיתוכים. **מה לעשות:** הסף שממקסם F1. **איך תדע שהצלחת:** הפונקציה עוברת על הציונים עצמם כספים — ותרגיל 7.9 מראה למה הקצה שהיא בוחרת מסוכן.'),
 '7.3': (1, '7.4', '**זו שאלת הבנה.** **נתון:** ‏YOLO-World שומר תיאורים מקודדים. **מה לעשות:** להסביר למה Grounding DINO לא יכול. **איך תדע שהצלחת:** תזכיר שהטקסט משפיע על עיבוד התמונה.'),
 '7.4': (3, '7.1', '**זו שאלת תכנון.** **נתון:** דיוק נמוך על עצמים קטנים. **מה לעשות:** שינוי בחיתוך, ומה הוא מקלקל. **איך תדע שהצלחת:** תזכיר שהמודל שלנו לומד "גודל" ממספר הפיקסלים.'),
})
X += [
 # ------------------------------------------------ chapter 7
 {'id': '7.5', 'ch': 7, 'level': 1, 'sec': '7.3',
  'q': ['**זו שאלת חיזוי.** לכל מצב — האם YOLO-World ירוץ בערך במהירות של YOLO רגיל? הסבר במשפט.',
        {'table': [['מצב', 'מהיר כמו YOLO?'], ['רשימה קבועה של 3 תיאורים, כל המשמרת', '?'], ['רשימה של 80 תיאורים, קבועה', '?'], ['המפעיל מוסיף תיאור פעם בעשר דקות', '?'], ['הקוד קורא ל־<code class="ltr">set_classes</code> בתוך הלולאה על הפריימים', '?'], ['מודל שיוצא ל־ONNX אחרי <code class="ltr">set_classes</code>, ורץ על מחשב הקצה', '?']]}],
  'hints': ['מתי רץ מקודד הטקסט?', 'מה נשמר בתוך המודל אחרי <code class="ltr">set_classes</code>?'],
  'sol': ['שלושה תיאורים קבועים — כן: קידוד אחד בתחילת המשמרת. ‏80 קבועים — כן: עוד עמודות בשכבה האחרונה, מכפלה קטנה. תיאור חדש פעם בעשר דקות — כן: קידוד של מילישניות פעם בעשר דקות. ‏<code class="ltr">set_classes</code> בלולאה — לא: מקודד הטקסט רץ בכל פריים, וזו בדיוק העלות שהמודל נבנה כדי לחסוך. ‏ONNX אחרי <code class="ltr">set_classes</code> — כן, ואפילו בלי מקודד טקסט על המחשב; אבל כדי להוסיף תיאור צריך לייצא מחדש (או להעביר את השיכונים כקלט נפרד).']},
 {'id': '7.6', 'ch': 7, 'level': 2, 'sec': '7.1',
  'q': ['מדידה של השלב הראשון לבד. השלם את <code class="ltr">iou(a, b)</code> למלבנים בצורה <span class="ltr">(x0, y0, x1, y1)</span>, ואת <code class="ltr">proposal_recall(proposals, truth, thr)</code>: החלק של המלבנים האמיתיים ב־<span class="ltr">truth</span> שיש להם לפחות הצעה אחת עם IoU מעל <span class="ltr">thr</span>.',
        '**א.** בקורס יצא 100%. מה זה אומר על הכיסוי של המזהה כולו?', '**ב.** למה לא מספיק למדוד רק את המזהה כולו?'],
  'hints': ['חיתוך: <span class="ltr">max(0, min(a[2], b[2]) − max(a[0], b[0]))</span> ברוחב, וכך גם בגובה.', 'לכל מלבן אמיתי: <code class="ltr">any(iou(p, t) > thr for p in proposals)</code>.'],
  'sol': ['**א.** כלום לבד — רק שהשלב הראשון לא מגביל אותו. הכיסוי של המזהה הוא לכל היותר כיסוי ההצעות, ובפועל כפול דיוק הסיווג על מה שהוצע.', '**ב.** כשהמזהה מפספס, צריך לדעת אם העצם לא הוצע (לתקן את ההצעות — סף, מציע נלמד) או שהוצע וסווג לא נכון (לתקן את המסווג — רזולוציה, חיתוך). מדד אחד מערבב את שתי התקלות.'],
  'test': T('השלם את iou ואת proposal_recall.',
            'def iou(a, b):\n    return 0.0     # TODO\n\ndef proposal_recall(proposals, truth, thr=0.5):\n    return 0.0     # TODO\n',
            "assert abs(iou((0, 0, 10, 10), (5, 0, 15, 10)) - 1 / 3) < 1e-9, f'חצי חפיפה ברוחב — IoU של שליש; קיבלתי {iou((0, 0, 10, 10), (5, 0, 15, 10))}'\nassert iou((0, 0, 10, 10), (20, 20, 30, 30)) == 0, 'בלי חפיפה — אפס, ולא מספר שלילי'\nassert iou((0, 0, 10, 10), (0, 0, 10, 10)) == 1\ntruth = [(0, 0, 10, 10), (50, 50, 60, 60), (100, 100, 110, 110)]\nprops = [(1, 0, 11, 10), (52, 52, 66, 66)]\nr = proposal_recall(props, truth, 0.5)\nassert abs(r - 1 / 3) < 1e-9, f'רק המלבן הראשון מכוסה (השני ב־IoU של כ־0.3); קיבלתי {r}'\nassert abs(proposal_recall(props, truth, 0.2) - 2 / 3) < 1e-9",
            'def iou(a, b):\n    ix = max(0, min(a[2], b[2]) - max(a[0], b[0]))\n    iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))\n    inter = ix * iy\n    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter\n    return inter / union\n\ndef proposal_recall(proposals, truth, thr=0.5):\n    hit = sum(any(iou(p, t) > thr for p in proposals) for t in truth)\n    return hit / len(truth)\n')},
 {'id': '7.7', 'ch': 7, 'level': 2, 'sec': '7.2',
  'q': ['הדיוק הממוצע של הטבלה ב־7.2. השלם את <code class="ltr">average_precision(prob, truth)</code>: ממיינים מהגבוה לנמוך, ובכל מקום שבו יש מטרה מחשבים את הדיוק עד אליו (מטרות עד כאן חלקי המקום). AP הוא הממוצע של הדיוקים האלה על כל המטרות.',
        '**א.** מה ה־AP אם כל המטרות בראש? ואם הן מפוזרות באקראי בין <span class="ltr">N</span> חיתוכים עם <span class="ltr">P</span> מטרות?', '**ב.** למה AP לא משתנה אם מכפילים את כל ההסתברויות ב־0.1 — ומה זה אומר על בעיית הסף?'],
  'hints': ['<code class="ltr">o = np.argsort(-prob); y = truth[o]</code>.', '<code class="ltr">np.cumsum(y) / np.arange(1, len(y) + 1)</code> — ואז ממוצע רק במקומות שבהם <span class="ltr">y</span> אמת.'],
  'sol': ['**א.** כל המטרות בראש — 1. באקראי — בערך <span class="ltr">P / N</span>, שיעור המטרות (בבדיקה: כ־0.1 עם 10% מטרות).', '**ב.** הכפלה בקבוע חיובי לא משנה סדר, ו־AP תלוי רק בסדר. לכן AP של 1.000 יכול לחיות לצד הסתברויות של 0.1 על כל המטרות — הדירוג מושלם, והסף של 0.5 לא מוצא כלום. זו בדיוק התמונה של 7.2.'],
  'test': T('השלם את average_precision.',
            'import numpy as np\n\ndef average_precision(prob, truth):\n    return float(np.mean(truth))     # TODO\n',
            "import numpy as np\nassert average_precision(np.array([0.9, 0.8, 0.1, 0.05]), np.array([True, True, False, False])) == 1.0, 'כל המטרות בראש — AP של 1'\nap = average_precision(np.array([0.9, 0.8, 0.7, 0.6]), np.array([False, True, False, True]))\nassert abs(ap - (1 / 2 + 2 / 4) / 2) < 1e-9, f'מטרות במקומות 2 ו־4: (1/2 + 2/4) / 2 = 0.5; קיבלתי {ap}'\nrng = np.random.default_rng(0)\nt = rng.random(5000) < 0.1; p = rng.random(5000)\nassert abs(average_precision(p, t) - t.mean()) < 0.03, 'באקראי — בערך שיעור המטרות'\nassert abs(average_precision(0.1 * p, t) - average_precision(p, t)) < 1e-12, 'AP תלוי רק בסדר'",
            'import numpy as np\n\ndef average_precision(prob, truth):\n    o = np.argsort(-prob)\n    y = np.asarray(truth)[o]\n    prec = np.cumsum(y) / np.arange(1, len(y) + 1)\n    return float(prec[y].mean())\n')},
 {'id': '7.8', 'ch': 7, 'level': 2, 'sec': '7.1',
  'q': ['החיתוך של 7.1 בלי לרפד את כל התמונה. השלם את <code class="ltr">reflect_crop(img, cx, cy, size)</code>: חיתוך של <span class="ltr">size × size</span> שמרכזו <span class="ltr">(cx, cy)</span>, כשפיקסלים מחוץ לתמונה נלקחים בשיקוף — בדיוק כמו <code class="ltr">cv2.BORDER_REFLECT</code> (‏<span class="ltr">−1 → 0, −2 → 1, W → W−1</span>).',
        '**א.** למה הקוד של הקורס מרפד את כל התמונה פעם אחת, ובכל זאת כדאי להכיר את הדרך הזו?', '**ב.** מה היה קורה למסווג אילו ריפדנו באפס (שחור)?'],
  'hints': ['אינדקסים: <code class="ltr">xs = np.arange(cx - size // 2, cx - size // 2 + size)</code>.', 'שיקוף: <span class="ltr">x &lt; 0 → −x − 1</span>, ‏<span class="ltr">x ≥ W → 2W − x − 1</span>; ואז <code class="ltr">img[ys][:, xs]</code>.'],
  'sol': ['**א.** ריפוד אחד של תמונה קטנה זול ופשוט. אבל בפריים של 4K עם עשרות הצעות, העתקה של כל התמונה רק בשביל השוליים מיותרת — מספיק לחשב אינדקסים לכל חיתוך.', '**ב.** פס שחור הוא משהו שהמודל לא ראה באימון — "קלט מחוץ להתפלגות". בחיתוכים ליד השוליים הוא עלול להשפיע על השיכון: הריבוע השחור יכול להיראות כחלק מהצורה. שיקוף שומר על מרקם של רקע.'],
  'test': T('השלם את reflect_crop.',
            'import numpy as np\n\ndef reflect_crop(img, cx, cy, size):\n    h = size // 2\n    return img[max(cy - h, 0):cy - h + size, max(cx - h, 0):cx - h + size]     # TODO: reflect at the borders\n',
            "import numpy as np, cv2\nrng = np.random.default_rng(0)\nimg = rng.integers(0, 256, (40, 50, 3)).astype(np.uint8)\npad = cv2.copyMakeBorder(img, 16, 16, 16, 16, cv2.BORDER_REFLECT)\nfor cx, cy in [(25, 20), (2, 3), (48, 38), (0, 39), (49, 0)]:\n    c = reflect_crop(img, cx, cy, 32)\n    assert c.shape == (32, 32, 3), f'צורה {c.shape} ב־{(cx, cy)}'\n    assert np.array_equal(c, pad[cy:cy + 32, cx:cx + 32]), f'שונה מהריפוד של OpenCV ב־{(cx, cy)}'",
            'import numpy as np\n\ndef reflect_crop(img, cx, cy, size):\n    H, W = img.shape[:2]\n    def refl(v, n):\n        v = np.where(v < 0, -v - 1, v)\n        return np.where(v >= n, 2 * n - v - 1, v)\n    xs = refl(np.arange(cx - size // 2, cx - size // 2 + size), W)\n    ys = refl(np.arange(cy - size // 2, cy - size // 2 + size), H)\n    return img[ys][:, xs]\n')},
 {'id': '7.9', 'ch': 7, 'level': 3, 'sec': '7.2',
  'q': ['**אתגר — סף באמצע, לא בקצה.** הפונקציה של תרגיל 7.2 מחזירה ציון של חיתוך — הנמוך ביותר שנבחר. אבל כל סף בין הציון הזה לבין הציון הבא (הגבוה ביותר שלא נבחר) נותן בדיוק אותו F1 על דוגמאות הכיול. השלם את <code class="ltr">margin_threshold(prob, truth)</code>: מוצאת את נקודת החיתוך שממקסמת F1 על הכיול, ומחזירה את <b>האמצע</b> בין הציון האחרון שנבחר לראשון שלא נבחר (אם כולם נבחרו — את הציון האחרון).',
        '**א.** בבדיקה: 300 כיולים של 10 מטרות ו־40 אחרים, וכל אחד נבדק על 2,000 דוגמאות חדשות. בכמה זה משפר את ה־F1 בממוצע?', '**ב.** למה השיפור קטן, ומה באמת היה עוזר?'],
  'hints': ['מיון מהגבוה לנמוך; ‏F1 בנקודת חיתוך <span class="ltr">k</span>: ‏<span class="ltr">2·tp / (k + 1 + P)</span>.', 'אחרי <code class="ltr">k = f1.argmax()</code> — ‏<span class="ltr">(p[k] + p[k + 1]) / 2</span>.'],
  'sol': ['**א.** בבדיקה (זרעים 0–299, מטרות סביב 0.65 ואחרים סביב 0.3): ‏F1 ממוצע של 0.871 בקצה מול 0.882 באמצע — כנקודה אחת. השיפור קטן אבל עקבי: הקצה תמיד צמוד לדוגמה אחת, והאמצע משאיר מרווח לשני הצדדים — אותו רעיון כמו שוליים רחבים ב־SVM.', '**ב.** הרעש העיקרי הוא <b>מעט דוגמאות</b>: עם 10 מטרות, המטרה החלשה ביותר בכיול היא מקרית. מה שעוזר באמת: יותר תיוג (כמה עשרות מטרות), תיוג ממוקד ליד הגבול (לתייג את החיתוכים שהציון שלהם קרוב לסף — "למידה פעילה"), ובדיקה על קבוצה נפרדת לפני שמשתמשים בסף.'],
  'test': T('השלם את margin_threshold.',
            'import numpy as np\n\ndef margin_threshold(prob, truth):\n    o = np.argsort(-prob); p, y = prob[o], np.asarray(truth)[o]\n    tp = np.cumsum(y); f1 = 2 * tp / (np.arange(1, len(p) + 1) + y.sum())\n    return float(p[f1.argmax()])     # TODO: the middle of the gap\n',
            "import numpy as np\nr = margin_threshold(np.array([0.9, 0.7, 0.4, 0.2]), np.array([True, True, False, False]))\nassert abs(r - 0.55) < 1e-9, f'החיתוך הטוב אחרי 0.7, והבא 0.4 — האמצע 0.55; קיבלתי {r}'\nassert abs(margin_threshold(np.array([0.9, 0.8]), np.array([True, True])) - 0.8) < 1e-9, 'כשכולם נבחרים — הציון האחרון'\ndef f1(p, t, th):\n    pick = p >= th; tp = (pick & t).sum(); return 2 * tp / max(pick.sum() + t.sum(), 1)\nedge, mid = [], []\nfor seed in range(300):\n    rng = np.random.default_rng(seed)\n    def gen(a, b):\n        return np.r_[rng.normal(0.65, 0.12, a), rng.normal(0.3, 0.1, b)], np.r_[np.ones(a, bool), np.zeros(b, bool)]\n    pc, tc = gen(10, 40); pt, tt = gen(400, 1600)\n    o = np.argsort(-pc); tp = np.cumsum(tc[o]); k = (2 * tp / (np.arange(1, 51) + 10)).argmax()\n    edge.append(f1(pt, tt, pc[o][k])); mid.append(f1(pt, tt, margin_threshold(pc, tc)))\nassert np.mean(mid) > np.mean(edge) + 0.005, f'האמצע צריך לנצח את הקצה בממוצע: {np.mean(mid):.3f} מול {np.mean(edge):.3f}'",
            'import numpy as np\n\ndef margin_threshold(prob, truth):\n    o = np.argsort(-prob); p, y = prob[o], np.asarray(truth)[o]\n    tp = np.cumsum(y); f1 = 2 * tp / (np.arange(1, len(p) + 1) + y.sum())\n    k = int(f1.argmax())\n    return float((p[k] + p[k + 1]) / 2) if k + 1 < len(p) else float(p[k])\n')},
]

META.update({
 '8.1': (1, '8.1', '**זה חישוב.** **נתון:** ארבע התצורות של 8.1 וקצב של 2,000 אסימונים בשנייה. **מה לעשות:** זמן קריאת התמונה בכל אחת. **איך תדע שהצלחת:** ‏0.10, ‏0.36, ‏0.13, ‏0.51 שניות — הקוד המלא של 8.1 מדפיס אותם.'),
 '8.2': (2, '8.3', '**זו שאלת ניסוח.** **נתון:** שאלה מובילה על צבע טנדר. **מה לעשות:** לנסח מחדש — לא מובילה, וקלה לפענוח. **איך תדע שהצלחת:** שתי שאלות סגורות, השנייה עם רשימת תשובות.'),
 '8.3': (2, '8.4', '**זו שאלת תכנון.** **נתון:** מזהה ב־30 פריימים בשנייה ומודל של 300 מילישניות. **מה לעשות:** מתי שואלים, ומה עם עשרה מועמדים. **איך תדע שהצלחת:** תזכיר התראה ראשונה של מסלול, תור ועדיפות — וההדמיה של 8.4 מראה למה.'),
 '8.4': (3, '8.4', '**זו שאלת ניסוי.** **נתון:** מודל שעלול להזות. **מה לעשות:** ניסוי עם מדד מספרי אחד. **איך תדע שהצלחת:** שאלות על עצמים שאינם בפריים, ושיעור ה"כן" — ותרגיל 8.9 מוסיף לו רווח סמך.'),
})
X += [
 # ------------------------------------------------ chapter 8
 {'id': '8.5', 'ch': 8, 'level': 1, 'sec': '8.1',
  'q': ['החשבון של 8.1 כפונקציה. השלם את <code class="ltr">visual_tokens(side, patch, shuffle)</code> ואת <code class="ltr">read_seconds(side, patch, shuffle, question_tokens, rate)</code> — זמן קריאת כל הקלט (תמונה ושאלה) בקצב <span class="ltr">rate</span> אסימונים בשנייה.',
        '**א.** כמה אסימונים בתמונה של 768 עם טלאי 14 ואיחוד 4? ובכמה אחוזים מהקלט, עם שאלה של 12 אסימונים?', '**ב.** כמה רזולוציה אפשר להרשות לעצמכם אם זמן הקריאה חייב להיות מתחת ל־0.2 שניות בקצב 2,000, עם טלאי 16 ואיחוד 4?'],
  'hints': ['<span class="ltr">(side // patch) ** 2 // shuffle</span>.', 'זמן = (אסימונים חזותיים + אסימוני שאלה) / קצב.'],
  'sol': ['**א.** ‏<span class="ltr">768 // 14 = 54</span>, ‏<span class="ltr">54² = 2,916</span>, חלקי 4 — ‏729 אסימונים; עם 12 אסימוני שאלה — 98.4% מהקלט.', '**ב.** ‏0.2 שניות × 2,000 = 400 אסימונים, פחות השאלה — כ־390. ‏<span class="ltr">(side / 16)² / 4 ≤ 390</span> נותן צלע של עד כ־630: ‏<span class="ltr">624 // 16 = 39</span>, ‏<span class="ltr">39² // 4 = 380</span>.'],
  'test': T('השלם את visual_tokens ואת read_seconds.',
            'def visual_tokens(side, patch, shuffle):\n    return side * side     # TODO\n\ndef read_seconds(side, patch, shuffle, question_tokens, rate):\n    return 0.0     # TODO\n',
            "assert [visual_tokens(*c) for c in [(224, 16, 1), (384, 14, 1), (512, 16, 4), (1024, 16, 4)]] == [196, 729, 256, 1024], 'ארבע התצורות של 8.1: 196, 729, 256, 1024'\nassert visual_tokens(768, 14, 4) == 729\nassert abs(read_seconds(224, 16, 1, 4, 2000) - 0.1) < 1e-9, f'(196 + 4) / 2000 = 0.1; קיבלתי {read_seconds(224, 16, 1, 4, 2000)}'",
            'def visual_tokens(side, patch, shuffle):\n    return (side // patch) ** 2 // shuffle\n\ndef read_seconds(side, patch, shuffle, question_tokens, rate):\n    return (visual_tokens(side, patch, shuffle) + question_tokens) / rate\n')},
 {'id': '8.6', 'ch': 8, 'level': 1, 'sec': '8.2',
  'q': ['**זו שאלת בחירה.** לכל מערכת — מאיזו משפחה בטבלה של 8.2 תתחיל לבדוק, ולמה? ומה תמדוד לפני שתחליט?',
        {'table': [['מערכת', 'משפחה?'], ['אימות "האם האדם נושא משהו ביד" על מחשב הקצה של הרחפן, בלי כרטיס מסך', '?'], ['קריאת מספרים על מכולות בנמל, בשרת', '?'], ['ספירת אנשים בחיתוך של רכב פתוח', '?'], ['מודל שתכווננו על אלף תמונות מתויגות של כלי הרכב שלכם', '?']]}],
  'hints': ['מה הדרישה הקשה בכל שורה?', 'והמדידה — אותה בכל השורות.'],
  'sol': ['מחשב קצה בלי כרטיס — SmolVLM2. מספרים על מכולות — Qwen3-VL (טקסט בתמונה), בשרת אין בעיית גודל. ספירה — Moondream (או Qwen3-VL אם יש מקום). כיוונון — PaliGemma 2 או Gemma 3. ובכל אחת, לפני החלטה: 50–100 דוגמאות שלכם עם תשובות נכונות — דיוק, זמן לשאלה על החומרה האמיתית, ושיעור הזיות (תרגיל 8.4★). והתחום משתנה — בודקים מה יצא מאז הסתיו.']},
 {'id': '8.7', 'ch': 8, 'level': 2, 'sec': '8.3',
  'q': ['הפענוח של 8.3. השלם את <code class="ltr">parse_yes_no(text)</code>: מחזירה <span class="ltr">True</span>, <span class="ltr">False</span> או <span class="ltr">None</span> (לא ברור). הכללים: מתעלמים מאותיות גדולות ומסימני פיסוק; המילה הראשונה קובעת — "yes" או "no" (וגם "nope" ו־"yeah"); תשובה שמכילה גם מילת כן וגם מילת לא — לא ברורה; כל דבר אחר — לא ברור.',
        '**א.** למה "There is no backpack" יוצא לא ברור, למרות שהמשמעות ברורה? האם זה בסדר?', '**ב.** במערכת של 8.4 — מה עושים עם <span class="ltr">None</span>?'],
  'hints': ['<code class="ltr">re.findall(r"[a-z]+", text.lower())</code>.', 'קבוצות: <span class="ltr">YES = {"yes", "yeah"}</span>, ‏<span class="ltr">NO = {"no", "nope"}</span>.'],
  'sol': ['**א.** כי המילה הראשונה היא "there". אפשר להוסיף כללים, אבל כל כלל נוסף הוא עוד מקום לטעות ("There is no doubt he has a backpack"). עדיף לטעות לכיוון "לא ברור" — ולשפר את ההוראה בשאלה ("Answer with one word: yes or no") — מאשר לפענח בביטחון משפט חופשי.', '**ב.** "לא אומת": ההתראה של המזהה נשארת בעדיפות שלה, ובממשק מסומן שהאימות לא הצליח. לא הופכים את זה ל"לא" — וגם לא שואלים שוב ושוב באותו פריים; אפשר לשאול פעם נוספת על פריים מאוחר יותר של המסלול.'],
  'test': T('השלם את parse_yes_no.',
            'def parse_yes_no(text):\n    return "yes" in text.lower()     # TODO\n',
            "cases = {'Yes': True, 'yes.': True, 'YES!': True, 'Yes, the person is carrying a backpack.': True, 'Yeah': True, 'No': False, 'NO.': False, 'Nope': False, 'no, nothing in hand': False, 'Yes and no.': None, 'No... well, yes': None, 'I cannot determine this from the image.': None, 'Not sure, but probably yes.': None, 'There is no backpack.': None, '': None, 'Nobody': None}\nfor t, want in cases.items():\n    got = parse_yes_no(t)\n    assert got is want, f'{t!r}: ציפיתי ל־{want}, קיבלתי {got}'",
            'import re\n\nYES, NO = {"yes", "yeah"}, {"no", "nope"}\n\ndef parse_yes_no(text):\n    words = re.findall(r"[a-z]+", text.lower())\n    if not words:\n        return None\n    if YES & set(words) and NO & set(words):\n        return None\n    if words[0] in YES:\n        return True\n    if words[0] in NO:\n        return False\n    return None\n')},
 {'id': '8.8', 'ch': 8, 'level': 2, 'sec': '8.4',
  'q': ['התור של 8.4. השלם את <code class="ltr">answer_times(arrivals, service)</code>: שאלות מגיעות בזמנים <span class="ltr">arrivals</span> (בשניות, ממוינים), ומודל אחד עונה על כל שאלה ב־<span class="ltr">service</span> שניות, לפי סדר ההגעה. מחזירה לכל שאלה את הזמן מההגעה עד התשובה.',
        '**א.** עשרה מועמדים באותו רגע, 0.3 שניות לשאלה — מה הזמן עד תשובה של האחרון?', '**ב.** שאלות מגיעות כל 0.32 שניות בדיוק, ומודל של 0.3 — מה קורה? ואם מגיעות באקראי באותו קצב ממוצע?'],
  'hints': ['המודל פנוי מזמן <span class="ltr">free</span>: שאלה מתחילה ב־<span class="ltr">max(a, free)</span>.', 'אחרי כל שאלה: <span class="ltr">free = start + service</span>, והזמן עד תשובה הוא <span class="ltr">free − a</span>.'],
  'sol': ['**א.** ‏3.0 שניות — האחרון מחכה לתשעה לפניו.', '**ב.** בדיוק כל 0.32 — כל שאלה מקבלת תשובה תוך 0.3, בלי תור. באקראי באותו קצב (עומס של כ־94%) — התור מתנפח בפרצים: בבדיקה, עם 2,000 הגעות אקראיות, הזמן החציוני עד תשובה 1.3 שניות, ו־5% מהשאלות מחכות יותר מ־5.7 שניות — פי 20 מזמן השאלה. מערכת אמיתית לא מגיעה בקצב קבוע — לכן משאירים מרווח מהקיבולת.'],
  'test': T('השלם את answer_times.',
            'import numpy as np\n\ndef answer_times(arrivals, service):\n    return [service for _ in arrivals]     # TODO: waiting in the queue\n',
            "import numpy as np\nr = answer_times([0.0] * 10, 0.3)\nassert abs(r[-1] - 3.0) < 1e-9 and abs(r[0] - 0.3) < 1e-9, f'עשרה באותו רגע: הראשון 0.3, האחרון 3.0; קיבלתי {r[0]}, {r[-1]}'\nassert np.allclose(answer_times(list(np.arange(0, 20, 0.32)), 0.3), 0.3), 'בקצב קבוע מתחת לקיבולת — בלי תור'\nassert np.allclose(answer_times([0, 1, 1.1, 5], 0.5), [0.5, 0.5, 0.9, 0.5])\nrng = np.random.default_rng(0)\narr = np.cumsum(rng.exponential(0.32, 2000))\nassert np.median(answer_times(list(arr), 0.3)) > 1.0, 'באקראי, בעומס של 94% — התור מתנפח'",
            'import numpy as np\n\ndef answer_times(arrivals, service):\n    free, out = 0.0, []\n    for a in arrivals:\n        start = max(a, free)\n        free = start + service\n        out.append(free - a)\n    return out\n')},
 {'id': '8.9', 'ch': 8, 'level': 3, 'sec': '8.4',
  'q': ['**אתגר — כמה שאלות צריך כדי לדעת?** בניסוי של תרגיל 8.4★ שאלתם 50 שאלות על עצמים שאינם בפריים, והמודל ענה "כן" ב־3 — ‏6%. אבל עם 50 שאלות, "6%" רועש. השלם את <code class="ltr">wilson(k, n, z=1.96)</code>: רווח הסמך של וילסון לשיעור <span class="ltr">k / n</span> (מוחזר כזוג, עם גבול תחתון שלא יורד מאפס), ואת <code class="ltr">questions_needed(p, half_width, z=1.96)</code>: מספר השאלות שנדרש כדי שחצי רוחב הרווח (בקירוב הנורמלי, <span class="ltr">z·√(p(1−p)/n)</span>) יהיה לכל היותר <span class="ltr">half_width</span>.',
        '**א.** מה רווח הסמך ל־3 מתוך 50? ול־0 מתוך 20 — האם "אפס הזיות" אומר שהמודל לא מזה?', '**ב.** כמה שאלות צריך כדי לדעת שיעור הזיות של כ־20% בדיוק של ±5%? וכמה במקרה הגרוע?', '**ג.** למה וילסון ולא <span class="ltr">p ± z·√(p(1−p)/n)</span>?'],
  'hints': ['‏<span class="ltr">c = (p + z²/2n) / (1 + z²/n)</span>, ‏<span class="ltr">h = z·√(p(1−p)/n + z²/4n²) / (1 + z²/n)</span>.', '‏<span class="ltr">n = ⌈z²·p(1−p) / w²⌉</span>.'],
  'sol': ['**א.** 3 מתוך 50: ‏2.1% עד 16.2% — המודל יכול להזות בשיעור של 1 מכל 6. ‏0 מתוך 20: ‏0% עד 16.1% — "אפס" על 20 שאלות לא מוכיח כמעט כלום.', '**ב.** ‏<span class="ltr">1.96² · 0.2 · 0.8 / 0.05²</span> — ‏246 שאלות. במקרה הגרוע (<span class="ltr">p = 0.5</span>) — ‏385. כלומר ניסוי של הזיות הוא כמה מאות שאלות, לא עשרות.', '**ג.** הנוסחה הפשוטה נותנת רווח באורך אפס כש־<span class="ltr">k = 0</span> ("בטוח שאין הזיות") וגבולות מתחת לאפס כשהשיעור קטן — בדיוק המצב של מודל טוב. וילסון נשאר בתוך <span class="ltr">[0, 1]</span> ונותן רווח סביר גם באפס.'],
  'test': T('השלם את wilson ואת questions_needed.',
            'import math\n\ndef wilson(k, n, z=1.96):\n    p = k / n\n    h = z * math.sqrt(p * (1 - p) / n)\n    return p - h, p + h     # TODO: the Wilson interval\n\ndef questions_needed(p, half_width, z=1.96):\n    return 0     # TODO\n',
            "lo, hi = wilson(3, 50)\nassert abs(lo - 0.0206) < 5e-4 and abs(hi - 0.1622) < 5e-4, f'3 מתוך 50: כ־0.021 עד 0.162; קיבלתי {lo:.4f}, {hi:.4f}'\nlo, hi = wilson(0, 20)\nassert lo == 0 and abs(hi - 0.1611) < 5e-4, f'0 מתוך 20: מאפס עד כ־0.161; קיבלתי {lo}, {hi:.4f}'\nlo, hi = wilson(10, 100)\nassert abs(lo - 0.0552) < 5e-4 and abs(hi - 0.1744) < 5e-4\nassert questions_needed(0.2, 0.05) == 246, f'צריך 246; קיבלתי {questions_needed(0.2, 0.05)}'\nassert questions_needed(0.5, 0.05) == 385",
            'import math\n\ndef wilson(k, n, z=1.96):\n    p = k / n\n    d = 1 + z * z / n\n    c = (p + z * z / (2 * n)) / d\n    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d\n    return max(0.0, c - h), min(1.0, c + h)\n\ndef questions_needed(p, half_width, z=1.96):\n    return math.ceil(z * z * p * (1 - p) / half_width ** 2)\n')},
]

META.update({
 '9.1': (1, '9.1', '**זו שאלת הבנה.** **נתון:** 0% לסגור על צירופים שלא נראו. **מה לעשות:** להסביר למה לא ניחוש אקראי. **איך תדע שהצלחת:** תזכיר שהסגור בוחר רק מתוך 24 המחלקות שלו.'),
 '9.2': (2, '9.1', '**זו שאלת הבנה.** **נתון:** שני מודלים באותו גודל ועל אותם נתונים. **מה לעשות:** להסביר למה הסגור מדויק יותר על מה שראה. **איך תדע שהצלחת:** תזכיר הפסד שהוא בדיוק המשימה, מול משימה עקיפה עם כיתובים ושליליים מדומים.'),
 '9.3': (1, '9.2', '**זו שאלת סיווג.** **נתון:** טבלת ההחלטה. **מה לעשות:** שלושה תרחישים — לשורה. **איך תדע שהצלחת:** ההדמיה של 9.2 מסמנת את השורה לפי התשובות שלך.'),
 '9.4': (3, '9.1', '**זו שאלת תכנון.** **נתון:** סגור ופתוח. **מה לעשות:** לשלב, ולומר מה לבדוק. **איך תדע שהצלחת:** תזכיר שהסגור בטוח בעצמו גם כשהוא טועה — וההיסטוגרמה של 9.1 מראה את זה; ואז הרצה במקביל.'),
})
X += [
 # ------------------------------------------------ chapter 9
 {'id': '9.5', 'ch': 9, 'level': 1, 'sec': '9.1',
  'q': ['למה הסגור "בטוח" גם כשהוא לא מכיר. השלם את <code class="ltr">softmax(z)</code> (יציבה — בלי גלישה גם לציונים של 1,000) ואת <code class="ltr">confidence(z)</code> — ההסתברות הגבוהה ביותר.',
        '**א.** משולש כחול נכנס לסגור, והציונים של "משולש אדום", "עיגול כחול" ו"ריבוע ירוק" הם 4.0, ‏1.0 ו־0.5. מה הביטחון? האם הוא אומר משהו על כך שהמחלקה לא קיימת?', '**ב.** הכפל את כל הציונים ב־3. מה קרה לביטחון, ולמה זו בעיה?'],
  'hints': ['מחסירים את המקסימום לפני <code class="ltr">np.exp</code>.', '<code class="ltr">softmax(z).max()</code>.'],
  'sol': ['**א.** כ־0.926. ‏softmax רק אומר "יחסית לשאר המחלקות", ו"משולש אדום" הוא אכן הכי דומה. אין לו דרך לומר "אף אחת" — ההסתברויות חייבות להסתכם ל־1.', '**ב.** כמעט 1 (0.9998): ציונים חדים יותר — ביטחון גבוה יותר, בלי שום שינוי בידע. רשת שאומנה עד הסוף נוטה לציונים חדים — ולכן ביטחון אינו גלאי של "לא מוכר" (תרגיל 9.4★).'],
  'test': T('השלם את softmax ואת confidence.',
            'import numpy as np\n\ndef softmax(z):\n    e = np.exp(z)\n    return e     # TODO: normalize, and stable\n\ndef confidence(z):\n    return 0.0     # TODO\n',
            "import numpy as np\np = softmax(np.array([4.0, 1.0, 0.5]))\nassert abs(p.sum() - 1) < 1e-9, f'ההסתברויות צריכות להסתכם ל־1; קיבלתי {p.sum()}'\nassert abs(confidence(np.array([4.0, 1.0, 0.5])) - 0.9259) < 1e-3, f'ציפיתי לכ־0.926; קיבלתי {confidence(np.array([4.0, 1.0, 0.5]))}'\nwith np.errstate(over='raise', invalid='raise'):\n    q = softmax(np.array([1000.0, 999.0]))\nassert abs(q[0] - 0.7311) < 1e-3, 'ציונים של 1,000 — בלי גלישה'\nassert confidence(3 * np.array([4.0, 1.0, 0.5])) > 0.999",
            'import numpy as np\n\ndef softmax(z):\n    e = np.exp(z - z.max())\n    return e / e.sum()\n\ndef confidence(z):\n    return float(softmax(z).max())\n')},
 {'id': '9.6', 'ch': 9, 'level': 2, 'sec': '9.1',
  'q': ['תרגיל 9.4★ בקוד: שני המודלים במקביל. השלם את <code class="ltr">combine(closed_pred, open_scores, open_names, thresholds)</code>: לכל חיתוך — אם יש תיאור חדש של הפתוח שהציון שלו עובר את הסף <i>שלו</i> (<span class="ltr">thresholds[name]</span>), מחזירים את התיאור עם הציון הגבוה מבין אלה שעברו; אחרת — את התשובה של הסגור. ‏<span class="ltr">open_scores</span> בצורה <span class="ltr">(N, K)</span>, עמודה לכל תיאור ב־<span class="ltr">open_names</span>.',
        '**א.** למה סף לכל תיאור, ולא אחד?', '**ב.** חיתוך של משאית אדומה (מחלקה מוכרת לסגור) מקבל ציון גבוה גם לתיאור החדש "משאית עם מנוף צהוב". מי מנצח לפי הכלל, ומה תבדוק כדי לדעת אם זה בסדר?'],
  'hints': ['<code class="ltr">ok = open_scores >= np.array([thresholds[n] for n in open_names])</code>.', 'בשורות שיש בהן <span class="ltr">ok</span> — ‏argmax על <code class="ltr">np.where(ok, open_scores, -np.inf)</code>.'],
  'sol': ['**א.** פרק 7.2: ההסתברויות של תיאורים שונים חיות בסולמות שונים — 0.11 יכול להיות מטרה טובה בתיאור אחד ולא־מטרה בתיאור אחר.', '**ב.** הפתוח מנצח — וזו התראת שווא על משאית רגילה. בודקים את שיעור ההתראות של הפתוח על עצמים שהסגור מכיר בביטחון (ובצדק), ואם הוא גבוה — מעלים את הסף של התיאור, או דורשים שהפתוח ינצח רק כשהמחלקה של הסגור היא "רקע" או קרובה לתיאור.'],
  'test': T('השלם את combine.',
            'import numpy as np\n\ndef combine(closed_pred, open_scores, open_names, thresholds):\n    return list(closed_pred)     # TODO\n',
            "import numpy as np\ncp = ['car', 'person', 'truck', 'car']\nS = np.array([[0.05, 0.30], [0.20, 0.01], [0.15, 0.25], [0.50, 0.60]])\nnames = ['crane truck', 'backpack']\nth = {'crane truck': 0.1, 'backpack': 0.5}\nr = combine(cp, S, names, th)\nassert list(r) == ['car', 'crane truck', 'crane truck', 'backpack'], f'ציפיתי ל־car, crane truck, crane truck, backpack (בשורה האחרונה שניהם עוברים, ו־backpack גבוה יותר); קיבלתי {list(r)}'\nth2 = {'crane truck': 0.6, 'backpack': 0.55}\nassert list(combine(cp, S, names, th2)) == ['car', 'person', 'truck', 'backpack'], 'בשורה האחרונה רק backpack עובר את הסף שלו'",
            'import numpy as np\n\ndef combine(closed_pred, open_scores, open_names, thresholds):\n    th = np.array([thresholds[n] for n in open_names])\n    ok = open_scores >= th\n    best = np.where(ok, open_scores, -np.inf).argmax(1)\n    return [open_names[best[i]] if ok[i].any() else closed_pred[i] for i in range(len(closed_pred))]\n')},
 {'id': '9.7', 'ch': 9, 'level': 2, 'sec': '9.3',
  'q': ['שלב 2 של 9.3 — לחסוך זמן של אדם. השלם את <code class="ltr">review_queue(probs, low, high)</code>: חיתוכים עם הסתברות מעל <span class="ltr">high</span> מתקבלים אוטומטית, מתחת ל־<span class="ltr">low</span> נדחים אוטומטית, והאמצעיים הולכים לבדיקה. מחזירה שלוש רשימות אינדקסים — <span class="ltr">accept</span>, ‏<span class="ltr">review</span> (מהגבוה לנמוך), ‏<span class="ltr">reject</span>.',
        '**א.** בבדיקה, 1,000 מועמדים. מה קורה לכמות העבודה כשמרחיבים את הטווח, ומה קורה לשגיאות שעוברות לתוויות?', '**ב.** איך תבחר את <span class="ltr">high</span>?'],
  'hints': ['שלוש מסכות: <span class="ltr">p &gt; high</span>, ‏<span class="ltr">p &lt; low</span>, והשאר.', 'מיון ה־review: <code class="ltr">idx[np.argsort(-probs[idx])]</code>.'],
  'sol': ['**א.** טווח רחב — יותר בדיקות, ופחות שגיאות שמתקבלות אוטומטית; צר — פחות עבודה, ויותר שגיאות שנכנסות לתוויות (ובהדמיה של 9.3 ראית כמה ארבע תוויות שגויות עולות). זו פשרה מפורשת בין שעות של אדם לאיכות התוויות.', '**ב.** על מדגם מתויג: ה־<span class="ltr">high</span> הנמוך ביותר שבו הדיוק מעליו כמעט 100% (כמו תרגיל 6.8, עם דרישה של 99%). ובהתחלה, כשאין מדגם — בודקים הכול, ומשתמשים בבדיקות האלה כדי לבחור את הספים לפעם הבאה.'],
  'test': T('השלם את review_queue.',
            'import numpy as np\n\ndef review_queue(probs, low, high):\n    return [], list(range(len(probs))), []     # TODO\n',
            "import numpy as np\np = np.array([0.95, 0.2, 0.6, 0.05, 0.8, 0.4, 0.99])\na, r, j = review_queue(p, 0.3, 0.9)\nassert sorted(int(i) for i in a) == [0, 6], f'מעל 0.9: 0 ו־6; קיבלתי {a}'\nassert [int(i) for i in r] == [4, 2, 5], f'לבדיקה, מהגבוה לנמוך: 4, 2, 5; קיבלתי {r}'\nassert sorted(int(i) for i in j) == [1, 3]\nrng = np.random.default_rng(0); q = rng.random(1000)\nn1 = len(review_queue(q, 0.4, 0.6)[1]); n2 = len(review_queue(q, 0.2, 0.8)[1])\nassert n2 > n1, 'טווח רחב — יותר בדיקות'",
            'import numpy as np\n\ndef review_queue(probs, low, high):\n    probs = np.asarray(probs)\n    idx = np.arange(len(probs))\n    accept = idx[probs > high]\n    reject = idx[probs < low]\n    mid = idx[(probs >= low) & (probs <= high)]\n    return list(accept), list(mid[np.argsort(-probs[mid])]), list(reject)\n')},
 {'id': '9.8', 'ch': 9, 'level': 2, 'sec': '9.2',
  'q': ['טבלת ההחלטה כפונקציה. השלם את <code class="ltr">choose(permanent, labels, today, human, rare)</code> — חמישה בוליאנים כמו בהדמיה של 9.2 — שמחזירה אחת מ־<span class="ltr">"closed"</span>, ‏<span class="ltr">"open"</span>, ‏<span class="ltr">"open+review"</span>, ‏<span class="ltr">"open-now-closed-later"</span>. הכללים, לפי הסדר: נדירה ← ‏open+review; לא קבועה ואדם בודק ממילא ← open; קבועה וצריך היום ← open-now-closed-later; קבועה עם תוויות ← closed; קבועה בלי תוויות ← open-now-closed-later; כל השאר ← open.',
        '**א.** למה הכלל של "נדירה" ראשון?', '**ב.** איזה שילוב של תשובות לא מכוסה היטב בכללים, ומה היית מוסיף?'],
  'hints': ['שרשרת של <code class="ltr">if</code> עם <code class="ltr">return</code>, בסדר שבשאלה.'],
  'sol': ['**א.** כי כשאין דוגמאות בעולם, שום דבר אחר לא משנה: גם אם המטרה קבועה, אין ממה לאמן סגור. הסדר הוא העדיפות.', '**ב.** למשל מטרה קבועה, עם תוויות, ושמחיר טעות בה גבוה מאוד (חיים) — הכללים אומרים "סגור", אבל אולי צריך גם אישור אנושי. או מטרה זמנית (שבוע) שצריך היום בלי אדם שבודק — "open", אבל עם סף שמרני. טבלה היא נקודת התחלה; המקרים בקצוות דורשים שיחה.'],
  'test': T('השלם את choose.',
            'def choose(permanent, labels, today, human, rare):\n    return "open"     # TODO\n',
            "assert choose(True, True, False, False, False) == 'closed', 'קבועה עם תוויות — סגור'\nassert choose(True, True, True, False, False) == 'open-now-closed-later', 'קבועה וצריך היום — פתוח עכשיו'\nassert choose(True, False, False, False, False) == 'open-now-closed-later'\nassert choose(False, False, False, True, False) == 'open', 'חיפוש חד־פעמי עם אדם — פתוח'\nassert choose(True, True, False, False, True) == 'open+review', 'נדירה — קודם לכול'\nassert choose(False, False, True, False, False) == 'open'",
            'def choose(permanent, labels, today, human, rare):\n    if rare:\n        return "open+review"\n    if not permanent and human:\n        return "open"\n    if permanent and today:\n        return "open-now-closed-later"\n    if permanent and labels:\n        return "closed"\n    if permanent:\n        return "open-now-closed-later"\n    return "open"\n')},
 {'id': '9.9', 'ch': 9, 'level': 3, 'sec': '9.3',
  'q': ['**אתגר — למה טעויות של הפתוח מזיקות יותר מרעש אקראי.** בהדמיה של 9.3, ארבע תוויות שגויות הורידו מאוד את הדיוק של הסגור. השערה: הטעויות של הפתוח הן לא אקראיות — הן בדיוק הדוגמאות השליליות שהכי <i>דומות</i> למטרה. בדוק על נתונים סינתטיים (שתי מחלקות בשני ממדים, 20% חיוביים). השלם את <code class="ltr">flip_random(y, k, rng)</code> — הופכת <span class="ltr">k</span> שליליים אקראיים לחיוביים — ואת <code class="ltr">flip_hard(X, y, k, w)</code> — הופכת את <span class="ltr">k</span> השליליים עם הציון <span class="ltr">X @ w</span> הגבוה ביותר (הכי קרובים למטרה). שתיהן מחזירות עותק.',
        '**א.** בבדיקה: 20 זרעים, 10% תוויות שגויות, רגרסיה לוגיסטית, דיוק על נתוני בדיקה נקיים. מה יצא בשלושת המצבים?', '**ב.** מה המסקנה לגבי סדר הבדיקה של אדם בשלב 2?'],
  'hints': ['<code class="ltr">neg = np.nonzero(~y)[0]</code>.', 'אקראי: <code class="ltr">rng.choice(neg, k, replace=False)</code>; קשה: <code class="ltr">neg[np.argsort(-(X[neg] @ w))[:k]]</code>.'],
  'sol': ['**א.** בבדיקה: תוויות נקיות — דיוק של 93.8%; 10% טעויות אקראיות — 92.8%; אותן 10% על הדוגמאות הקשות — 89.7%. אותו מספר טעויות, פי ארבעה נזק: טעויות אקראיות מתקזזות, וטעויות שיטתיות מזיזות את הגבול בדיוק לכיוון הלא נכון.', '**ב.** לבדוק קודם את המקרים הקרובים לגבול — שם הטעויות של הפתוח מרוכזות, ושם הן מזיקות ביותר. מועמדים עם ציון גבוה מאוד הם כמעט תמיד נכונים (תרגיל 9.7). זה הרעיון של "למידה פעילה": זמן של אדם הולך לאן שהוא שווה הכי הרבה.'],
  'test': T('השלם את flip_random ואת flip_hard.',
            'import numpy as np\n\ndef flip_random(y, k, rng):\n    return y.copy()     # TODO\n\ndef flip_hard(X, y, k, w):\n    return y.copy()     # TODO\n',
            "import numpy as np, warnings\nwarnings.filterwarnings('ignore')\nfrom sklearn.linear_model import LogisticRegression\ndef make(n, rng):\n    y = rng.random(n) < 0.2\n    X = rng.normal(size=(n, 2)); X[y] += [2.5, 2.5]\n    return X, y\ndef prec(clf, X, y):\n    p = clf.predict(X); return (p & y).sum() / max(p.sum(), 1)\ny0 = np.array([True, False, False, False]); X0 = np.array([[0, 0], [5, 5], [1, 1], [-3, -3.0]])\nh = flip_hard(X0, y0, 1, np.array([1.0, 1.0]))\nassert list(h) == [True, True, False, False] and list(y0) == [True, False, False, False], f'הקשה ביותר היא השורה 1, ובלי לשנות את המקור; קיבלתי {[bool(v) for v in h]}'\nassert flip_random(y0, 2, np.random.default_rng(0)).sum() == 3\nres = []\nfor seed in range(20):\n    rng = np.random.default_rng(seed); X, y = make(400, rng); Xt, yt = make(4000, rng); k = int(0.1 * y.sum())\n    res.append((prec(LogisticRegression().fit(X, y), Xt, yt), prec(LogisticRegression().fit(X, flip_random(y, k, rng)), Xt, yt), prec(LogisticRegression().fit(X, flip_hard(X, y, k, np.array([1.0, 1.0]))), Xt, yt)))\na, b, c = np.mean(res, 0)\nassert b > c + 0.02, f'טעויות קשות צריכות להזיק יותר: אקראי {b:.3f}, קשה {c:.3f}'",
            'import numpy as np\n\ndef flip_random(y, k, rng):\n    neg = np.nonzero(~y)[0]\n    y2 = y.copy(); y2[rng.choice(neg, k, replace=False)] = True\n    return y2\n\ndef flip_hard(X, y, k, w):\n    neg = np.nonzero(~y)[0]\n    y2 = y.copy(); y2[neg[np.argsort(-(X[neg] @ w))[:k]]] = True\n    return y2\n')},
]

META.update({
 '10.1': (1, '10.1', '**זו שאלת תכנון.** **נתון:** מטריצת שיכונים. **מה לעשות:** עמודות של טבלת המטא־מידע, ואיך מקשרים. **איך תדע שהצלחת:** תזכיר שורה i = שורה i, ומחיקה בסימון.'),
 '10.2': (2, '10.2', '**זו שאלת תחקור.** **נתון:** הרבה התראות שווא אחרי הוספת מטרה. **מה לעשות:** סדר בדיקה. **איך תדע שהצלחת:** להסתכל על התראות לפני שמשנים סף — וסף הוא הצעד האחרון.'),
 '10.3': (3, '10.1', '**זו שאלת תכנון.** **נתון:** האינדקס של חלק א. **מה לעשות:** מטרה מתמונת דוגמה, מה משתנה, יתרון וחיסרון. **איך תדע שהצלחת:** שורה אחת בקוד — מגדל התמונה במקום הטקסט — ותזכיר זווית, תאורה ורקע.'),
})
X += [
 # ------------------------------------------------ chapter 10
 {'id': '10.4', 'ch': 10, 'level': 1, 'sec': '10.1',
  'q': ['הגודל של האינדקס של חלק א, עם חיתוכים. השלם את <code class="ltr">index_mb(hours, fps, crops_per_frame, dim, bytes_per_value)</code>: כל פריים שנדגם מוסיף שורה אחת לפריים השלם ו־<span class="ltr">crops_per_frame</span> שורות לחיתוכים. מחזירה מגה־בייט (מיליון בתים).',
        '**א.** 10 שעות, פריים לשנייה, 3 חיתוכים בממוצע, ‏768, ‏float16 — כמה?', '**ב.** ואם רק 20% מהפריימים "השתנו" ונדגמים?'],
  'hints': ['שורות = <span class="ltr">hours · 3600 · fps · (1 + crops)</span>.'],
  'sol': ['**א.** ‏<span class="ltr">36,000 · 4 = 144,000</span> שורות × 768 × 2 בתים — כ־221 MB. ארבע פעמים יותר מבלי חיתוכים, ועדיין נכנס בזיכרון.', '**ב.** כ־44 MB. דגימה לפי שינוי חוסכת גם זיכרון וגם — חשוב יותר — את זמן הקידוד.'],
  'test': T('השלם את index_mb.',
            'def index_mb(hours, fps, crops_per_frame, dim, bytes_per_value):\n    return hours * 3600 * fps * dim * bytes_per_value / 1e6     # TODO: the crops\n',
            "assert abs(index_mb(10, 1, 0, 768, 4) - 110.592) < 1e-6, 'בלי חיתוכים, 32 סיביות — התרגיל 6.1: 110.6'\nr = index_mb(10, 1, 3, 768, 2)\nassert abs(r - 221.184) < 1e-6, f'עם 3 חיתוכים ב־16 סיביות: 221.2; קיבלתי {r}'\nassert abs(index_mb(10, 0.2, 3, 768, 2) - 44.2368) < 1e-6",
            'def index_mb(hours, fps, crops_per_frame, dim, bytes_per_value):\n    rows = hours * 3600 * fps * (1 + crops_per_frame)\n    return rows * dim * bytes_per_value / 1e6\n')},
 {'id': '10.5', 'ch': 10, 'level': 1, 'sec': '10.3',
  'q': ['**זו שאלת שיפוט.** סטודנט הגיש את הפרויקט עם המדידות הבאות. מה עובר, מה לא, ומה חסר כדי לקבל?',
        {'table': [['תנאי', 'נמדד'], ['זמן שאילתה בארכיון של 10 שעות', '12 מילישניות'], ['דיוק בעשרה, שאילתות פשוטות', '8.1 (על 5 שאילתות שכתב אחרי שראה תוצאות)'], ['הוספת מטרה עד שהיא חיה', '40 דקות, בלי כיול — "הסף של ברירת המחדל עבד"'], ['קצב המערכת החיה', '29 פריימים בשנייה במקום 30'], ['דוח', 'טבלת דיוק לכל מטרה; "לא נמצאו כישלונות משמעותיים"']]}],
  'hints': ['שלושה תנאים עוברים במספר — אבל האם המדידה עצמה תקינה?'],
  'sol': ['זמן שאילתה — עובר. קצב — עובר (ירידה של 3%). דיוק בעשרה — המספר עובר, אבל המדידה לא: 5 שאילתות במקום 20, ונכתבו אחרי שראה תוצאות (10.1). הוספת מטרה — לא עובר: בלי כיול אין סף לכל מטרה, ו"ברירת המחדל עבדה" לא נמדד (7.2). דוח — לא עובר: חסרות שלוש דוגמאות כישלון, ו"לא נמצאו כישלונות" אומר שלא חיפשו. ואין כלום על סימון בממשק — אחת משתי הדרישות שלא מוותרים עליהן.']},
 {'id': '10.6', 'ch': 10, 'level': 2, 'sec': '10.1',
  'q': ['ההערכה של חלק א. השלם את <code class="ltr">precision_at_k(ranked, relevant, k)</code> — כמה מ־<span class="ltr">k</span> הראשונים ב־<span class="ltr">ranked</span> נמצאים בקבוצה <span class="ltr">relevant</span>, כשבר — ואת <code class="ltr">by_type(results)</code>: מקבלת רשימה של <span class="ltr">(type, ranked, relevant)</span> ומחזירה מילון: סוג ← ממוצע הדיוק בעשרה.',
        '**א.** למה לפרק לפי סוג ולא לדווח ממוצע אחד?', '**ב.** לשאילתה יש רק 4 תשובות נכונות בכל הארכיון. מה הדיוק בעשרה המקסימלי שלה, ומה זה אומר על בחירת השאילתות?'],
  'hints': ['<code class="ltr">sum(r in relevant for r in ranked[:k]) / k</code>.', 'קבץ ב־<code class="ltr">dict</code> של רשימות, ואז ממוצע.'],
  'sol': ['**א.** ממוצע אחד מסתיר: 9 מתוך 10 על שמות עצם ו־3 על יחסים יכולים לצאת "7 בממוצע" — עובר, בזמן שהמערכת כמעט לא עונה על סוג שלם של שאלות. הפירוק אומר לאן להשקיע (למשל דירוג מחדש לשאילתות יחס).', '**ב.** ‏0.4 — גם מערכת מושלמת לא תעבור 7. לכן בוחרים שאילתות עם לפחות עשר תשובות נכונות בארכיון, או מודדים גם כיסוי (כמה מה־4 נמצאו בעשרה).'],
  'test': T('השלם את precision_at_k ואת by_type.',
            'def precision_at_k(ranked, relevant, k=10):\n    return 0.0     # TODO\n\ndef by_type(results):\n    return {}     # TODO\n',
            "assert precision_at_k([1, 2, 3, 4], {2, 4, 9}, 4) == 0.5, 'שניים מארבעה — 0.5'\nassert precision_at_k(list(range(20)), set(range(0, 20, 2)), 10) == 0.5, 'זוגיים בעשרה הראשונים — 5'\nres = [('noun', list(range(10)), set(range(10))), ('noun', list(range(10)), set(range(8))), ('relation', list(range(10)), {0, 1, 2})]\nr = by_type(res)\nassert abs(r['noun'] - 0.9) < 1e-9 and abs(r['relation'] - 0.3) < 1e-9, f'noun 0.9, relation 0.3; קיבלתי {r}'",
            'def precision_at_k(ranked, relevant, k=10):\n    return sum(r in relevant for r in ranked[:k]) / k\n\ndef by_type(results):\n    groups = {}\n    for t, ranked, relevant in results:\n        groups.setdefault(t, []).append(precision_at_k(ranked, relevant))\n    return {t: sum(v) / len(v) for t, v in groups.items()}\n')},
 {'id': '10.7', 'ch': 10, 'level': 2, 'sec': '10.1',
  'q': ['חיפוש עם סינון לפי מטא־מידע. השלם את <code class="ltr">search(index, meta, q, k, camera=None, t_from=None, t_to=None)</code>: ‏<span class="ltr">meta</span> היא רשימה של מילונים עם <span class="ltr">"camera"</span> ו־<span class="ltr">"t"</span>, באותו סדר כמו שורות <span class="ltr">index</span>. מחזירה את <span class="ltr">k</span> האינדקסים הטובים מבין השורות שעוברות את הסינונים (ממוינים מהגבוה).',
        '**א.** למה לסנן <i>לפני</i> שלוקחים את <span class="ltr">k</span> הראשונים, ולא אחרי?', '**ב.** מיליון שורות ושאילתה על מצלמה אחת מתוך מאה — איך היית מארגן את האינדקס?'],
  'hints': ['מסכה בוליאנית על השורות, וציון <span class="ltr">−inf</span> לכל מה שלא עובר.', 'אל תחזיר שורות עם <span class="ltr">−inf</span> אם יש פחות מ־<span class="ltr">k</span> שעוברות.'],
  'sol': ['**א.** אם לוקחים עשרה ואז מסננים, ייתכן שכל העשרה ממצלמה אחרת — והתוצאה ריקה, למרות שיש התאמות טובות במצלמה המבוקשת. סינון קודם, דירוג אחר כך (כמו תרגיל 6.2).', '**ב.** אינדקס נפרד לכל מצלמה (או מחיצה לפי מצלמה ויום): השאילתה מכפילה רק את המטריצה הרלוונטית — פי מאה פחות עבודה. ספריות חיפוש מקורב תומכות בסינון כזה, אבל מחיצות פשוטות מכסות את רוב המקרים.'],
  'test': T('השלם את search.',
            'import numpy as np\n\ndef search(index, meta, q, k, camera=None, t_from=None, t_to=None):\n    return list(np.argsort(-(index @ q))[:k])     # TODO: filters\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nindex = rng.normal(size=(100, 8)); q = rng.normal(size=8)\nmeta = [{'camera': 'A' if i % 2 else 'B', 't': float(i)} for i in range(100)]\nr = search(index, meta, q, 5, camera='A')\nassert len(r) == 5 and all(meta[i]['camera'] == 'A' for i in r), f'רק מצלמה A; קיבלתי {r}'\ns = index @ q; best_A = [i for i in np.argsort(-s) if i % 2][:5]\nassert [int(i) for i in r] == [int(i) for i in best_A], 'החמישה הטובים מבין שורות A, מהגבוה'\nr2 = search(index, meta, q, 10, t_from=10, t_to=13)\nassert sorted(int(i) for i in r2) == [10, 11, 12, 13], f'רק ארבע שורות בטווח — לא להשלים בשורות שלא עוברות; קיבלתי {[int(i) for i in r2]}'",
            'import numpy as np\n\ndef search(index, meta, q, k, camera=None, t_from=None, t_to=None):\n    ok = np.ones(len(meta), bool)\n    for i, m in enumerate(meta):\n        if camera is not None and m["camera"] != camera: ok[i] = False\n        if t_from is not None and m["t"] < t_from: ok[i] = False\n        if t_to is not None and m["t"] > t_to: ok[i] = False\n    s = np.where(ok, index @ q, -np.inf)\n    top = np.argsort(-s)[:k]\n    return [int(i) for i in top if ok[i]]\n')},
 {'id': '10.8', 'ch': 10, 'level': 2, 'sec': '10.1',
  'q': ['שלב 1, הבונוס: לקודד רק פריימים שהשתנו. השלם את <code class="ltr">changed(prev, cur, thr)</code>: שני פריימים בצבע (uint8). מקטינים כל אחד ל־64 על 64 בגווני אפור (<code class="ltr">cv2.INTER_AREA</code>), ומחזירים <span class="ltr">True</span> אם הממוצע של ההפרש המוחלט גדול מ־<span class="ltr">thr</span>. ו־<code class="ltr">select_frames(frames, thr)</code>: מחזירה את האינדקסים לקידוד — הראשון תמיד, ואז כל פריים שהשתנה ביחס <b>לאחרון שנבחר</b>.',
        '**א.** למה להשוות לאחרון שנבחר ולא לפריים הקודם?', '**ב.** מה יקרה בשקיעה, כשהאור משתנה לאט? ובענן שעובר?'],
  'hints': ['<code class="ltr">cv2.resize(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (64, 64), interpolation=cv2.INTER_AREA)</code>.', 'הפרש: <code class="ltr">np.abs(a.astype(np.int16) - b).mean()</code>.'],
  'sol': ['**א.** שינוי איטי (רכב שזוחל, צל שזז) קטן בין שני פריימים סמוכים — ואף פעם לא יעבור את הסף. מול האחרון שנבחר, השינוי מצטבר עד שהוא עובר.', '**ב.** שקיעה — השינוי מצטבר לאט ויגרום לבחירה כל כמה דקות: בסדר, ואפילו רצוי (המראה של הסצנה השתנה). ענן — שינוי פתאומי בכל הפריים, ייבחר פריים מיותר. אפשר לנרמל בהירות לפני ההפרש (להחסיר את הממוצע), או למדוד שינוי מקומי (כמה תאים ברשת השתנו) במקום ממוצע גלובלי.'],
  'test': T('השלם את changed ואת select_frames.',
            'import cv2\nimport numpy as np\n\ndef changed(prev, cur, thr):\n    return True     # TODO\n\ndef select_frames(frames, thr):\n    return list(range(len(frames)))     # TODO\n',
            "import numpy as np, cv2\nrng = np.random.default_rng(0)\nbg = rng.integers(60, 120, (240, 320, 3)).astype(np.uint8)\nframes = []\nfor t in range(30):\n    f = bg.copy()\n    if 10 <= t < 20: cv2.rectangle(f, (40, 60), (160, 160), (255, 255, 255), -1)\n    frames.append(f)\nassert not changed(frames[0], frames[1], 3), 'שני פריימים זהים — לא השתנו'\nassert changed(frames[9], frames[10], 3), 'מלבן לבן נכנס — השתנה'\nsel = select_frames(frames, 3)\nassert sel[0] == 0 and 10 in sel and 20 in sel, f'הראשון, הכניסה של המלבן והיציאה שלו; קיבלתי {sel}'\nassert len(sel) <= 8, f'רוב הפריימים זהים — צריך מעט מאוד; קיבלתי {len(sel)}'\nslow = [np.clip(bg.astype(int) + t, 0, 255).astype(np.uint8) for t in range(0, 40)]\nassert len(select_frames(slow, 3)) >= 5, 'שינוי איטי מצטבר — משווים לאחרון שנבחר'",
            'import cv2\nimport numpy as np\n\ndef small(f):\n    return cv2.resize(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (64, 64), interpolation=cv2.INTER_AREA)\n\ndef changed(prev, cur, thr):\n    return np.abs(small(prev).astype(np.int16) - small(cur)).mean() > thr\n\ndef select_frames(frames, thr):\n    sel = [0]\n    for i in range(1, len(frames)):\n        if changed(frames[sel[-1]], frames[i], thr):\n            sel.append(i)\n    return sel\n')},
 {'id': '10.9', 'ch': 10, 'level': 3, 'sec': '10.3',
  'q': ['**אתגר — הדירוג הדו־שלבי של שאלת הראיון.** במיליון שעות, אפילו מכפלה אחת על כל האינדקס יקרה. הרעיון: שלב גס — אינדקס <b>קטן</b> (הטלה לממד נמוך, ב־16 סיביות) שמחזיר <span class="ltr">m</span> מועמדים; שלב עדין — מדרגים רק אותם בוקטורים המלאים. השלם את <code class="ltr">two_stage(full, q, k, m, P)</code>: ‏<span class="ltr">P</span> היא מטריצת הטלה <span class="ltr">(d, d_small)</span>. האינדקס הגס הוא <span class="ltr">(full @ P)</span> ב־float16; מחזירה את <span class="ltr">k</span> הטובים מבין <span class="ltr">m</span> המועמדים, לפי הציון המלא.',
        '**א.** בבדיקה: 20,000 שורות של 256, הטלה ל־32. מה הכיסוי של העשרה האמיתיים עם <span class="ltr">m</span> = 10, ‏100, ‏1,000? וכמה עבודה נחסכה?', '**ב.** במערכת אמיתית, מה היה השלב העדין?'],
  'hints': ['גס: <code class="ltr">coarse = (full @ P).astype(np.float16)</code>, ‏<code class="ltr">cand = np.argsort(-(coarse.astype(np.float32) @ (q @ P)))[:m]</code>.', 'עדין: <code class="ltr">cand[np.argsort(-(full[cand] @ q))[:k]]</code>.'],
  'sol': ['**א.** בבדיקה (ממוצע על 10 זרעים): ‏<span class="ltr">m = 10</span> — רק 9% מהעשרה האמיתיים; ‏100 — 50%; ‏1,000 (5% מהשורות) — 100%. העבודה: <span class="ltr">20,000 · 32 + 1,000 · 256</span> — כ־0.9 מיליון פעולות במקום 5.1 — פי 5.7 פחות, וגם הזיכרון החם הוא פי 16 קטן. הלקח: השלב הגס חייב להחזיר <b>הרבה</b> מועמדים; הוא מסנן, לא מדרג.', '**ב.** במקום וקטורים מלאים — מודל כבד: Grounding DINO על מאות הפריימים הראשונים, או שאלה סגורה למודל שפה־ראייה (פרק 8). ואת השלב הגס עושה ספריית חיפוש מקורב (כמו FAISS עם דחיסה), שהיא גרסה חכמה בהרבה של ההטלה כאן.'],
  'test': T('השלם את two_stage.',
            'import numpy as np\n\ndef two_stage(full, q, k, m, P):\n    return np.argsort(-((full @ P) @ (q @ P)))[:k]     # TODO: re-rank m candidates with the full vectors\n',
            "import numpy as np\nrec = {10: [], 1000: []}\nfor seed in range(10):\n    rng = np.random.default_rng(seed); N, d = 20000, 256\n    centers = rng.normal(size=(50, d)); full = centers[rng.integers(50, size=N)] + 0.8 * rng.normal(size=(N, d)); full /= np.linalg.norm(full, axis=1, keepdims=True)\n    q = centers[3] + 0.5 * rng.normal(size=d); q /= np.linalg.norm(q)\n    P = rng.normal(size=(d, 32)) / np.sqrt(32)\n    truth = set(np.argsort(-(full @ q))[:10].tolist())\n    for m in rec:\n        r = two_stage(full, q, 10, m, P)\n        assert len(r) == 10, f'צריך להחזיר עשרה; קיבלתי {len(r)}'\n        rec[m].append(len(truth & set(int(i) for i in r)) / 10)\nassert np.mean(rec[1000]) >= 0.95, f'עם 1,000 מועמדים — כמעט כל העשרה האמיתיים; קיבלתי {np.mean(rec[1000]):.2f}'\nassert np.mean(rec[10]) < 0.5, 'עם 10 מועמדים — השלב הגס לבד, וחלש'",
            'import numpy as np\n\ndef two_stage(full, q, k, m, P):\n    coarse = (full @ P).astype(np.float16)\n    cand = np.argsort(-(coarse.astype(np.float32) @ (q @ P)))[:m]\n    return cand[np.argsort(-(full[cand] @ q))[:k]]\n')},
]

#@@CH@@

# ---------- validation ----------
def run(src, cwd=None):
    r = subprocess.run([sys.executable, '-c', src], capture_output=True, text=True, timeout=120, cwd=cwd)
    return r.stdout, r.stderr
STUB = 'import cv2\ncv2.imshow = lambda *a, **k: None\ncv2.waitKey = lambda *a, **k: -1\ncv2.destroyAllWindows = lambda *a, **k: None\n'
bad = 0
def wrap(body): return 'try:\n' + '\n'.join('    ' + l for l in body.split('\n')) + "\n    print('PASS')\nexcept Exception as e:\n    print('FAIL:', e)"
for e in X:
    t = e.get('test')
    if t:
        o1, e1 = run(t['starter'] + '\n\n' + wrap(t['body'])); o2, e2 = run(t['solved'] + '\n\n' + wrap(t['body']))
        ok = 'PASS' not in o1 and 'PASS' in o2 and not e2
        print('test', e['id'], 'OK' if ok else 'BAD', '| starter:', (o1.strip().splitlines() or [e1.strip()[-80:]])[-1][:90])
        if not ok: bad += 1; print('   solved ->', o2, e2[-300:])
    for part in ('q', 'sol'):
        for b in e[part]:
            if isinstance(b, dict) and 'code' in b and not b.get('norun'):
                with tempfile.TemporaryDirectory() as td:
                    o, er = run(STUB + b['code'], cwd=td)
                print('code', e['id'], part, 'OK' if not er else 'BAD', '|', o.strip().replace('\n', ' / ')[:90])
                if er: bad += 1; print(er[-400:])
                b['out'] = o
if bad: sys.exit('validation failed')

# ---------- emit ----------
exs, tests, hints, exsec, meta = {}, {}, {}, {}, {}
n = 0
for e in X:
    def blocks(items, tag):
        global n
        out = []
        for it in items:
            n += 1
            if isinstance(it, dict) and 'table' in it:
                out.append({'type': 'table', 'header': True, 'id': f'm7-x{n}', 'rows': [[[{'type': 'p', 'text': c}] for c in r] for r in it['table']]})
            elif isinstance(it, dict):
                out.append({'type': 'code', 'lang': it.get('lang', 'python'), 'text': it['code'], 'id': f'm7-x{n}', 'output': {'stdout': it.get('out', '')}})
            else:
                out.append({'type': 'p', 'text': it, 'id': f'm7-x{n}'})
        return out
    exs.setdefault(e['ch'], []).append({'id': e['id'], 'star': False, 'extra': True, 'blocks': blocks(e['q'], 'q'), 'solution': blocks(e['sol'], 's')})
    if e.get('test'): tests[e['id']] = {'task': e['test']['task'], 'starter': e['test']['starter'], 'test': wrap(e['test']['body'])}
    hints[e['id']] = e['hints']; exsec[e['id']] = e['sec']; meta[e['id']] = {'level': e['level'], 'sec': e['sec']}
for k, (lv, sec, ex) in META.items(): meta[k] = {'level': lv, 'sec': sec, 'explain': ex}; exsec[k] = sec
js = '''/* Module 6 — exercise levels, an explanation of what every question asks, and supplementary exercises
   for the sections the course's own sets do not reach (generated by exercises_m7.py). All of it is an ADDITION. */
(function () {
const L = window.LAYER.m7, M = window.CONTENT.m7;
const EXTRA = %s;
Object.keys(EXTRA).forEach(n => { const c = M.chapters.find(x => x.n === +n); if (c && !c.exercises.some(e => e.extra)) c.exercises.push(...EXTRA[n]); });
L.exMeta = %s;
Object.assign(L.codeTests, %s);
Object.assign(L.hints, %s);
Object.assign(L.exSection, %s);
})();
''' % tuple(json.dumps(x, ensure_ascii=False) for x in (exs, meta, tests, hints, exsec))
open('site/content/m7_exercises.js', 'w', encoding='utf8').write(js)
print('written:', sum(len(v) for v in exs.values()), 'extra exercises,', len(tests), 'new checks')


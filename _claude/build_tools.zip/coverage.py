"""Coverage check: every visible character of the PDF must appear in the extracted
content exactly as many times (spaces ignored; mirrored bracket glyphs counted as
one pair; page headers/footers and the byline excluded). Also compares Hebrew words
as whole words, so a letter moved inside a word is caught too."""
import json, sys, collections, re, logging
import pdfplumber
logging.getLogger('pdfminer').setLevel(logging.ERROR)

MIR = str.maketrans(')]}>', '([{<')
HEBW = re.compile(r'[א-ת׳״״׳"]+')

def pdf_chars(path):
    pdf = pdfplumber.open(path)
    c = collections.Counter(); words = collections.Counter()
    for pno, p in enumerate(pdf.pages):
        chars = [ch for ch in p.chars if round(ch['size'], 1) != 6.0]
        if pno == 0:
            chars = [ch for ch in chars if not (80 < ch['top'] < 110 and round(ch['size'], 1) in (9.0, 12.0))]
        for ch in chars:
            t = ch['text']
            if t.strip() and t not in '​‎‏﻿':
                c[t.translate(MIR)] += 1
    return c

def unmd(s):
    s = re.sub(r'\\(.)', lambda m: '\x00' + m.group(1), s)
    s = re.sub(r'`[^`]*`', lambda m: m.group(0).replace('*', '\x01'), s)
    s = s.replace('**', '').replace('`', '')
    return s.replace('\x00', '').replace('\x01', '*')

def out_chars(doc):
    c = collections.Counter()
    def add(s, md=True):
        if md: s = unmd(s)
        for ch in s:
            if ch.strip(): c[ch.translate(MIR)] += 1
    # a header row that the PDF printer repeated at the top of a continued table page
    for row in doc.get('dropped_repeated_headers', []):
        for cell in row:
            for s in cell: add(s['text'], md=s['type'] != 'code')
    for b in doc['blocks']:
        if b['type'] == 'table':
            for r in b['rows']:
                for cell in r:
                    for s in cell: add(s['text'], md=s['type'] != 'code')
        elif b['type'] == 'img':
            pass
        else:
            add(b['text'], md=b['type'] != 'code')
    return c

def heb_words_pdf(path):
    # visual Hebrew words are stored reversed letter by letter
    pdf = pdfplumber.open(path)
    w = collections.Counter()
    import extract
    for pno, p in enumerate(pdf.pages):
        chars = [ch for ch in p.chars if round(ch['size'], 1) != 6.0]
        if pno == 0:
            chars = [ch for ch in chars if not (80 < ch['top'] < 110 and round(ch['size'], 1) in (9.0, 12.0))]
        for L in extract.group_lines(chars):
            s = ''.join(i['t'] for i in extract.build_line(L['chars']))
            for m in HEBW.findall(s): w[m[::-1]] += 1
    return w

def heb_words_out(doc):
    w = collections.Counter()
    def add(s):
        for m in HEBW.findall(unmd(s)): w[m] += 1
    for row in doc.get('dropped_repeated_headers', []):
        for cell in row:
            for s in cell: add(s['text'])
    for b in doc['blocks']:
        if b['type'] == 'table':
            for r in b['rows']:
                for cell in r:
                    for s in cell: add(s['text'])
        elif b['type'] != 'img':
            add(b['text'])
    return w

if __name__ == '__main__':
    pdfpath, jpath = sys.argv[1], sys.argv[2]
    doc = json.load(open(jpath))
    a, b = pdf_chars(pdfpath), out_chars(doc)
    missing, extra = a - b, b - a
    total = sum(a.values())
    print(f'characters in PDF: {total}, in site content: {sum(b.values())}')
    print('missing:', dict(missing) or 'none')
    print('extra:', dict(extra) or 'none')
    wa, wb = heb_words_pdf(pdfpath), heb_words_out(doc)
    # the PDF draws a few words without the space between them (a layout artifact): count them as the two words
    for glued, parts in {'לאהורץ': ('לא', 'הורץ'), '"ו': ('ו', '"')}.items():
        n = wa.pop(glued, 0)
        for w in parts: wa[w] += n
    wm, we = wa - wb, wb - wa
    print(f'Hebrew words in PDF: {sum(wa.values())}, in site content: {sum(wb.values())}')
    print('words missing:', dict(wm) or 'none')
    print('words extra:', dict(we) or 'none')
    ok = not missing and not extra and not wm and not we
    imgs = sum(1 for x in doc['blocks'] if x['type'] == 'img')
    print('images:', imgs)
    print('RESULT:', 'PASS 100%' if ok else 'FAIL')
    json.dump({'chars_pdf': total, 'chars_site': sum(b.values()), 'heb_words_pdf': sum(wa.values()),
               'heb_words_site': sum(wb.values()), 'images': imgs, 'pass': ok},
              open(jpath.replace('.json', '.coverage.json'), 'w'))

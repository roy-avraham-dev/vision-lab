import numpy as np
import cv2

# --- 15 synthetic images of the board from a camera whose answer we know (section 5.2): fx = fy = 1100, centre (650, 350), k1 = -0.28, k2 = 0.09
K_true = np.array([[1100, 0, 650], [0, 1100, 350], [0, 0, 1.0]])
dist_true = (-0.28, 0.09, 0.0, 0.0, 0.0)

def distort_normalized(xy, k1, k2, p1=0, p2=0, k3=0):
    x, y = xy[:, 0], xy[:, 1]
    r2 = x * x + y * y
    radial = 1 + k1 * r2 + k2 * r2 ** 2 + k3 * r2 ** 3
    return np.c_[x * radial + 2 * p1 * x * y + p2 * (r2 + 2 * x * x), y * radial + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y]

def render_board(R, t, w=1280, h=720, sq=0.025):
    u, v = np.meshgrid(np.arange(w), np.arange(h))
    xyd = np.c_[(u.ravel() - K_true[0, 2]) / K_true[0, 0], (v.ravel() - K_true[1, 2]) / K_true[1, 1]]
    xy = xyd.copy()
    for _ in range(20):                                   # chapter 4: undo the distortion
        xy = xy - (distort_normalized(xy, *dist_true) - xyd)
    rays = np.c_[xy, np.ones(len(xy))] @ R                # chapter 3: the ray in board coordinates (R.T @ ray)
    C = -R.T @ t
    s = -C[2] / rays[:, 2]                                # where the ray meets the board plane Z = 0
    X, Y = C[0] + s * rays[:, 0], C[1] + s * rays[:, 1]
    i, j = np.floor(X / sq), np.floor(Y / sq)
    img = np.full(len(X), 110.0)                           # gray table behind the board
    paper = (s > 0) & (X > -2.6 * sq) & (X < 11.6 * sq) & (Y > -2.6 * sq) & (Y < 8.6 * sq)
    img[paper] = 235
    squares = paper & (i >= -1) & (i <= 8) & (j >= -1) & (j <= 5)
    img[squares & ((i + j) % 2 == 0)] = 25
    img = cv2.GaussianBlur(img.reshape(h, w), (0, 0), 0.8)
    img += np.random.default_rng(int(abs(t[0]) * 1e4)).normal(0, 2, img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)

rng = np.random.default_rng(5)
images = []
for sx, sy in [(0, 0), (-1, -1), (1, -1), (-1, 1), (1, 1), (0, -1), (0, 1), (-1, 0), (1, 0), (-0.6, -0.5), (0.6, 0.5), (0.5, -0.6), (-0.5, 0.6), (0, 0), (0.2, -0.2)]:
    Z = 0.42 + 0.18 * rng.random()
    R, _ = cv2.Rodrigues(np.array([(rng.random() - 0.5) * 0.9, (rng.random() - 0.5) * 0.9, (rng.random() - 0.5) * 0.6]))
    target = np.array([sx * 0.4 * Z * 640 / 1100, sy * 0.3 * Z * 360 / 1100, Z])
    t = target - R @ np.array([0.1, 0.0625, 0])
    images.append(render_board(R, t))
print(len(images), "synthetic images,", images[0].shape)

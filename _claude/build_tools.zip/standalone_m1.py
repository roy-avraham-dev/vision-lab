# Stand-alone additions for the code examples of module 1 (chapters 1-3): writes site/content/m1_codefull.js,
# verifies every full script in a fresh process and an empty folder, and refreshes the precomputed outputs in m1.js.
import json, os, subprocess, sys, tempfile, base64, textwrap
PIP = 'אם PyCharm מסמן את `cv2` או את `numpy` באדום, הרץ פעם אחת בטרמינל שלו: `pip install opencv-python numpy`.'
IMP = {'code': 'import cv2\nimport numpy as np\n', 'say': 'שתי הספריות שהקוד משתמש בהן. ' + PIP}
def show(*names, extra=''):
    return {'code': extra + ''.join(f'cv2.imshow("{n}", {n})\n' for n in names) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()',
            'say': 'מציג את התוצאה: ' + ('חלון אחד' if len(names) == 1 else f'{len(names)} חלונות') + ' (' + ', '.join(f'`{n}`' for n in names) + '). לחיצה על מקש כלשהו, כשאחד החלונות בפוקוס, סוגרת אותם.'}
PAPER = 'gray = np.full((300, 400), 200, np.uint8)                                  # נייר בהיר\ncv2.putText(gray, "CV", (60, 200), cv2.FONT_HERSHEY_SIMPLEX, 5, 50, 20)    # טקסט כהה\n'
F = {
 'm1-b33': {'pre': [IMP], 'post': [{'code': 'cv2.imshow("drawing", canvas)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'פותח חלון עם הציור ומחכה למקש. הקובץ `drawing.png` נשמר בתיקיית הפרויקט.'}]},
 'm1-b39': {'pre': [IMP], 'post': [{'code': 'print("saved ball.mp4")', 'say': 'הודעה שהקובץ נכתב. הוא נשמר בתיקיית הפרויקט, ואפשר לפתוח אותו בכל נגן וידאו.'}], 'local': True},
 'm1-b43': {'pre': [{'code': 'import os\nimport cv2\nimport numpy as np\n\nif not os.path.exists("ball.mp4"):          # יוצר את סרטון הבדיקה אם הוא עוד לא קיים\n    out = cv2.VideoWriter("ball.mp4", cv2.VideoWriter_fourcc(*"mp4v"), 30.0, (640, 480))\n    for i in range(90):\n        frame = np.zeros((480, 640, 3), np.uint8)\n        cv2.circle(frame, (50 + i * 6, 240), 20, (0, 200, 255), -1)\n        out.write(frame)\n    out.release()\n',
                     'say': 'הספריות, ויצירת סרטון הבדיקה מהדוגמה הקודמת אם הוא עוד לא קיים בתיקייה. ' + PIP}], 'local': True,
            'note': '**כשמריצים במחשב:** הסרטון חולף בפחות משנייה, כי `waitKey(1)` מחכה רק אלפית שנייה בין פריים לפריים, והמספר שמוצג ב־FPS גבוה מאוד. כדי לראות אותו בקצב רגיל שנה ל־`cv2.waitKey(33)`. יציאה באמצע: מקש `q`, כשהחלון בפוקוס והמקלדת באנגלית.'},
 'm1-b72': {'post': [show('img', 'mask_bgr', 'mask_hsv')]},
 'm1-b77': {'pre': [IMP], 'local': True, 'note': '**כשמריצים במחשב:** צריך מצלמה מחוברת. אם אין, `cap.read()` מחזיר `ok = False` והתוכנית מסתיימת מיד בלי הודעה. יציאה: מקש `q`, כשהחלון בפוקוס והמקלדת באנגלית — ואז מודפס הטווח שבחרת.'},
 'm1-b82': {'pre': [IMP, {'code': 'img = np.full((200, 400, 3), 60, np.uint8)             # רקע אפור כהה\ncv2.circle(img, (100, 100), 60, (20, 60, 220), -1)     # אדום שנוטה לכתום\ncv2.circle(img, (300, 100), 60, (70, 20, 220), -1)     # אדום שנוטה לסגול\nhsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)\n', 'say': 'תמונת בדיקה עם שני עיגולים אדומים, אחד מכל צד של האפס במעגל הגוון, והמרה שלה למרחב הגוון. הקוד של הסעיף מניח ש־`hsv` כבר קיים.'}],
            'post': [show('img', 'red_mask', extra='print(cv2.countNonZero(mask1), cv2.countNonZero(mask2), cv2.countNonZero(red_mask))\n')]},
 'm1-b104': {'pre': [IMP, {'code': PAPER, 'say': 'תמונת בדיקה באפור: נייר בהיר (200) עם טקסט כהה (50). הקוד של הסעיף מניח ש־`gray` כבר קיים.'}],
             'post': [show('gray', 'mask', extra='print(cv2.countNonZero(mask))\n')]},
 'm1-b110': {'pre': [IMP, {'code': PAPER + '_, mask = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY_INV)\n', 'say': 'תמונת הבדיקה מהסעיף הקודם והמסכה שלה. הקוד של הסעיף מניח ש־`mask` כבר קיים.'}],
             'post': [show('mask', 'left_text', 'background', extra='print(cv2.countNonZero(mask), cv2.countNonZero(left_text), cv2.countNonZero(background))\n')]},
 'm1-b118': {'pre': [IMP], 'post': [show('img', 'otsu')]},
 'm1-b124': {'pre': [IMP], 'post': [show('img', 'glob', 'adapt', extra='print(cv2.countNonZero(text), cv2.countNonZero(glob), cv2.countNonZero(adapt))   # טקסט אמיתי, אוצו, מסתגל\n')]},
 'm1-b156': {'post': [{'code': 'row1 = np.hstack([gauss_noisy, cv2.GaussianBlur(gauss_noisy, (5, 5), 0), cv2.bilateralFilter(gauss_noisy, 9, 75, 75)])\nrow2 = np.hstack([sp_noisy, cv2.GaussianBlur(sp_noisy, (5, 5), 0), cv2.medianBlur(sp_noisy, 5)])\nboth = np.vstack([row1, row2])\ncv2.imshow("both", both)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'מציג את התוצאות זו לצד זו, כדי לראות את המספרים בעין. שורה עליונה: רעש גאוסיאני, אחרי גאוסיאני, אחרי דו־צדדי. שורה תחתונה: מלח ופלפל, אחרי גאוסיאני (הנקודות נמרחו לכתמים), אחרי חציוני (נעלמו). `np.hstack` מצמיד תמונות לרוחב ו־`np.vstack` לגובה.'}]},
 'm1-b187': {'post': [{'code': 'shown = np.uint8(np.clip(magnitude / magnitude.max() * 255, 0, 255))\ncv2.imshow("img", img)\ncv2.imshow("shown", shown)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'כדי לראות את גודל הגרדיאנט כתמונה, מנרמלים אותו לטווח 0 עד 255 (חלוקה במקסימום וכפל ב־255) וממירים לטיפוס של תמונה. רק לתצוגה: לחישובים ממשיכים להשתמש ב־`magnitude` עצמו. לחיצה על מקש סוגרת את החלונות.'}]},
 'm1-b199': {'pre': [IMP, {'code': 'img = np.zeros((200, 200), np.uint8)\ncv2.rectangle(img, (50, 50), (150, 150), 200, -1)\n', 'say': 'הריבוע מהקוד של סעיף 5.2. הקוד של הסעיף מניח ש־`img` כבר קיים.'}], 'post': [show('noisy', 'edges_noisy', 'edges_blurred')]},
 'm1-b494': {'pre': [IMP, {'code': 'img = np.zeros((200, 200), np.uint8)\ncv2.rectangle(img, (50, 50), (150, 150), 200, -1)\n', 'say': 'הריבוע מסעיף 5.2, שעליו הפתרון רץ.'}], 'post': [{'code': 'print(np.nonzero(keep[100])[0])        # [ 49  50 150 151] — two pixels per edge\nkeep2 = (gx > left) & (gx >= right) & (gx > 0)\nprint(np.nonzero(keep2[100])[0])       # [ 49 150] — one pixel per edge', 'say': 'מדפיס אילו עמודות נשארו בשורה 100, ואחר כך מנסה את התיקון מהפתרון: תנאי חזק משמאל וחלש מימין. נשאר פיקסל אחד לכל קצה.'}]},
 'm1-b229': {'post': [{'code': 'cv2.imshow("mask", mask)\ncv2.imshow("opened", opened)\ncv2.imshow("cleaned", cleaned)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'מציג את שלוש המסכות: הגולמית (נקודות וחורים), אחרי פתיחה (הנקודות נעלמו, החורים גדלו), ואחרי פתיחה וסגירה. לחיצה על מקש סוגרת.'}]},
 'm1-b502': {'pre': [IMP], 'post': [{'code': 'rng = np.random.default_rng(0)\nmask = np.where(rng.random((100, 150)) < 0.7, 255, 0).astype(np.uint8)\nlib = cv2.erode(mask, np.ones((3, 3), np.uint8), borderType=cv2.BORDER_CONSTANT, borderValue=0)\nprint(np.array_equal(my_erode(mask), lib))', 'say': 'בדיקה: מסכה אקראית, והשוואה לכירסום של הספרייה. צריך להגיד לספרייה שמחוץ לתמונה יש אפסים (`BORDER_CONSTANT` עם 0), כמו הריפוד של `np.pad`. בלי זה הספרייה מתעלמת מהשוליים, והתוצאות שונות בשורה ובעמודה החיצוניות.'}]},
 'm1-b253': {'post': [{'code': 'shown = img.copy()\ncv2.drawContours(shown, contours, -1, (0, 255, 0), 2)\ncv2.imshow("shown", shown)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'מצייר את כל המתארים בירוק על עותק של התמונה. ה־`-1` אומר "את כולם", ו־2 הוא העובי. לחיצה על מקש סוגרת.'}]},
 'm1-b263': {'pre': [IMP, {'code': 'img = np.full((300, 400, 3), 40, np.uint8)\ncv2.circle(img, (100, 150), 45, (0, 140, 255), -1)\ncv2.rectangle(img, (220, 80), (330, 140), (0, 140, 255), -1)\ncv2.circle(img, (300, 240), 4, (0, 140, 255), -1)\nhsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)\nmask = cv2.inRange(hsv, np.array([5, 120, 40]), np.array([25, 255, 255]))\ncontours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)\n', 'say': 'תמונת הבדיקה והמתארים מסעיף 7.2. הקוד של הסעיף מניח ש־`contours` כבר קיים.'}]},
 'm1-b268': {'pre': [{'code': 'import os\nimport cv2\nimport numpy as np\n\nif not os.path.exists("ball.mp4"):          # creates the test video of section 1.4 if it is missing\n    out = cv2.VideoWriter("ball.mp4", cv2.VideoWriter_fourcc(*"mp4v"), 30.0, (640, 480))\n    for i in range(90):\n        frame = np.zeros((480, 640, 3), np.uint8)\n        cv2.circle(frame, (50 + i * 6, 240), 20, (0, 200, 255), -1)\n        out.write(frame)\n    out.release()\n', 'say': 'הספריות, ויצירת `ball.mp4` מסעיף 1.4 אם הוא עוד לא קיים בתיקייה. ' + PIP}], 'local': True, 'post': [{'code': 'truth = np.array([(50 + 6 * i, 240) for i in range(len(track))])\nprint(np.abs(np.array(track) - truth).max())     # the largest error, in pixels', 'say': 'בודק את המסלול מול המיקום האמיתי של הכדור בכל פריים, ומדפיס את השגיאה הגדולה ביותר.'}],
             'note': '**כשמריצים במחשב:** אין חלון — העוקב רק מחשב ומדפיס. הסרטון נקרא מהתיקייה שבה הקובץ רץ; אם `track` ריק, `ball.mp4` לא נמצא שם.'},
 'm1-b283': {'pre': [IMP, {'code': 'img = np.zeros((300, 400, 3), np.uint8)\ncv2.circle(img, (200, 150), 60, (0, 140, 255), -1)\n', 'say': 'תמונת בדיקה בגודל 300 על 400, עם עיגול כתום. הקוד של הסעיף מניח ש־`img` כבר קיים.'}], 'post': [{'code': 'print(img.shape, small.shape, fixed.shape)', 'say': 'מדפיס את שלוש הצורות. שים לב ש־`fixed` יוצא `(480, 640, 3)`: ביקשנו `(640, 480)` — רוחב ואז גובה.'}]},
 'm1-b290': {'post': [show('img', 'shifted', 'rotated')]},
 'm1-b299': {'pre': [IMP], 'post': [show('src', 'flat')]},
 'm1-b325': {'pre': [{'code': "import os\n\nif not os.path.exists(\"scene.py\"):          # creates scene.py from exercise 9.1 if it is missing\n    with open(\"scene.py\", \"w\", encoding=\"utf8\") as f:\n        f.write('''import cv2\nimport numpy as np\n\ndef make_scene(seed=0, h=480, w=640):\n    rng = np.random.default_rng(seed)\n    img = np.full((h, w, 3), 128, np.uint8)\n    for _ in range(60):\n        color = tuple(int(c) for c in rng.integers(0, 256, 3))\n        x, y = int(rng.integers(0, w)), int(rng.integers(0, h))\n        if rng.random() < 0.5:\n            cv2.circle(img, (x, y), int(rng.integers(8, 40)), color, -1)\n        else:\n            cv2.rectangle(img, (x, y), (x + int(rng.integers(10, 60)), y + int(rng.integers(10, 60))), color, -1)\n    return img\n''')\n    import importlib\n    importlib.invalidate_caches()           # let Python see the new file right away\n", 'say': 'הקוד מייבא את `make_scene` מהקובץ `scene.py` של תרגיל 9.1. השורות האלה יוצרות את הקובץ בתיקייה, אם הוא עוד לא שם — כך הקוד רץ גם בקובץ חדש.'}], 'post': [{'code': 'shown = cv2.drawMatches(img1, kp1, img2, kp2, good[:60], None)\ncv2.imshow("shown", shown)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'מצייר 60 מההתאמות הטובות: שתי התמונות זו לצד זו, וקו בין כל זוג. לחיצה על מקש סוגרת.'}]},
 'm1-b334': {'pre': [{'code': "import os\n\nif not os.path.exists(\"scene.py\"):          # creates scene.py from exercise 9.1 if it is missing\n    with open(\"scene.py\", \"w\", encoding=\"utf8\") as f:\n        f.write('''import cv2\nimport numpy as np\n\ndef make_scene(seed=0, h=480, w=640):\n    rng = np.random.default_rng(seed)\n    img = np.full((h, w, 3), 128, np.uint8)\n    for _ in range(60):\n        color = tuple(int(c) for c in rng.integers(0, 256, 3))\n        x, y = int(rng.integers(0, w)), int(rng.integers(0, h))\n        if rng.random() < 0.5:\n            cv2.circle(img, (x, y), int(rng.integers(8, 40)), color, -1)\n        else:\n            cv2.rectangle(img, (x, y), (x + int(rng.integers(10, 60)), y + int(rng.integers(10, 60))), color, -1)\n    return img\n''')\n    import importlib\n    importlib.invalidate_caches()           # let Python see the new file right away\n\nimport cv2\nimport numpy as np\nfrom scene import make_scene\n\nimg1 = make_scene(0)\nH_true = np.array([[0.9, -0.15, 60], [0.1, 0.95, 20], [0.0002, 0.0001, 1]])\nimg2 = cv2.warpPerspective(img1, H_true, (640, 480))\ng1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)\ng2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)\norb = cv2.ORB_create(nfeatures=1000)\nkp1, des1 = orb.detectAndCompute(g1, None)\nkp2, des2 = orb.detectAndCompute(g2, None)\nknn = cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(des1, des2, k=2)\ngood = [m for m, n in knn if m.distance < 0.75 * n.distance]\n", 'say': 'הקוד של סעיף 9.3: הסצנה, ההומוגרפיה האמיתית, הנקודות, וההתאמות שעברו את מבחן היחס. הקוד של הסעיף מניח שכל אלה כבר קיימים.'}], 'post': [{'code': 'corners = np.float32([[0, 0], [640, 0], [640, 480], [0, 480]]).reshape(-1, 1, 2)\ntrue = cv2.perspectiveTransform(corners, H_true)\nfor name, M in [("least squares", H_plain), ("RANSAC", H)]:\n    err = np.linalg.norm(cv2.perspectiveTransform(corners, M) - true, axis=2).max()\n    print(name, round(float(err), 1))', 'say': 'הטבלה של הסעיף: מעבירה את ארבע הפינות של התמונה דרך כל אחת מההומוגרפיות, ומודדת כמה הן רחוקות מהמקום האמיתי.'}]},
 'm1-b517': {'post': [{'code': 'img = make_scene(0)\ncv2.imshow("img", img)\ncv2.waitKey(0)\ncv2.destroyAllWindows()', 'say': 'מצייר את הסצנה עם זרע 0 ומציג אותה. כשהקובץ נקרא `scene.py`, השורות האלה ירוצו גם כשמייבאים אותו — לכן בקובץ עצמו עדיף לעטוף אותן ב־`if __name__ == "__main__":`.'}]},
 'm1-b525': {'pre': [IMP]},
 'm1-b473': {'pre': [IMP], 'post': [{'code': 'img = np.full((300, 400, 3), 90, np.uint8)\ncv2.circle(img, (200, 150), 80, (0, 140, 255), -1)\nlower, upper = pick_range(img, 200, 150)\nprint("lower:", lower, "upper:", upper)', 'say': 'דוגמת שימוש: הכדור הכתום מסעיף 2.3, ובחירת טווח סביב הפיקסל שבמרכזו.'}]},
 'm1-b481': {'pre': [IMP], 'post': [{'code': 'gray = np.full((300, 400), 200, np.uint8)\ncv2.putText(gray, "CV", (60, 200), cv2.FONT_HERSHEY_SIMPLEX, 5, 50, 20)\nnoise = np.random.default_rng(0).normal(0, 15, gray.shape)\ngray = np.clip(gray + noise, 0, 255).astype(np.uint8)\nt, _ = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)\nprint("my_otsu:", my_otsu(gray), "cv2:", t)', 'say': 'דוגמת שימוש: התמונה מסעיף 3.3, והשוואה בין הסף שלנו לסף של הספרייה.'}]},
}
SCENE_PRE = {'code': F['m1-b325']['pre'][0]['code'], 'say': 'הקוד מייבא את `make_scene` מהקובץ `scene.py` של תרגיל 9.1. השורות האלה יוצרות את הקובץ בתיקייה אם הוא עוד לא שם — כך הקוד רץ גם בקובץ חדש.'}
LK_SETUP = ('import cv2\nimport numpy as np\nfrom scene import make_scene\n\ng = cv2.cvtColor(make_scene(1), cv2.COLOR_BGR2GRAY)\nM = np.float32([[1, 0, 4], [0, 1, -3]])\n'
            'g2 = cv2.warpAffine(g, M, (640, 480), borderMode=cv2.BORDER_REFLECT)\np0 = cv2.goodFeaturesToTrack(g, maxCorners=200, qualityLevel=0.01, minDistance=10)\n')
F['m1-b364'] = {'pre': [SCENE_PRE], 'post': [{'code': 'shown = cv2.cvtColor(g2, cv2.COLOR_GRAY2BGR)\nfor (x0, y0), (x1, y1) in zip(p0.reshape(-1, 2)[ok], p1.reshape(-1, 2)[ok]):\n    tip = (int(x0 + 4 * (x1 - x0)), int(y0 + 4 * (y1 - y0)))          # the motion, 4 times longer\n    cv2.arrowedLine(shown, (int(x0), int(y0)), tip, (0, 255, 0), 1, tipLength=0.3)\ncv2.imshow("shown", shown)\ncv2.waitKey(0)\ncv2.destroyAllWindows()',
    'say': 'מצייר על הפריים השני חץ לכל נקודה שעוקבה: מהמיקום הישן לכיוון החדש. התנועה היא 5 פיקסלים בלבד, ולכן החץ מוארך פי 4 כדי שיהיה אפשר לראות אותו. כל החיצים באותו כיוון — ימינה ולמעלה. לחיצה על מקש סוגרת.'}]}
F['m1-b374'] = {'pre': [SCENE_PRE, {'code': LK_SETUP, 'say': 'הקוד של סעיף 10.3: שני הפריימים (`g`, `g2`) והפינות `p0`. הקוד של הסעיף משתמש בשלושתם.'}],
    'post': [{'code': 'hsv = np.zeros((480, 640, 3), np.uint8)\nhsv[..., 0] = angle * 180 / np.pi / 2                      # direction -> hue (0..179)\nhsv[..., 1] = 255\nhsv[..., 2] = cv2.normalize(magnitude, None, 0, 255, cv2.NORM_MINMAX)   # size -> brightness\nshown = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)\ncv2.imshow("g", g)\ncv2.imshow("shown", shown)\ncv2.waitKey(0)\ncv2.destroyAllWindows()',
    'say': 'מציג את הזרימה כתמונה (תרגיל 10.3): הגוון לפי הכיוון, הבהירות לפי הגודל. כל מה שזז — באותו צבע, כי כל התמונה זזה באותו כיוון. באמצע צורות אחידות — כהה: שם הזרימה כמעט אפס.'}]}
F['m1-b533'] = {'pre': [SCENE_PRE, {'code': 'import cv2\nimport numpy as np\nfrom scene import make_scene\n', 'say': 'הספריות והסצנה של פרק 9.'}],
    'post': [{'code': 'g1 = cv2.cvtColor(make_scene(1), cv2.COLOR_BGR2GRAY).astype(np.float64)\npts = cv2.goodFeaturesToTrack(g1.astype(np.uint8), 200, 0.01, 10).reshape(-1, 2).astype(int)\nfor shift in (1, 10):\n    M = np.float32([[1, 0, shift], [0, 1, 0]])\n    g2 = cv2.warpAffine(g1, M, (640, 480), borderMode=cv2.BORDER_REFLECT)\n    res = [lk_point(g1, g2, x, y) for x, y in pts if 15 < x < 625 and 15 < y < 465]\n    print(shift, np.round(np.median(res, axis=0), 2) + 0.0)',
    'say': 'בודק את הפונקציה על כל פינות הסצנה (חוץ מאלה שקרובות מדי לשוליים, שם החלון יוצא מהתמונה): הזזה של פיקסל אחד ימינה, ואז של 10. מדפיס את החציון של התוצאות. `+ 0.0` רק מונע הדפסה של `-0.`.'}]}

p = 'site/content/m1.js'; s = open(p, encoding='utf8').read(); k = s.index('= {', 40) + 2
d = json.loads(s[k:].rstrip().rstrip(';'))
blocks = {}
for ch in d['chapters']:
    for sec in ch['sections']:
        for b in sec['blocks']:
            if b['type'] == 'code': blocks[b['id']] = b
    for e in ch['exercises']:
        for b in e['blocks'] + e['solution']:
            if b['type'] == 'code': blocks[b['id']] = b
# ---- chapter 11: the code blocks build on each other; each one gets what it needs from the previous ones ----
_mk = blocks['m1-b394']['text'].strip()
SHAKY_PRE = {'code': SCENE_PRE['code'] + '\nimport cv2\nimport numpy as np\nfrom scene import make_scene\n\nif not os.path.exists("shaky.mp4"):          # creates the shaky test video of section 11.2 if it is missing\n' + '\n'.join('    ' + l if l.strip() else '' for l in _mk.split('\n') if not l.startswith(('import ', 'from '))) + '\n',
             'say': 'יוצר את `scene.py` (תרגיל 9.1) ואת סרטון הבדיקה `shaky.mp4` (סעיף 11.2), אם הם עוד לא בתיקייה — כך הקוד רץ גם בקובץ חדש.'}
FM_PRE = {'code': blocks['m1-b399']['text'].strip() + '\n', 'say': 'הפונקציה `frame_motion` מסעיף 11.3: התנועה בין שני פריימים.'}
ST_PRE = {'code': blocks['m1-b403']['text'].strip() + '\n', 'say': 'הפונקציות של סעיף 11.4: `read_frames`, `smooth_path` ו־`stabilize`.'}
F['m1-b394'] = {'pre': [SCENE_PRE], 'post': [{'code': 'cap = cv2.VideoCapture("shaky.mp4")\nprint(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), "frames written to shaky.mp4")\ncap.release()', 'say': 'פותח את הקובץ שנכתב ובודק כמה פריימים יש בו — 120. אפשר לפתוח את `shaky.mp4` בכל נגן וידאו ולראות את הרעידה.'}], 'local': True}
F['m1-b399'] = {'pre': [SHAKY_PRE], 'post': [{'code': 'cap = cv2.VideoCapture("shaky.mp4")\n_, f1 = cap.read()\n_, f2 = cap.read()\ncap.release()\ng1 = cv2.cvtColor(f1, cv2.COLOR_BGR2GRAY)\ng2 = cv2.cvtColor(f2, cv2.COLOR_BGR2GRAY)\ndx, dy, da = frame_motion(g1, g2)\nprint(round(float(dx), 2), round(float(dy), 2), round(float(np.degrees(da)), 3))   # pixels, pixels, degrees', 'say': 'מנסה את הפונקציה על שני הפריימים הראשונים של הסרטון, ומדפיס את ההזזה בפיקסלים ואת הסיבוב במעלות.'}], 'local': True}
F['m1-b403'] = {'pre': [SHAKY_PRE, FM_PRE], 'post': [{'code': 'frames = read_frames("shaky.mp4")\nstable, trajectory, correction = stabilize(frames)\nprint(len(stable), np.round(np.abs(correction).max(axis=0), 1))     # frames, largest correction (x, y, angle)\nh, w = frames[0].shape[:2]\nout = cv2.VideoWriter("stable.mp4", cv2.VideoWriter_fourcc(*"mp4v"), 30.0, (2 * w, h))\nfor a, b in zip(frames, stable):\n    out.write(np.hstack([a, b]))                     # original | stabilized, side by side\nout.release()\ncv2.imshow("frame 60", np.hstack([frames[60], stable[60]]))\ncv2.waitKey(0)\ncv2.destroyAllWindows()',
    'say': 'מריץ את המייצב על הסרטון, מדפיס את התיקון הגדול ביותר בכל עמודה, וכותב את `stable.mp4`: המקורי משמאל והמיוצב מימין — פתח אותו בנגן כדי לראות את ההבדל. החלון מציג את פריים 60 בשתי הגרסאות.'}], 'local': True}
F['m1-b408'] = {'pre': [SHAKY_PRE, FM_PRE, ST_PRE], 'local': True}

_stab = 'import cv2\nimport numpy as np\n\n' + blocks['m1-b399']['text'].strip() + '\n\n' + blocks['m1-b403']['text'].strip() + '\n'
STAB_PRE = {'code': 'import importlib\n\nif not os.path.exists("stab.py"):            # creates stab.py (sections 11.3 and 11.4) if it is missing\n    with open("stab.py", "w", encoding="utf8") as f:\n        f.write(' + repr(_stab) + ')\n    importlib.invalidate_caches()\n',
            'say': 'יוצר את `stab.py` — הפונקציות של סעיפים 11.3 ו־11.4 — אם הוא עוד לא בתיקייה. בקובץ הזה יש בדיוק את מה שהסעיף מבקש לשים שם.'}
F['m1-b433'] = {'pre': [SHAKY_PRE, STAB_PRE], 'post': [{'code': 'cap = cv2.VideoCapture("result.mp4")\nprint("result.mp4:", int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), "frames of", int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), "x", int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))\ncap.release()',
    'say': 'בודק שסרטון הפלט נכתב: 120 פריימים ברוחב כפול (שני הצדדים). פתח את `result.mp4` בנגן — משמאל המקורי עם השובל השבור, מימין המיוצב.'}], 'local': True}

def full(bid):
    f = F.get(bid, {}); return ''.join(x['code'] + '\n' for x in f.get('pre', [])) + blocks[bid]['text'] + ''.join('\n' + x['code'] for x in f.get('post', []))
HARNESS = textwrap.dedent('''
    import sys, json, base64, io, contextlib
    import cv2, numpy as np
    SHOWN = {}; CALLS = []
    def _imshow(name, im): SHOWN[name] = np.asarray(im).copy(); CALLS.append('imshow')
    cv2.imshow = _imshow
    _w = cv2.imwrite
    def _iw(path, im, *a): SHOWN[path] = np.asarray(im).copy(); return _w(path, im, *a)
    cv2.imwrite = _iw
    cv2.waitKey = lambda *a, **k: (CALLS.append('waitKey'), -1)[1]
    cv2.destroyAllWindows = lambda *a, **k: None
    cv2.namedWindow = lambda *a, **k: None
    cv2.createTrackbar = lambda *a, **k: None
    cv2.getTrackbarPos = lambda *a, **k: 0
    import os; sys.path.insert(0, os.getcwd())             # like running the file from its own folder
    src = open(sys.argv[1], encoding='utf8').read(); buf = io.StringIO(); err = None
    try:
        with contextlib.redirect_stdout(buf): exec(compile(src, 'script.py', 'exec'), {'__name__': '__main__'})
    except Exception as e: err = type(e).__name__ + ': ' + str(e)
    figs = []
    for name, im in list(SHOWN.items())[:3]:
        h, w = im.shape[:2]
        if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode('.png', im); figs.append('data:image/png;base64,' + base64.b64encode(b.tobytes()).decode())
    print(json.dumps({'stdout': buf.getvalue(), 'err': err, 'figs': figs, 'calls': CALLS}))
''')
open('/tmp/harness_sa.py', 'w').write(HARNESS)
ids = [b for b in blocks if b in F or b == 'm1-b22']
bad = 0
for bid in ids:
    src = full(bid)
    with tempfile.TemporaryDirectory() as td:                      # empty folder, fresh interpreter: like a new PyCharm file
        open(os.path.join(td, 'script.py'), 'w', encoding='utf8').write(src)
        r = subprocess.run([sys.executable, '/tmp/harness_sa.py', 'script.py'], cwd=td, capture_output=True, text=True, timeout=120)
        try: o = json.loads(r.stdout.strip().splitlines()[-1])
        except Exception: o = {'err': 'harness: ' + r.stderr[-300:], 'stdout': '', 'figs': [], 'calls': []}
    shows = o['calls'].count('imshow'); waits = o['calls'].count('waitKey')
    status = 'OK ' if not o['err'] else 'ERR'
    if o['err']: bad += 1
    print(status, bid, '| stdout:', o['stdout'].strip().replace('\n', ' / ')[:70], '| windows:', shows, 'waitKey:', waits, '|', o['err'] or '')
    if not o['err']:
        out = {'stdout': o['stdout'][:4000]}
        if o['figs']: out['figs'] = o['figs']
        blocks[bid]['output'] = out
if bad: sys.exit('some scripts failed')
open(p, 'w', encoding='utf8').write(s[:k] + json.dumps(d, ensure_ascii=False) + ';\n')
open('site/content/m1_codefull.js', 'w', encoding='utf8').write('/* Module 1 — additions that make each code example run on its own (generated by standalone_m1.py). */\n(window.LAYER.m1.codeFull = ' + json.dumps(F, ensure_ascii=False, indent=1) + ');\n')
print('written', len(F))

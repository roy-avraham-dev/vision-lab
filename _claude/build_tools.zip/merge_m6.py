import json
p='out/m6.fixed.json'; d=json.load(open(p)); B=d['blocks']
out=[]; n=0
for b in B:
    if b['type']=='code' and out and out[-1]['type']=='p':
        t=b['text'].strip(); prev=out[-1]
        if t.startswith('. '):
            prev['text']=prev['text'].rstrip()+' `'+t[2:]+'` .'; n+=1; continue
        if t.startswith('I/usr/local/cuda') and prev['text'].endswith('infer.cpp -`'):
            prev['text']=prev['text'][:-1]+t+'`'; n+=1; continue
    out.append(b)
d['blocks']=out; json.dump(d,open(p,'w'),ensure_ascii=False); print('merged',n)

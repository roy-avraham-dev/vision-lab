import numpy as np
import cv2

# --- the stereo pair of section 10.2 (exercise 10.4): 640 x 480, f = 700, B = 10 cm, two textured boards at 4 and 7 m
#     in front of a textured wall at 12 m; every pixel sends a ray and takes the colour of the first plane it hits
def render_pair(f=700.0, B=0.10, w=640, h=480, seed=0):
    rng = np.random.default_rng(seed)
    tex = rng.integers(40, 216, (3, 400, 400)).astype(np.float32)          # a random texture table per plane
    tex = np.stack([cv2.GaussianBlur(t, (0, 0), 1.2) for t in tex])
    planes = [(4.0, -0.9, 0.1, -0.4, 0.6), (7.0, 0.2, 1.6, -0.6, 0.5), (12.0, -99, 99, -99, 99)]   # Z, x0, x1, y0, y1
    u, v = np.meshgrid(np.arange(w), np.arange(h))
    out = []
    for cam_x in (0.0, B):                                                   # left camera at 0, right camera B to the right
        img = np.zeros((h, w), np.float32); done = np.zeros((h, w), bool)
        for k, (Z, x0, x1, y0, y1) in enumerate(planes):
            X = cam_x + Z * (u - w / 2) / f
            Y = Z * (v - h / 2) / f
            hit = ~done & (X >= x0) & (X <= x1) & (Y >= y0) & (Y <= y1)
            ti = (np.floor(X * 60).astype(int) % 400, np.floor(Y * 60).astype(int) % 400)
            img[hit] = tex[k][ti[1][hit], ti[0][hit]]
            done |= hit
        img += rng.normal(0, 2, img.shape)                                     # sensor noise
        out.append(np.clip(img, 0, 255).astype(np.uint8))
    return out

left_img, right_img = render_pair()
cv2.imwrite("left.png", left_img)
cv2.imwrite("right.png", right_img)

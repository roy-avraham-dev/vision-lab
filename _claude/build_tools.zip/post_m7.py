import json, re
p='out/m7.fixed.json'; d=json.load(open(p)); n=0
d.setdefault('dropped_repeated_headers', [])
for b in d['blocks']:
    if b['type']=='p' and b.get('dir')=='ltr' and len(re.findall('[א-ת]', b['text']))>40: del b['dir']; n+=1
    if b['type']=='table':
        h=json.dumps(b['rows'][0],ensure_ascii=False); keep=[b['rows'][0]]
        for r in b['rows'][1:]:
            if json.dumps(r,ensure_ascii=False)==h: d['dropped_repeated_headers'].append(r); n+=1
            else: keep.append(r)
        b['rows']=keep
json.dump(d,open(p,'w'),ensure_ascii=False); print('post',n)

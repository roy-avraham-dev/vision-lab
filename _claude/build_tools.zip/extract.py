"""Extract structured, logically-ordered content from the course PDFs (Chromium/Skia output).

Hebrew is stored in visual order. Every line is rebuilt from character positions
and run through the Unicode bidi reordering (self-inverse for plain text), with
bracket mirroring for right-to-left runs. Monospace text is treated as an
isolated left-to-right run, exactly as Chrome rendered it.

Page structure comes from the drawing primitives Chrome emitted:
  thin rects  (0.9098,0.898,0.8627)  -> table borders
  curve       (0.9725,0.9725,0.9647) -> code block background
  rect        (0.8588,0.851,0.8314)  -> callout bar (blockquote)
  tiny dark curves                   -> bullet markers
"""
import json, re, sys, os, subprocess, collections, logging
import pdfplumber
logging.getLogger('pdfminer').setLevel(logging.ERROR)

HEB = re.compile(r'[֐-׿יִ-ﭏ]')
LAT = re.compile(r'[A-Za-zÀ-ɏͰ-ϿЀ-ӿ]')
DIG = re.compile(r'[0-9⁰-⁹₀-₉²³¹]')
AMBIG = []
DROPPED_HEADERS = []
CODE_HEB = []
OVR_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'overrides.json')
OVERRIDES = json.load(open(OVR_PATH)) if os.path.exists(OVR_PATH) else {}
PREP = {'של','עם','על','פי','עד','בין','מול','כ','באורך','בגודל','בגובה','ברוחב','צורה','גודל','אורך','מתוך','מעל','מתחת','לפני','אחרי','בערך','כמעט','רק','סביב','בזווית','ב','ל','מ'}
MIRROR = {'(': ')', ')': '(', '[': ']', ']': '[', '{': '}', '}': '{', '<': '>', '>': '<', '«': '»', '»': '«'}

BORDER = (0.9098, 0.898, 0.8627)
CODEBG = (0.9725, 0.9725, 0.9647)
BAR = (0.8588, 0.851, 0.8314)

def col(o):
    c = o.get('non_stroking_color')
    return tuple(round(x, 4) for x in c) if isinstance(c, (list, tuple)) else c

import unicodedata
def ctype(c, para=True):
    ch = c['t']
    if para and c.get('s') == 'code' and ch != ' ' and not HEB.match(ch): return 'L'
    bc = unicodedata.bidirectional(ch[0]) if ch else 'ON'
    if bc in ('R', 'AL'): return 'R'
    if bc == 'L': return 'L'
    if bc in ('EN', 'AN'): return 'EN'
    if bc in ('ES', 'ET', 'CS'): return bc
    return 'N'

def bidi_reorder(chars, base_rtl=True, para=True, sos=None, eos=None):
    n = len(chars)
    if n == 0: return chars, []
    T = [ctype(c, para) for c in chars]
    for i in range(1, n - 1):
        if T[i] in ('CS', 'ES') and T[i-1] == 'EN' and T[i+1] == 'EN': T[i] = 'EN'
    changed = True
    while changed:
        changed = False
        for i in range(n):
            if T[i] == 'ET' and ((i > 0 and T[i-1] == 'EN') or (i < n-1 and T[i+1] == 'EN')):
                T[i] = 'EN'; changed = True
    T = ['N' if t in ('CS', 'ET', 'ES') else t for t in T]
    # W7 for visual input. A number belongs to Hebrew text when only spaces separate it
    # from a Hebrew letter; in RTL paragraphs a number joined to Latin by an operator
    # (x = 3) stays with the Latin. Otherwise a number after Latin joins the Latin run.
    def scan(i, step):
        seps = ''
        j = i + step
        while 0 <= j < n:
            if T[j] in ('L', 'R'): return T[j], seps
            if T[j] not in ('EN',) and not (T[j] in ('CS', 'ES', 'ET') and 0 <= j + step < n and T[j + step] == 'EN'):
                seps += chars[j]['t']
            j += step
        return None, seps
    for i in range(n):
        if T[i] != 'EN': continue
        lt, ls = scan(i, -1); rt, rs = scan(i, 1)
        if lt is None and sos: lt = sos
        if rt is None and eos: rt = eos
        clear = (lambda s: s.strip() == '') if base_rtl else (lambda s: set(s) <= set(' ,()[].:;'))
        glued_any = lt == 'L' and ' ' not in ls
        heb_touch = (lt == 'R' and clear(ls)) or (rt == 'R' and clear(rs))
        op = lambda s: s.strip() != '' and set(s.replace(' ', '')) <= set('=+−-*/<>×·≤≥≈([,')
        lat_op = (lt == 'L' and op(ls)) or (rt == 'L' and op(rs))
        glued_l = (lt == 'L' and ' ' not in ls and ls != '' and set(ls) <= set('⁻⁺ᵀ\'′″^_')) or (lt == 'L' and ls == '' and i > 0)
        if base_rtl:
            if glued_l or glued_any or lat_op or (not heb_touch and (lt == 'L' or (lt is None and rt == 'L'))): T[i] = 'EN_L'
        elif para:
            # left-to-right paragraph
            perm = lambda s: set(s) <= set(' ,()[].:;')
            if glued_any or (lt == 'L' and ls.rstrip(' ,').endswith(('(', '[')) and not ls.rstrip(' ,')[:-1].strip(' ,')): T[i] = 'EN_L'
            elif lt == 'L' and ls.endswith(('(', '[')): T[i] = 'EN_L'
            elif rs.startswith(' ,') or ls.startswith(' ,'): pass      # reversed list "4 ,2": Hebrew context
            elif rt == 'R' and rs.strip() == '': pass
            elif lt in ('L', None): T[i] = 'EN_L'
        else:
            if not heb_touch or glued_any: T[i] = 'EN_L'
            elif rt == 'R' and clear(rs) and not (lt == 'R' and clear(ls)):
                # number sits just left of a Hebrew phrase in a left-to-right line: it is either
                # the phrase's last word ("באורך 3") or a count before it ("2 שורות").
                j = i + 1
                while j < n and T[j] in ('EN', 'CS', 'ES', 'ET'): j += 1
                seg = ''
                while j < n and T[j] != 'L': seg += chars[j]['t']; j += 1
                words = [w[::-1] for w in re.findall(r'[\u0590-\u05FF״׳"־]+', seg)]
                if words:
                    w_last, w_first = words[0], words[-1]
                    AMBIG.append((w_first, w_last))
                    # a count stands before a plural noun ("2 שורות"); a label follows its noun ("מחלקה 0")
                    if re.search(r'(ות|ים)$', w_first) and len(w_first) > 2 and not w_first.startswith('ה') and chars[i-1]['t'] not in '([' if i > 0 else True:
                        T[i] = 'EN_L'
    T = ['L' if t == 'EN_L' else t for t in T]
    T = ['N' if t in ('CS', 'ET', 'ES') else t for t in T]
    # W7 (symmetric form for visual input): EN joins Latin only when no Hebrew touches it
    near_l = [None] * n; near_r = [None] * n
    last = None
    for i in range(n):
        near_l[i] = last
        if T[i] in ('L', 'R'): last = T[i]
    last = None
    for i in range(n - 1, -1, -1):
        near_r[i] = last
        if T[i] in ('L', 'R'): last = T[i]
    for i in range(n):
        if T[i] == 'EN':
            l = near_l[i] or ('R' if base_rtl else 'L'); r = near_r[i]
            if (l == 'L' and r != 'R') or (r == 'L' and l is None and not base_rtl): T[i] = 'L'
    base = 'R' if base_rtl else 'L'
    strong = lambda t: 'R' if t in ('R', 'EN') else 'L'
    # N0: paired brackets
    OPEN = {'(': ')', '[': ']', '{': '}'}
    stack, pairs = [], []
    for i in range(n):
        ch = chars[i]['t']
        if T[i] != 'N': continue
        if ch in OPEN: stack.append((ch, i))
        elif ch in OPEN.values():
            for k in range(len(stack) - 1, -1, -1):
                if OPEN[stack[k][0]] == ch:
                    pairs.append((stack[k][1], i)); del stack[k:]; break
    pairs.sort()
    for o, cl in pairs:
        inside_types = {strong(T[k]) for k in range(o + 1, cl) if T[k] in ('L', 'R', 'EN')}
        if not inside_types: continue
        if base in inside_types: res = base
        else:
            opp = 'L' if base == 'R' else 'R'
            prev, nxt = sos, eos
            for k in range(o - 1, -1, -1):
                if T[k] in ('L', 'R', 'EN'): prev = strong(T[k]); break
            for k in range(cl + 1, n):
                if T[k] in ('L', 'R', 'EN'): nxt = strong(T[k]); break
            res = opp if (prev == opp or nxt == opp) else base
        T[o] = T[cl] = res
    # G: connector punctuation glued to the end of a Latin word stays with it
    for i in range(1, n):
        ch = chars[i]['t']
        if T[i] == 'N' and ch not in ' .,:;!?()[]{}"\'״׳' and T[i-1] == 'L' and chars[i-1]['t'] != ' ':
            if i == n - 1 or chars[i+1]['t'] == ' ' or T[i+1] in ('R', 'L'):
                T[i] = 'L'
    i = 0
    while i < n:
        if T[i] == 'N':
            j = i
            while j < n and T[j] == 'N': j += 1
            before = strong(T[i-1]) if i > 0 else (sos or base)
            after = strong(T[j]) if j < n else (eos or base)
            res = before if before == after else base
            for k in range(i, j): T[k] = res
            i = j
        else:
            i += 1
    if base_rtl:
        lv = [1 if t == 'R' else 2 for t in T]
    else:
        lv = [0 if t == 'L' else (2 if t == 'EN' else 1) for t in T]
    out = list(range(n))
    for level in range(max(lv), 0, -1):
        i = 0
        while i < n:
            if lv[out[i]] >= level:
                j = i
                while j < n and lv[out[j]] >= level: j += 1
                out[i:j] = out[i:j][::-1]
                i = j
            else:
                i += 1
    res = []
    for idx in out:
        c = dict(chars[idx])
        if lv[idx] % 2 == 1 and c['t'] in MIRROR: c['t'] = MIRROR[c['t']]
        res.append(c)
    return res, lv

def style_of(c):
    f = c['fontname']
    if 'Mono' in f: return 'code'
    if 'Bold' in f or 'Semibold' in f: return 'b'
    return ''

def build_line(cs, keep_spaces=False):
    cs = sorted(cs, key=lambda c: (c['x0'], c['x1']))
    out = []
    prev = None
    for c in cs:
        t = c['text']
        if t in (' ', ' ', ' '):
            if keep_spaces or (out and out[-1]['t'] != ' '):
                out.append({'t': ' ', 's': style_of(c)})
            prev = c; continue
        if t == '' or t in '​‎‏‪‫‬‭‮﻿': continue
        if prev is not None and (not out or out[-1]['t'] != ' '):
            gap = c['x0'] - prev['x1']
            if gap > 0.22 * c['size']:
                out.append({'t': ' ', 's': style_of(c) if style_of(c) == style_of(prev) else ''})
        out.append({'t': t, 's': style_of(c)})
        prev = c
    return out

def render_inline(items):
    s = ''; cur = None; buf = ''
    def flush():
        nonlocal s, buf
        if not buf: return
        lead = len(buf) - len(buf.lstrip(' ')); trail = len(buf) - len(buf.rstrip(' '))
        core = buf.strip(' ')
        if cur not in ('code',):
            buf = buf.replace('\\', '\\\\').replace('*', '\\*').replace('`', '\\`')
            core = buf.strip(' ')
        if cur == 'code' and core: s += ' ' * lead + '`' + core.replace('`', '\\`') + '`' + ' ' * trail
        elif cur == 'b' and core: s += ' ' * lead + '**' + core + '**' + ' ' * trail
        else: s += buf
        buf = ''
    for it in items:
        st = it['s']
        if it['t'] == ' ':
            buf += ' '; continue
        if st != cur:
            flush(); cur = st
        buf += it['t']
    flush()
    s = re.sub(r'`\s*`', ' ', s)
    s = s.replace('****', '')
    return re.sub(r' {2,}', ' ', s)

def logical_items(cs, code=False, rtl=None, sos=None, eos=None):
    items = build_line(cs, keep_spaces=code)
    has_heb = any(HEB.match(i['t']) for i in items)
    if code:
        if has_heb:
            items, _ = bidi_reorder(items, base_rtl=False, para=False)
        return items
    if rtl is None: rtl = has_heb
    if rtl:
        items, _ = bidi_reorder(items, base_rtl=True, sos=sos, eos=eos)
    elif has_heb:
        items, _ = bidi_reorder(items, base_rtl=False, sos=sos, eos=eos)
    return items

def strong_ends(items):
    ts = [ctype(i) for i in items]
    ts = [t for t in ts if t in ('L', 'R')]
    return (ts[0], ts[-1]) if ts else (None, None)

def has_hebrew(lines):
    return any(HEB.match(c['text']) for L in lines for c in L['chars'])

def group_lines(chars, tol=3.0):
    vis = [c for c in chars if c['text'].strip()]
    vis = sorted(vis, key=lambda c: (c['top'] + c['bottom']) / 2)
    lines = []
    for c in vis:
        mid = (c['top'] + c['bottom']) / 2
        if lines and abs(mid - lines[-1]['mid']) <= tol:
            L = lines[-1]; L['chars'].append(c)
        else:
            lines.append({'mid': mid, 'chars': [c]})
    # attach space characters to nearest line
    for c in chars:
        if not c['text'].strip():
            mid = (c['top'] + c['bottom']) / 2
            best = min(lines, key=lambda L: abs(L['mid'] - mid), default=None)
            if best and abs(best['mid'] - mid) <= tol + 1: best['chars'].append(c)
    for L in lines:
        cs = [c for c in L['chars'] if c['text'].strip()]
        L['x0'] = min(c['x0'] for c in cs); L['x1'] = max(c['x1'] for c in cs)
        L['top'] = min(c['top'] for c in cs); L['bottom'] = max(c['bottom'] for c in cs)
        sz = collections.Counter(round(c['size'], 1) for c in cs)
        L['size'] = sz.most_common(1)[0][0]
        L['mono_ratio'] = sum('Mono' in c['fontname'] for c in cs) / len(cs)
    lines.sort(key=lambda L: L['top'])
    return lines

def inside(c, bb, pad=0.8):
    cx = (c['x0'] + c['x1']) / 2; cy = (c['top'] + c['bottom']) / 2
    return bb[0] - pad <= cx <= bb[2] + pad and bb[1] - pad <= cy <= bb[3] + pad

WRAPS = []
def code_text(lines, bb=None):
    if not lines: return ''
    x0 = min(L['x0'] for L in lines)
    cws = [c['x1'] - c['x0'] for L in lines for c in L['chars'] if 'Mono' in c['fontname'] and c['text'].strip()]
    cw = sorted(cws)[len(cws)//2] if cws else 6.3
    lh = None
    tops = [L['top'] for L in lines]
    diffs = sorted(b - a for a, b in zip(tops, tops[1:]) if b - a > 2)
    lh = diffs[0] if diffs else 15
    out = []
    prev_top = None; prev = None
    limit = None
    if bb is not None:
        pad = x0 - bb[0]
        limit = bb[2] - pad - 2.2 * cw
    for L in lines:
        items = logical_items(L['chars'], code=True)
        t = ''.join(i['t'] for i in items).strip(' ')
        vis = ''.join(i['t'] for i in build_line(L['chars'], keep_spaces=True)).strip(' ')
        if HEB.search(vis):
            CODE_HEB.append((vis, t))
            if vis in OVERRIDES: t = OVERRIDES[vis]
        ind = max(0, round((L['x0'] - x0) / cw))
        if prev is not None:
            blanks = round((L['top'] - prev_top) / lh) - 1
            heb_only = bool(t) and not re.search(r'[A-Za-z0-9_=()\[\]{}#]', t)
            if blanks <= 0 and out and ((limit is not None and prev['x1'] >= limit and ind == 0) or (heb_only and '#' in out[-1])):
                out[-1] = out[-1] + ' ' + t; WRAPS.append(out[-1]); prev_top = L['top']; prev = L; continue
            out += [''] * max(0, blanks)
        out.append(' ' * ind + t)
        prev_top = L['top']; prev = L
    return '\n'.join(out)

def _is(t, kind):
    return ctype(t) == kind

def text_of(lines, rtl=None):
    """Rebuild a paragraph. Lines are joined into one visual sequence equal to the
    unwrapped paragraph (a Latin run that wraps across lines is re-joined), then the
    bidi reordering runs once over the whole paragraph."""
    if rtl is None: rtl = has_hebrew(lines)
    vis = [build_line(L['chars']) for L in lines]
    vis = [v for v in vis if v]
    if not vis: return ''
    if not rtl:
        S = vis[0]
        for T in vis[1:]:
            # a Hebrew run wrapping across lines: its first part ends line k, the rest starts line k+1
            first_r = next((k for k, it in enumerate(S) if ctype(it) == 'R'), len(S))
            last_l = max([k for k, it in enumerate(S) if ctype(it) == 'L'] + [first_r - 1])
            first_l = next((k for k, it in enumerate(T) if ctype(it) == 'L'), len(T))
            A, B = S[last_l + 1:], T[:first_l]
            joiner = [{'t': ' ', 's': ''}]
            if any(ctype(i) == 'R' for i in A) and any(ctype(i) == 'R' for i in B):
                a_lead = []
                while A and ctype(A[0]) not in ('R', 'EN'): a_lead.append(A[0]); A = A[1:]
                b_trail = []
                while B and ctype(B[-1]) not in ('R', 'EN'): b_trail.insert(0, B[-1]); B = B[:-1]
                S = S[:last_l + 1] + a_lead + B + joiner + A + b_trail + T[first_l:]
            else:
                S = S + joiner + T
        seq = S
        if any(HEB.match(i['t']) for i in seq):
            seq, _ = bidi_reorder(seq, base_rtl=False)
        return render_inline(seq).strip()
    S = vis[0]
    for T in vis[1:]:
        # logical end of the text so far sits at the visual left of S
        first_r_S = next((k for k, it in enumerate(S) if ctype(it) == 'R'), len(S))
        last_r_T = max([k for k, it in enumerate(T) if ctype(it) == 'R'], default=-1)
        A_full, S_rest = S[:first_r_S], S[first_r_S:]
        B_full, T_rest = T[last_r_T + 1:], T[:last_r_T + 1]
        # boundary punctuation next to Hebrew belongs to the Hebrew side (it is right-to-left)
        A = A_full
        while A and ctype(A[-1]) not in ('L', 'EN'): A = A[:-1]
        a_trail = A_full[len(A):]
        B = B_full
        b_lead = []
        while B and ctype(B[0]) not in ('L', 'EN'): b_lead.append(B[0]); B = B[1:]
        has = lambda seg, kinds: any(ctype(i) in kinds for i in seg)
        # hyphen / maqaf at the logical end of the previous line: no space at the join
        tail_char = A[-1]['t'] if A else (S_rest[0]['t'] if S_rest else '')
        joiner = [] if tail_char in '-־/' else [{'t': ' ', 's': ''}]
        if A and B and (has(A, ('L',)) or has(B, ('L',))) and has(A, ('L', 'EN')) and has(B, ('L', 'EN')):
            S = T_rest + b_lead + A + joiner + B + a_trail + S_rest
        else:
            S = T + joiner + S
    seq, _ = bidi_reorder(S, base_rtl=True)
    return render_inline(seq).strip()

def find_tables(page):
    thin = [r for r in page.rects if col(r) == BORDER and min(r['width'], r['height']) < 1.5]
    if not thin: return []
    ts = page.find_tables(table_settings={
        'vertical_strategy': 'explicit', 'horizontal_strategy': 'explicit',
        'explicit_vertical_lines': [r for r in thin if r['width'] < 1.5],
        'explicit_horizontal_lines': [r for r in thin if r['height'] < 1.5],
        'snap_tolerance': 2, 'join_tolerance': 2, 'intersection_tolerance': 2})
    return ts

def cell_content(chars, codebgs):
    lines = group_lines(chars)
    if not lines: return []
    blocks = []
    for L in lines:
        is_codeblock = any(inside(L['chars'][0], bb, 1) for bb in codebgs)
        heb = has_hebrew([L])
        kind = 'codeblock' if is_codeblock else ('code' if L['mono_ratio'] > 0.85 and not heb else 'p')
        if blocks and blocks[-1]['kind'] == kind and L['top'] - blocks[-1]['lines'][-1]['bottom'] < L['size'] * 0.9:
            blocks[-1]['lines'].append(L)
        else:
            blocks.append({'kind': kind, 'lines': [L]})
    res = []
    for b in blocks:
        if b['kind'] == 'codeblock': res.append({'type': 'code', 'text': code_text(b['lines'])})
        elif b['kind'] == 'code':
            res.append({'type': 'code', 'text': ' '.join(''.join(i['t'] for i in logical_items(L['chars'], code=True)).strip() for L in b['lines']), 'inline': True})
        else: res.append({'type': 'p', 'text': text_of(b['lines']), '_vis': [''.join(i['t'] for i in build_line(l['chars'])) for l in b['lines']]})
    return res

HEAD = {24.0: 'h1', 16.5: 'h2', 13.5: 'h3'}
CAPTION = {9.7, 9.8}

def page_blocks(page, pno, imgdir, pdfpath, tag):
    W = page.width
    codebgs = [(c['x0'], c['top'], c['x1'], c['bottom']) for c in page.curves if col(c) == CODEBG]
    bars = [(r['x0'] - 520, r['top'], r['x1'], r['bottom']) for r in page.rects if col(r) == BAR]
    bullets = [((c['top'] + c['bottom']) / 2, c['x0']) for c in page.curves
               if (c['x1'] - c['x0']) < 7 and (c['bottom'] - c['top']) < 7 and col(c) in ((0.1216, 0.1176, 0.1137), (0.0431, 0.0431, 0.0431))]
    chars = [c for c in page.chars if round(c['size'], 1) != 6.0]
    meta = None
    if pno == 0:
        mc = [c for c in chars if 80 < c['top'] < 110 and round(c['size'], 1) in (9.0, 12.0)]
        if mc: meta = text_of(group_lines(mc))
        chars = [c for c in chars if c not in mc]
    tables = find_tables(page)
    tbbs = [t.bbox for t in tables]
    items = []
    used = set()
    for t in tables:
        rows = []
        for r in t.rows:
            row = []
            for cell in r.cells:
                if cell is None: continue
                cc = [c for c in chars if inside(c, cell, pad=0.3)]
                for c in cc: used.add(id(c))
                row.append(cell_content(cc, codebgs))
            rows.append(row[::-1])  # RTL table: rightmost column first
        rows = [r for r in rows if any(r)]
        if rows:
            header = bool(page.rects) and any(col(x) == (0.9608, 0.9529, 0.9294) and abs(x['top'] - t.bbox[1]) < 3 for x in page.rects)
            items.append({'type': 'table', 'top': t.bbox[1], 'bottom': t.bbox[3], 'rows': rows, 'header': header})
    for k, im in enumerate(page.images):
        x0, top, x1, bottom = im['x0'], im['top'], im['x1'], im['bottom']
        if (x1 - x0) < 20 or (bottom - top) < 20: continue
        name = f'{tag}_p{pno+1:03d}_{k}'
        dpi = 170
        subprocess.run(['pdftoppm', '-png', '-r', str(dpi), '-f', str(pno+1), '-l', str(pno+1),
                        '-x', str(int(x0*dpi/72)), '-y', str(int(top*dpi/72)),
                        '-W', str(int((x1-x0)*dpi/72)), '-H', str(int((bottom-top)*dpi/72)),
                        '-singlefile', pdfpath, os.path.join(imgdir, name)], check=True)
        items.append({'type': 'img', 'top': top, 'bottom': bottom, 'src': name + '.png', 'w': round(x1 - x0), 'h': round(bottom - top)})
    free = [c for c in chars if id(c) not in used and not any(inside(c, bb, 0.3) for bb in tbbs)]
    lines = group_lines(free)
    cur = None
    def close():
        nonlocal cur
        if cur:
            if cur['type'] == 'code': cur['text'] = code_text(cur.pop('_lines'), cur['_key'] if cur['_key'] != 'mono' else None)
            else:
                ls_ = cur.pop('_lines')
                if cur['type'] == 'oli':
                    cur['type'] = 'li'; cur['ordered'] = True
                if cur['type'] in ('p', 'quote') and all(l['x0'] < 62 for l in ls_) and ls_[-1]['x1'] < 540:
                    cur['dir'] = 'ltr'
                cur['text'] = text_of(ls_, rtl=False if cur.get('dir') == 'ltr' else None)
                cur['_vis'] = [''.join(i['t'] for i in build_line(l['chars'])) for l in ls_]
            items.append(cur)
        cur = None
    for L in lines:
        cb = next((bb for bb in codebgs if inside(L['chars'][0], bb, 1) and bb[3] - bb[1] > 12 and bb[2] - bb[0] > 300), None)
        if cb is not None or (L['mono_ratio'] > 0.95 and L['x1'] - L['x0'] > 0 and L['size'] in (10.5, 10.8)):
            key = cb or 'mono'
            if cur and cur['type'] == 'code' and cur['_key'] == key:
                cur['_lines'].append(L); cur['bottom'] = L['bottom']; continue
            close(); cur = {'type': 'code', 'top': L['top'], 'bottom': L['bottom'], '_lines': [L], '_key': key}; continue
        h = HEAD.get(L['size'])
        mid = (L['top'] + L['bottom']) / 2
        in_bar = any(bb[1] - 2 <= mid <= bb[3] + 2 for bb in bars)
        bullet = next((b for b in bullets if abs(b[0] - mid) < 5 and (b[1] > L['x1'] - 2 or b[1] < L['x0'] + 2)), None)
        right = 549.4 - L['x1']
        visline = ''.join(i['t'] for i in build_line(L['chars'])).strip()
        olm = re.search(r'\s\.(\d{1,2})$', visline) if not h else None
        if h: typ = h
        elif L['size'] in CAPTION: typ = 'caption'
        elif olm and not in_bar: typ = 'oli'
        elif in_bar: typ = 'quote'
        elif bullet: typ = 'li'
        else: typ = 'p'
        start_new = True
        if cur and cur['type'] not in ('code',):
            gap = L['top'] - cur['bottom']
            if typ == 'oli': same = False
            elif cur['type'] == 'oli' and typ == 'p' and L['x1'] < 549.4 - 8: same = True
            else: same = (typ == cur['type']) or (cur['type'] == 'li' and typ == 'p' and (abs(right - cur['_right']) < 4 or (cur.get('dir') == 'ltr' and abs(L['x0'] - cur['_x0']) < 4)))
            if same and gap < L['size'] * 0.9 and not bullet: start_new = False
        if start_new:
            close()
            cur = {'type': typ, 'top': L['top'], 'bottom': L['bottom'], '_lines': [L], '_right': right if typ != 'li' else 549.4 - L['x1'], '_x0': L['x0']}
            if typ == 'li':
                if bullet[1] < 300:
                    cur['dir'] = 'ltr'; cur['level'] = max(0, round((bullet[1] - 55) / 22))
                else:
                    cur['level'] = max(0, round((549.4 - bullet[1] - 9) / 22))
            elif typ == 'p' and right > 14:
                cur['indent'] = round(right / 22)
        else:
            cur['_lines'].append(L); cur['bottom'] = L['bottom']
    close()
    items.sort(key=lambda b: b['top'])
    for b in items: b['page'] = pno + 1
    return items, meta

def merge_pages(blocks):
    out = []
    for b in blocks:
        first = b.pop('_first', False)
        if out and first:
            a = out[-1]
            if a['page'] == b['page'] - 1:
                if a['type'] == 'table' and b['type'] == 'table' and len(b['rows'][0]) == len(a['rows'][0]):
                    rows = b['rows']
                    if a.get('header') and rows and rows[0] == a['rows'][0]:
                        rows = rows[1:]; DROPPED_HEADERS.append(a['rows'][0])
                    a['rows'] += rows; continue
                if a['type'] == 'code' and b['type'] == 'code':
                    a['text'] += '\n' + b['text']; continue
                if a['type'] in ('p', 'li', 'quote') and b['type'] in ('p', 'quote') and not re.search(r'[.:?!״"”)\]]\**`?$', a['text']):
                    a['text'] += ' ' + b['text']; continue
        out.append(b)
    return out

def extract(pdfpath, outdir, tag):
    imgdir = os.path.join(outdir, 'img')
    os.makedirs(imgdir, exist_ok=True)
    pdf = pdfplumber.open(pdfpath)
    allb = []; meta = None
    for pno, page in enumerate(pdf.pages):
        bl, m = page_blocks(page, pno, imgdir, pdfpath, tag)
        meta = meta or m
        if bl: bl[0]['_first'] = True
        allb += bl
    allb = merge_pages(allb)
    vis = {}
    for n_, b in enumerate(allb):
        for k in ('top', 'bottom', '_right', '_key', '_x0'): b.pop(k, None)
        if '_vis' in b: vis[n_] = b.pop('_vis')
        if b['type'] == 'table':
            for r in b['rows']:
                for c in r:
                    for s in c:
                        if '_vis' in s: vis.setdefault(n_, []).extend(s.pop('_vis'))
    json.dump(vis, open(os.path.join(outdir, f'{tag}_vis.json'), 'w'), ensure_ascii=False, indent=0)
    doc = {'meta': meta, 'pages': len(pdf.pages), 'blocks': allb,
           'dropped_repeated_headers': DROPPED_HEADERS}
    json.dump(doc, open(os.path.join(outdir, f'{tag}.json'), 'w'), ensure_ascii=False, indent=1)
    json.dump(CODE_HEB, open(os.path.join(outdir, f'{tag}_codeheb.json'), 'w'), ensure_ascii=False, indent=0)
    return doc

if __name__ == '__main__':
    doc = extract(sys.argv[1], sys.argv[2], sys.argv[3])
    print(sys.argv[3], len(doc['blocks']), 'blocks', 'ambiguous numbers:', len(AMBIG))

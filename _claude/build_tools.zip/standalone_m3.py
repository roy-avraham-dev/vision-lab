# Stand-alone additions for the code examples of module 3: writes site/content/m3_codefull.js,
# verifies every full script in a fresh process and an empty folder, and refreshes the precomputed outputs in m3.js.
import json, os, subprocess, sys, tempfile, base64, textwrap
PIP = 'אם PyCharm מסמן את `cv2` או את `numpy` באדום, הרץ פעם אחת בטרמינל שלו: `pip install opencv-python numpy`.'
IMP = {'code': 'import cv2\nimport numpy as np\n', 'say': 'שתי הספריות שהקוד משתמש בהן. ' + PIP}
def show(*names, extra=''):
    return {'code': extra + ''.join(f'cv2.imshow("{n}", {n})\n' for n in names) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()',
            'say': 'מציג את התוצאה: ' + ('חלון אחד' if len(names) == 1 else f'{len(names)} חלונות') + ' (' + ', '.join(f'`{n}`' for n in names) + '). לחיצה על מקש כלשהו, כשאחד החלונות בפוקוס, סוגרת אותם.'}
PAPER = 'gray = np.full((300, 400), 200, np.uint8)                                  # נייר בהיר\ncv2.putText(gray, "CV", (60, 200), cv2.FONT_HERSHEY_SIMPLEX, 5, 50, 20)    # טקסט כהה\n'
F = {
 'm3-b31': {'post': [{'code': 'import matplotlib.pyplot as plt\n\nZs = np.linspace(2, 60, 200)\nheights = []\nfor Z in Zs:\n    p = project_pinhole(np.array([[0, -0.3, Z], [0, 1.5, Z]]), f)\n    heights.append((p[1, 1] - p[0, 1]) * 1000)\nplt.plot(Zs, heights)\nplt.xlabel("Z (m)")\nplt.ylabel("height on the sensor (mm)")\nplt.show()', 'say': 'גרף של הגובה על החיישן כפונקציה של המרחק: עקומה הפוכה (1/Z), שיורדת מהר בהתחלה ומשתטחת. אם `matplotlib` מסומן באדום — `pip install matplotlib`.'}]},
 'm3-b39': {'pre': [{'code': 'import numpy as np\n\ndef project_pinhole(P, f):\n    P = np.asarray(P, float)\n    return f * P[:, :2] / P[:, 2:3]\n\nf = 0.004\n', 'say': 'הפונקציה `project_pinhole` ומרחק המוקד מהקוד של סעיף 1.2. הקוד של הסעיף משתמש בשניהם.'}]},
}

# ---------------- chapter 2
NP = {'code': 'import numpy as np\n', 'say': 'NumPy. אם PyCharm מסמן אותה באדום: `pip install numpy`.'}
CH2_DEFS = ('import numpy as np\n\nfx = 4.0 / 0.003\nW, H = 1920, 1080\nK = np.array([[fx, 0, W / 2], [0, fx, H / 2], [0, 0, 1]])\n\n'
            'def project_K(K, P):\n    p = (K @ np.asarray(P, float).T).T\n    return p[:, :2] / p[:, 2:3]\n\n'
            'P = np.array([[0, 0, 10], [1, 0, 10], [0, 1.5, 10], [-2, -1, 20]])\n')
F['m3-b65'] = {'post': [{'code': 'print(np.linalg.inv(K).round(5))       # the inverse: subtract the centre, divide by fx', 'say': 'מדפיס גם את ‎K⁻¹‎ עצמה, כדי לראות את המבנה שלה: ‎1/fx = 0.00075‎ על האלכסון, ו־‎−cx/fx = −0.72‎, ‎−cy/fy = −0.405‎ בעמודה האחרונה — "להחסיר את המרכז ולחלק ב־fx".'}]}
F['m3-b72'] = {'pre': [{'code': CH2_DEFS, 'say': 'K, הפונקציה `project_K` והנקודות P מהקוד של סעיף 2.2 — הקוד של הסעיף משתמש בשלושתם.'}],
               'post': [{'code': 'print(K_half.round(1))\nprint(K_crop.round(1))\nuv = project_K(K, P)\nprint(np.abs(project_K(K_crop, P) - (uv - [300, 100])).max())   # 0: the same as shifting every pixel', 'say': 'מדפיס את שתי המטריצות החדשות, ובודק את הטענה של הטבלה: ההטלה עם ‎K_crop‎ שווה בדיוק להחסרת ‎(300, 100)‎ מכל פיקסל של ההטלה המקורית.'}]}

# ---------------- chapter 3
def _noprint(t): return '\n'.join(l for l in t.split('\n') if not l.startswith('print('))
F['m3-b98'] = {'pre': [{'code': 'IMPORT_LATER', 'say': 'הקוד של סעיף 3.2 — `look_at`, `project`, K, R, t, הנקודות `Pw` וההטלה `uv` — בלי ההדפסות שלו. הקוד של הסעיף משווה אליהם. (בקורס הם ב־`geom.py`; כאן הם מועתקים כדי שהקובץ ירוץ לבד.) אם `cv2` מסומן באדום: `pip install opencv-python`.'}]}

# ---------------- chapter 4
GEOM_SAY = 'הקורס מייבא מהקובץ `geom.py` של סעיף 3.2. השורות האלה כותבות אותו לתיקייה של הקובץ, אם הוא עוד לא קיים — עם `look_at`, `project` ו־K, בלי ההדפסות של הדוגמה. אחרי הפעם הראשונה הוא כבר שם, וזה בדיוק המצב של הקורס.'
F['m3-b117'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}]}
F['m3-b125'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'B117_LATER', 'say': 'הקוד של סעיף 4.1 — `distort_normalized`, `project_dist` והנקודות המעוותות `uv` — כי הקוד של הסעיף ממשיך ממנו.'}]}

# ---------------- chapter 5
BOARDS = open('/home/claude/build/pre5_boards.py', encoding='utf8').read()
BOARDS_SAY = 'הקורס משתמש ב־`images` — 15 תמונות של לוח מהמצלמה המדומה של הסעיף (‏fx = fy = 1100, מרכז ‎(650, 350)‎, ‏k1 = −0.28, ‏k2 = 0.09) — בלי לתת את הקוד שמייצר אותן (זה תרגיל 5.4). כאן הוא כתוב במלואו, בדיוק לפי התיאור: לכל פיקסל ביטול עיוות (פרק 4), קרן (פרק 2), סיבוב למערכת הלוח (פרק 3), חיתוך עם המישור Z = 0 וצבע לפי הריבוע; ועוד טשטוש קל ורעש, כמו מצלמה. התנוחות שונות מאלה של הקורס, ולכן המספרים בפלט שונים מעט מההערות בקוד. ההרצה לוקחת כמה שניות.'
F['m3-b145'] = {'pre': [{'code': BOARDS, 'say': BOARDS_SAY}]}
F['m3-b155'] = {'pre': [{'code': BOARDS, 'say': BOARDS_SAY}, {'code': 'B145_LATER', 'say': 'הכיול של סעיף 5.2 — הקוד של הסעיף בודק את התוצאות שלו (`obj_pts`, `img_pts`, `rvecs`, `tvecs`, `K_est`, `dist_est`).'}]}

# ---------------- chapter 6
F['m3-b178'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}], 'post': [{'code': '\nsrc = np.array([[0, 0], [1, 0], [1, 1], [0, 1]], float)\ndst = np.array([[10, 10], [30, 12], [28, 40], [8, 35]], float)\nH = homography_dlt(src, dst)\nprint(np.abs(apply_h(H, src) - dst).max())     # ~1e-14: the four points map exactly', 'say': 'בדיקה קטנה שהפונקציות עובדות — הקוד של הסעיף רק מגדיר אותן: ארבעה זוגות כלשהם, H מ־DLT, ו־`apply_h` מחזירה את ארבע הנקודות בדיוק (עד שגיאת עיגול).'}]}
F['m3-b183'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'B178_LATER', 'say': 'הפונקציות `normalize`, `homography_dlt` ו־`apply_h` מסעיף 6.2.'}]}
F['m3-b193'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'B178_LATER', 'say': 'הפונקציות של סעיף 6.2.'}, {'code': 'B183_LATER', 'say': 'המצלמה, המלבן, `uv`, נקודות הבדיקה `test` ו־`uv_test` של סעיף 6.3.'}]}
F['m3-b202'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'B178_LATER', 'say': 'הפונקציות של סעיף 6.2.'}, {'code': 'B183_LATER', 'say': 'המצלמה ונקודות הבדיקה של סעיף 6.3.'}, {'code': 'B193_LATER', 'say': 'הניסוי של הרעש מתחילת הסעיף (בלי ההדפסה). הוא כאן בגלל `rng`: הקוד של החריגות ממשיך מאותו מחולל מספרים אקראיים. גם כך השגיאות של DLT יוצאות שונות מההערה בקורס (החריגות אקראיות, וכנראה הקורס הריץ בסדר אחר) — אבל הדפוס זהה: RANSAC מוצא בדיוק את חמש החריגות ושגיאה של אפס, ו־DLT טועה במטרים בנקודה הרחוקה.'}],
               'post': [{'code': '\nfor name, Hx in (("DLT", H_dlt), ("RANSAC", H_ransac)):\n    print(name, np.linalg.norm(apply_h(Hx, uv_test) - test[:, :2], axis=1).round(2))', 'say': 'הקורס כותב את שגיאות נקודות הבדיקה בהערה בלבד; השורות האלה מחשבות אותן — לכל אחת משתי ההומוגרפיות.'}]}

# ---------------- chapter 7
F['m3-b222'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}]}
IMPG = {'code': 'import numpy as np\nimport cv2\nfrom geom import K, look_at, project\n', 'say': 'הייבוא של סעיף 7.1, שהקוד הזה ממשיך ממנו. `cv2.aruco` הוא חלק מ־`opencv-python` מגרסה 4.7 ומעלה.'}
F['m3-b228'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, IMPG]}
F['m3-b451'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'import numpy as np\nimport cv2\nfrom geom import K, look_at, project\n', 'say': 'NumPy, OpenCV (להשוואה ל־`solvePnP` בסוף), והפונקציות של `geom.py`.'}],
    'post': [{'code': '\n# a check: four points on the ground, a known camera, and solvePnP for comparison\nR, t = look_at([2, -6, 3], [0, 0, 0])\nground = np.array([[-1, -1, 0], [1, -1, 0], [1, 1, 0], [-1, 1, 0]], float)\nuv, _ = project(K, R, t, ground)\nH, _ = cv2.findHomography(ground[:, :2], uv)\nR_h, t_h = pose_from_H(H, K)\nok, rv, tv = cv2.solvePnP(ground, uv, K, None, flags=cv2.SOLVEPNP_IPPE)\nR_cv, _ = cv2.Rodrigues(rv)\nprint(np.abs(R_h - R).max(), np.abs(t_h - t).max())          # vs. the true pose\nprint(np.abs(R_h - R_cv).max(), np.abs(t_h - tv.ravel()).max())   # vs. solvePnP', 'say': 'בדיקה של הפונקציה, שהקורס לא הריץ: מצלמה ידועה, ארבע נקודות על הקרקע, H מ־`findHomography`, ו־`pose_from_H` — מול האמת ומול `solvePnP`. ההפרשים הם שגיאת עיגול.'}]}

# ---------------- chapter 8
HOMO_SAY = 'הקוד מייבא את `normalize` מהקובץ `homography.py` — הפונקציות של סעיף 6.2. השורות האלה כותבות אותו (ואת `geom.py`, שהוא צריך) אם הוא לא קיים.'
F['m3-b262'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'HOMO_LATER', 'say': HOMO_SAY}]}
F['m3-b267'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'HOMO_LATER', 'say': HOMO_SAY}, {'code': 'B262_LATER', 'say': 'הקוד של סעיף 8.3 — הנקודות, שתי המצלמות וההתאמות הרועשות `n1`, `n2` — כי הקוד של הסעיף ממשיך ממנו.'}]}

# ---------------- chapter 9
F['m3-b284'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}]}
F['m3-b466'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}, {'code': 'import numpy as np\nfrom geom import K, look_at, project\n', 'say': 'NumPy והפונקציות של `geom.py`.'}],
    'post': [{'code': '\n# the experiment of the exercise: 2 cameras vs 4 around the scene, noise of half a pixel\nrng = np.random.default_rng(0)\nPw = np.c_[rng.uniform(-3, 3, 200), rng.uniform(8, 16, 200), rng.uniform(0, 3, 200)]\ncams = [look_at(C, [0, 12, 1.5]) for C in ([-0.5, 0, 1.5], [0.5, 0, 1.5], [-8, 12, 3], [8, 12, 3])]\nPs = [K @ np.c_[R, t] for R, t in cams]\nuvs = [project(K, R, t, Pw)[0] + rng.normal(0, 0.5, (200, 2)) for R, t in cams]\nfor n in (2, 4):\n    X = np.array([triangulate_n(Ps[:n], [uv[i] for uv in uvs[:n]]) for i in range(200)])\n    print(n, "cameras:", round(np.linalg.norm(X - Pw, axis=1).mean() * 100, 2), "cm")', 'say': 'הקורס כותב רק את התוצאה; כאן הניסוי עצמו: 200 נקודות, רעש של חצי פיקסל, זוג סטריאו מול אותו זוג ועוד שתי מצלמות מהצדדים. המספרים שונים מהקורס (מיקומי המצלמות שלו לא נתונים), אבל המגמה אותה מגמה.'}]}

# ---------------- chapter 10
PAIR = open('/home/claude/build/pre10_pair.py', encoding='utf8').read()
F['m3-b315'] = {'pre': [{'code': PAIR, 'say': 'הקורס קורא את `left.png` ו־`right.png` בלי לתת את הקוד שמצייר אותן (זה תרגיל 10.4). כאן הוא כתוב במלואו, לפי התיאור בסעיף: לכל פיקסל, קרן; לכל משטח מקביל למצלמה, נקודת הפגיעה; הקרוב ביותר מנצח; הצבע מטבלת מרקם אקראית; ועוד רעש חיישן. השורות כותבות את שתי התמונות לתיקייה, והקוד של הסעיף קורא אותן.'}],
    'post': [{'code': '\n# how good is it? compare with the depth we know\nu, v = np.meshgrid(np.arange(640), np.arange(480))\nfor Z, x0, x1, y0, y1 in [(4.0, -0.9, 0.1, -0.4, 0.6), (7.0, 0.2, 1.6, -0.6, 0.5)]:\n    X, Y = Z * (u - 320) / f, Z * (v - 240) / f\n    m = (X >= x0) & (X <= x1) & (Y >= y0) & (Y <= y1)\n    print(Z, "m: coverage", round(valid[m].mean() * 100, 1), "%  median error", round(float(np.nanmedian(np.abs(depth[m] - Z))) * 100, 1), "cm")', 'say': 'בדיקה מול האמת — כמו הטבלה של הסעיף — לשני הלוחות: כמה מהפיקסלים שלהם קיבלו עומק, ומה השגיאה החציונית. המרקם האקראי שונה מזה של הקורס, ולכן המספרים שונים מעט.'}]}
F['m3-b325'] = {'local': True, 'skiprun': True, 'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy — לשורה האחרונה. הספריות: `pip install transformers torch pillow`.'}], 'note': '**רץ רק במחשב, עם `transformers` ו־`torch`, וצריך תמונה בשם `street.jpg` בתיקייה.** בהרצה הראשונה המודל יורד מהאינטרנט (כמאה מגה־בייט). **שים לב לשם המודל:** בקורס נכנס רווח באמצע — `Depth- Anything` — והשם הנכון הוא `depth-anything/Depth-Anything-V2-Small-hf`. עם הרווח ההורדה תיכשל בהודעה שהמודל לא נמצא.'}
F['m3-b330'] = {'pre': [{'code': 'import numpy as np\n', 'say': 'NumPy.'}]}

# ---------------- chapter 11
F['m3-b345'] = {'pre': [{'code': 'GEOM_LATER', 'say': GEOM_SAY}],
    'post': [{'code': '\n# the simulation of the section: a 10 m circle in a yard of walls, 120 frames\nfrom geom import look_at\nrng = np.random.default_rng(0)\nside = rng.integers(0, 4, 600); s = rng.uniform(-20, 20, 600); h = rng.uniform(0, 4, 600)\npts = np.where(side[:, None] == 0, np.c_[s, np.full(600, 20), h], np.where(side[:, None] == 1, np.c_[s, np.full(600, -20), h], np.where(side[:, None] == 2, np.c_[np.full(600, 20), s, h], np.c_[np.full(600, -20), s, h])))\ninner = np.c_[rng.uniform(-19, 19, 300), rng.uniform(-19, 19, 300), rng.uniform(0, 4, 300)]\npts = np.r_[pts, inner[np.abs(np.hypot(inner[:, 0], inner[:, 1]) - 10) > 2.5]]   # posts inside the yard: a single wall is a plane\nang = np.linspace(0, 2 * np.pi, 121)\nCs = np.c_[10 * np.cos(ang), 10 * np.sin(ang), np.full(121, 1.5)]\nposes = [look_at(C, C + [-np.sin(a), np.cos(a), 0]) for C, a in zip(Cs, ang)]\nfor noise in (0, 0.5, 1, 2):\n    est = visual_odometry(poses, Cs, pts, noise, np.random.default_rng(1))\n    err = np.linalg.norm(est[-1] - Cs[-1])\n    print(f"noise {noise}: end error {err:.2f} m ({err / 62.8 * 100:.1f}% of the path)")', 'say': 'הקורס נותן את הפונקציה ואת התוצאות בטבלה, בלי הקוד שבונה את החצר. השורות האלה בונות אותה לפי התיאור — מעגל ברדיוס 10 מטר, 120 צעדים, קירות עם נקודות — ומריצות את `visual_odometry` עם ארבע רמות רעש. (הוספנו גם עמודים בתוך החצר: כשהמצלמה רואה רק קיר אחד, כל הנקודות על מישור, והמטריצה החיונית מתנוונת — פרק 8.) הנקודות שלנו לא אלה של הקורס, ולכן המספרים שונים — ובין הרצות עם רעש שונה הם קופצים, כי 120 שגיאות קטנות מצטברות. ההרצה לוקחת כמה שניות.'}]}

# ---------------- chapter 12
F['m3-b376'] = {'post': [{'code': '\n# a quick check: a camera 50 m up, looking straight down (rows of R: right = east, down = south, forward = down)\nK = np.array([[1400, 0, 960], [0, 1400, 540], [0, 0, 1.0]])\nR = np.array([[1, 0, 0], [0, -1, 0], [0, 0, -1.0]])\nC = np.array([0, 0, 50.0])\nprint(pixel_to_ground([[960, 540], [1100, 540], [960, 400]], K, np.zeros(5), R, C).round(3))', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה — הרצה שלו לא מדפיסה כלום. כאן בדיקה קטנה: מצלמה בגובה 50 מטר שמסתכלת ישר למטה. הפיקסל המרכזי נופל בדיוק מתחתיה ‎(0, 0, 0)‎; פיקסל 140 פיקסלים ימינה — 140/1400 = 0.1 מהגובה, כלומר 5 מטר מזרחה; ו־140 פיקסלים למעלה בתמונה — 5 מטר צפונה.'}]}
F['m3-b382'] = {'pre': [NP], 'post': [{'code': '\nR = R_from_attitude(0, 0)\nprint(R.round(3))                         # north, horizontal: rows right=(1,0,0), down=(0,0,-1), forward=(0,1,0)\nR = R_from_attitude(30, -60)\nprint(R.round(3))\nprint(np.abs(R @ R.T - np.eye(3)).max())   # ~0: a rotation\nprint(R_from_attitude(0, -90).round(3))    # straight down works too (look_at breaks here, exercise 3.3)', 'say': 'הקוד של הסעיף רק מגדיר את הפונקציה. כאן שלוש בדיקות: במבט אופקי לצפון השורות הן ימין = מזרח, למטה = ‎(0, 0, −1)‎ וקדימה = צפון, כמו בטבלה; ‎R·Rᵀ = I‎ — זה סיבוב; ומבט ישר למטה עובד.'}]}
F['m3-b390'] = {'pre': [{'code': 'B376_LATER', 'say': 'הפונקציה `pixel_to_ground` מסעיף 12.2 — הקוד של הסעיף קורא לה.'}, {'code': 'B382_LATER', 'say': 'הפונקציה `R_from_attitude` מסעיף 12.3.'}],
    'post': [{'code': '\n# by distance from the drone (the numbers of the paragraph after the table)\nd = np.linalg.norm(G[:, :2] - C[:2], axis=1)\ne = np.linalg.norm(pixel_to_ground(uv, K, dist, R_from_attitude(30, -59), C)[:, :2] - G[:, :2], axis=1)\nfor a, b in [(0, 30), (30, 60), (60, 999)]:\n    print(a, "-", b, "m:", round(float(np.median(e[(d >= a) & (d < b)])), 2))', 'say': 'תוספת: שגיאת מעלת ה־pitch לפי המרחק מהרחפן — המספרים שהפסקה שאחרי הטבלה מצטטת (1.0, ‏1.4 ו־2.2 מטר).'}]}
F['m3-b403'] = {'local': True, 'skiprun': True, 'pre': [{'code': 'GROUND_LATER', 'say': 'הקוד מייבא את `pixel_to_ground` מהקובץ `ground.py`. השורות האלה כותבות אותו לתיקייה של הקובץ מהקוד של סעיף 12.2, אם הוא עוד לא קיים.'}],
    'post': [{'code': 'cap.release()\ncv2.destroyAllWindows()', 'say': 'משחרר את המצלמה וסוגר את החלון אחרי היציאה ב־q.'}],
    'note': '**רץ רק במחשב — צריך מצלמה, את `calib.npz` מסעיף 5.3 וסמן ArUco מודפס (DICT_4X4_50) על השולחן.** אם `cv2.aruco` חסר: `pip install opencv-contrib-python`. אם הסמן לא נמצא בפריים, `corners[0]` ייכשל — ודא שהוא בתמונה ומואר. **הרשימה `rows` מוגדרת ולא נשמרת** — השמירה ל־CSV היא תרגיל 12.2.'}
F['m3-b491'] = {'pre': [{'code': 'B376_LATER', 'say': 'הפונקציה `pixel_to_ground` מסעיף 12.2.'}, {'code': 'B382_LATER', 'say': 'הפונקציה `R_from_attitude` מסעיף 12.3, לדוגמה שבסוף.'},
    {'code': '_pixel_to_ground_full = pixel_to_ground\n\ndef pixel_to_ground(uv, K, R, C, dist=np.zeros(5), ground_z=0.0):\n    return _pixel_to_ground_full(np.array([uv], float), K, dist, R, C, ground_z)[0]\n', 'say': '**תיקון לחתימה:** הפתרון בקורס קורא ‎`pixel_to_ground(foot, K, R, C)`‎ — בלי `dist`. עם הפונקציה של 12.2 זה היה מכניס את R במקום `dist` ונכשל ב־TypeError. העטיפה הזו מקבלת נקודה אחת בסדר של הפתרון (עם `dist` כפרמטר אופציונלי בסוף) ומחזירה נקודה אחת.'}],
    'post': [{'code': '\n# try it: the drone of section 12.4, a car near the bottom of the image and one near the top\nK = np.array([[1400, 0, 960], [0, 1400, 540], [0, 0, 1.0]])\nC = np.array([0, 0, 50.0])\nR = R_from_attitude(30, -60)\nfor box in [(900, 950, 980, 1000), (900, 30, 940, 50)]:\n    P, err = bbox_to_ground(box, K, R, C)\n    P_pitch = pixel_to_ground(((box[0] + box[2]) / 2, box[3]), K, R_from_attitude(30, -59), C)\n    print(box, "->", P.round(2), " err for 2 px:", round(err, 2), "m   err for 1 deg of pitch:", round(float(np.linalg.norm(P_pitch - P)), 2), "m")', 'say': 'הפתרון בקורס מסומן "לא הורץ"; כאן הוא רץ על הרחפן של 12.4, עם מלבן ליד תחתית התמונה ומלבן ליד הקצה העליון — והשגיאה של שני פיקסלים גדלה ככל שמתקרבים לאופק (כאן פי שניים), כמו שהפתרון צופה. **תוספת:** התרגיל ביקש גם הערכה לשגיאה של מעלה בזווית, והפתרון לא כולל אותה — השורה האחרונה מחשבת אותה באותה דרך (וגם כאן — היא גדולה בהרבה משגיאת הפיקסלים).'}]}

p = 'site/content/m3.js'; s = open(p, encoding='utf8').read(); k = s.index('= {', 40) + 2
d = json.loads(s[k:].rstrip().rstrip(';'))
blocks = {}
for ch in d['chapters']:
    for sec in ch['sections']:
        for b in sec['blocks']:
            if b['type'] == 'code': blocks[b['id']] = b
    for e in ch['exercises']:
        for b in e['blocks'] + e['solution']:
            if b['type'] == 'code': blocks[b['id']] = b
F['m3-b98']['pre'][0]['code'] = _noprint(blocks['m3-b93']['text']) + '\n'
GEOM_MK = 'import os, importlib\nif not os.path.exists("geom.py"):\n    open("geom.py", "w", encoding="utf8").write(%r)\n    importlib.invalidate_caches()\n' % (_noprint(blocks['m3-b93']['text']) + '\n')
F['m3-b117']['pre'][0]['code'] = GEOM_MK
F['m3-b125']['pre'][0]['code'] = GEOM_MK
F['m3-b125']['pre'][1]['code'] = _noprint(blocks['m3-b117']['text']) + '\n'
F['m3-b155']['pre'][1]['code'] = _noprint(blocks['m3-b145']['text']) + '\n'
HOMO_MK = 'import os, importlib\nif not os.path.exists("homography.py"):\n    open("homography.py", "w", encoding="utf8").write(%r)\n    importlib.invalidate_caches()\n' % (blocks['m3-b178']['text'] + '\n')
for _b in ('m3-b178', 'm3-b183', 'm3-b193', 'm3-b202', 'm3-b222', 'm3-b228', 'm3-b451', 'm3-b262', 'm3-b267', 'm3-b284', 'm3-b466', 'm3-b345'):
    for _x in F[_b]['pre']:
        if _x['code'] == 'GEOM_LATER': _x['code'] = GEOM_MK
        elif _x['code'] == 'B178_LATER': _x['code'] = blocks['m3-b178']['text'].replace('from geom import K, look_at, project\n', 'from geom import K, look_at, project\nimport importlib\n') + '\n'
        elif _x['code'] == 'B183_LATER': _x['code'] = _noprint(blocks['m3-b183']['text']) + '\n'
        elif _x['code'] == 'HOMO_LATER': _x['code'] = HOMO_MK
        elif _x['code'] == 'B262_LATER': _x['code'] = _noprint(blocks['m3-b262']['text']) + '\n'
        elif _x['code'] == 'B193_LATER': _x['code'] = _noprint(blocks['m3-b193']['text']) + '\n'
GROUND_MK = 'import os, importlib\nif not os.path.exists("ground.py"):\n    open("ground.py", "w", encoding="utf8").write(%r)\n    importlib.invalidate_caches()\n' % (blocks['m3-b376']['text'] + '\n')
for _b in ('m3-b390', 'm3-b403', 'm3-b491'):
    for _x in F[_b]['pre']:
        if _x['code'] == 'B376_LATER': _x['code'] = blocks['m3-b376']['text'] + '\n'
        elif _x['code'] == 'B382_LATER': _x['code'] = blocks['m3-b382']['text'] + '\n'
        elif _x['code'] == 'GROUND_LATER': _x['code'] = GROUND_MK
# ---------------- section 12.7 (an addition): the three parts build on each other
F['m3-x127c1'] = {'pre': [], 'post': []}
F['m3-x127c2'] = {'pre': [{'code': _noprint(blocks['m3-x127c1']['text']) + '\n', 'say': 'חלק 1 של הסעיף — הסצנה: `camera`, `project`, קווי הנתיב `lines_px`, הרכבים `cars_px` ומסלול הרכב `track_px`. החלק הזה ממשיך ממנו.'}]}
F['m3-x127c3'] = {'pre': [{'code': _noprint(blocks['m3-x127c1']['text']) + '\n', 'say': 'חלק 1 של הסעיף — הסצנה.'}, {'code': _noprint(blocks['m3-x127c2']['text']) + '\n', 'say': 'חלק 2 של הסעיף — נקודת המגוז, `ground`, וה־K וה־R שנמצאו. החלק הזה ממשיך ממנו.'}]}
def full(bid):
    f = F.get(bid, {}); return ''.join(x['code'] + '\n' for x in f.get('pre', [])) + blocks[bid]['text'] + ''.join('\n' + x['code'] for x in f.get('post', []))
HARNESS = textwrap.dedent('''
    import sys, json, base64, io, contextlib
    import cv2, numpy as np
    SHOWN = {}; CALLS = []
    def _imshow(name, im): SHOWN[name] = np.asarray(im).copy(); CALLS.append('imshow')
    cv2.imshow = _imshow
    _w = cv2.imwrite
    def _iw(path, im, *a): SHOWN[path] = np.asarray(im).copy(); return _w(path, im, *a)
    cv2.imwrite = _iw
    cv2.waitKey = lambda *a, **k: (CALLS.append('waitKey'), -1)[1]
    cv2.destroyAllWindows = lambda *a, **k: None
    cv2.namedWindow = lambda *a, **k: None
    cv2.createTrackbar = lambda *a, **k: None
    cv2.getTrackbarPos = lambda *a, **k: 0
    import os; sys.path.insert(0, os.getcwd())             # like running the file from its own folder
    src = open(sys.argv[1], encoding='utf8').read(); buf = io.StringIO(); err = None
    try:
        with contextlib.redirect_stdout(buf): exec(compile(src, 'script.py', 'exec'), {'__name__': '__main__'})
    except Exception as e: err = type(e).__name__ + ': ' + str(e)
    figs = []
    for name, im in list(SHOWN.items())[:3]:
        h, w = im.shape[:2]
        if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode('.png', im); figs.append('data:image/png;base64,' + base64.b64encode(b.tobytes()).decode())
    print(json.dumps({'stdout': buf.getvalue(), 'err': err, 'figs': figs, 'calls': CALLS}))
''')
open('/tmp/harness_sa.py', 'w').write(HARNESS)
ids = [b for b in blocks if b in F ]
bad = 0
for bid in ids:
    src = full(bid)
    if F[bid].get('skiprun'): print('SKIP', bid, '(needs libraries that are not installed here)'); continue
    with tempfile.TemporaryDirectory() as td:                      # empty folder, fresh interpreter: like a new PyCharm file
        open(os.path.join(td, 'script.py'), 'w', encoding='utf8').write(src)
        r = subprocess.run([sys.executable, '/tmp/harness_sa.py', 'script.py'], cwd=td, capture_output=True, text=True, timeout=120)
        try: o = json.loads(r.stdout.strip().splitlines()[-1])
        except Exception: o = {'err': 'harness: ' + r.stderr[-300:], 'stdout': '', 'figs': [], 'calls': []}
    shows = o['calls'].count('imshow'); waits = o['calls'].count('waitKey')
    status = 'OK ' if not o['err'] else 'ERR'
    if o['err']: bad += 1
    print(status, bid, '| stdout:', o['stdout'].strip().replace('\n', ' / ')[:70], '| windows:', shows, 'waitKey:', waits, '|', o['err'] or '')
    if not o['err']:
        out = {'stdout': o['stdout'][:4000]}
        if o['figs']: out['figs'] = o['figs']
        blocks[bid]['output'] = out
if bad: sys.exit('some scripts failed')
open(p, 'w', encoding='utf8').write(s[:k] + json.dumps(d, ensure_ascii=False) + ';\n')
open('site/content/m3_codefull.js', 'w', encoding='utf8').write('/* Module 3 — additions that make each code example run on its own (generated by standalone_m3.py). */\n(window.LAYER.m3.codeFull = ' + json.dumps(F, ensure_ascii=False, indent=1) + ');\n')
print('written', len(F))

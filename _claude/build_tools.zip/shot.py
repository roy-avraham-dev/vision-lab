import asyncio, sys, json
from playwright.async_api import async_playwright
async def main():
    pages = sys.argv[1].split(',')
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1300, 'height': 900})
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append('console: ' + m.text) if m.type == 'error' else None)
        for i, h in enumerate(pages):
            await pg.goto('file:///home/claude/build/site/index.html#' + h)
            await pg.wait_for_timeout(400)
            if len(sys.argv) > 2: await pg.screenshot(path=f'/home/claude/build/shot_{i}.png', full_page=sys.argv[2] == 'full')
            n = await pg.evaluate("document.querySelectorAll('.err').length")
            if n: errs.append(f'{h}: {n} widget errors: ' + await pg.evaluate("[...document.querySelectorAll('.err')].map(e=>e.textContent).join(' | ')"))
        print('ERRORS:', json.dumps([e for e in errs if 'pyodide' not in e and 'ERR_' not in e], ensure_ascii=False, indent=0) if errs else 'none')
        await b.close()
asyncio.run(main())

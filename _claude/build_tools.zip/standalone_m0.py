# Stand-alone additions for the code examples of module 0: writes site/content/m0_codefull.js,
# verifies every full script in a fresh process and an empty folder, and refreshes the precomputed outputs in m0.js.
import json, os, subprocess, sys, tempfile, base64, textwrap
PIP = 'אם PyCharm מסמן את `cv2` או את `numpy` באדום, הרץ פעם אחת בטרמינל שלו: `pip install opencv-python numpy`.'
IMP = {'code': 'import cv2\nimport numpy as np\n', 'say': 'שתי הספריות שהקוד משתמש בהן. ' + PIP}
def show(*names, extra=''):
    return {'code': extra + ''.join(f'cv2.imshow("{n}", {n})\n' for n in names) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()',
            'say': 'מציג את התוצאה: ' + ('חלון אחד' if len(names) == 1 else f'{len(names)} חלונות') + ' (' + ', '.join(f'`{n}`' for n in names) + '). לחיצה על מקש כלשהו, כשאחד החלונות בפוקוס, סוגרת אותם.'}
NP = {'code': 'import numpy as np\n', 'say': 'NumPy. אם PyCharm מסמן אותה באדום: `pip install numpy`.'}
F = {}
NP = {'code': 'import numpy as np\n', 'say': 'ספריית המערכים. אם PyCharm מסמן אותה באדום: ‏`pip install numpy` בטרמינל שלו.'}
# ---------------- chapter 1
for _b in ('m0-b30', 'm0-b34', 'm0-b38', 'm0-b45'): F[_b] = {}
F['m0-b52'] = {'pre': [NP]}
F['m0-b56'] = {'pre': [NP, {'code': 'img = np.array([[[10, 120, 250], [100, 200, 255]],\n                [[0, 50, 248], [30, 60, 90]]], dtype=np.uint8)   # a tiny 2x2 color image\n', 'say': 'תמונה זעירה של 2 על 2 פיקסלים בשלושה ערוצים, כדי שיהיה על מה לעבוד — עם כמה ערכים קרובים ל־255, כדי לראות את החיתוך.'}],
    'post': [{'code': '\nprint(img + 10)          # wrong: uint8 wraps around (250 + 10 -> 4)\nprint(brighter)          # right: clipped at 255', 'say': 'מדפיס את שתי הדרכים זו מול זו: החיבור הישיר גולש (‏250 הופך ל־4, ‏255 ל־9), והדרך עם float ו־clip עוצרת ב־255.'}]}
for _b in ('m0-b61', 'm0-b66', 'm0-b73', 'm0-b79', 'm0-b85'): F[_b] = {'pre': [NP]}
F['m0-b94'] = {'pre': [NP, {'code': 'M = np.arange(6).reshape(2, 3)\nA = np.ones((2, 3)); B = np.ones((3, 4))\n', 'say': 'שלושה מערכים קטנים, כדי שלשלוש השורות האחרונות יהיה על מה לפעול: ‏M בצורה (2, 3), ו־A ו־B בצורות שאפשר לכפול.'}],
    'post': [{'code': '\n# the lines above compute values but print nothing — print a few of them:\nprint(np.arange(0, 1, 0.25))\nprint(np.linspace(0, 1, 5))\nnp.random.seed(0); print(np.random.randn(3))\nprint(M.T.shape, (A @ B).shape, M.reshape(3, 2).shape)', 'say': 'השורות של הסעיף מחשבות ערכים אבל לא מדפיסות כלום (במחברת, הערך של השורה האחרונה מוצג לבד; בקובץ — לא). ההדפסות מראות את התוצאות החשובות.'}]}
F['m0-b98'] = {'pre': [NP]}
# ---------------- chapter 2
F['m0-b126'] = {'pre': [NP]}
F['m0-b133'] = {'pre': [NP]}
F['m0-b151'] = {'pre': [NP, {'code': 'img = np.array([[[255, 255, 255], [0, 0, 255]],\n                [[0, 255, 0], [255, 0, 0]]], dtype=np.uint8)   # white, red / green, blue (B, G, R)\n', 'say': 'תמונה זעירה של ארבעה פיקסלים: לבן, אדום, ירוק וכחול (בסדר כחול, ירוק, אדום של OpenCV) — כדי לראות כמה "אור" מקבל כל צבע באפור.'}],
    'post': [{'code': '\nprint(gray.shape)\nprint(gray)        # white 255, red 76.2, green 149.7, blue 29.1', 'say': 'הצורה (2, 2) — הממד של הערוצים נעלם — והערכים: לבן נשאר 255 (סכום המשקלות 1), ירוק הכי בהיר, כחול הכי כהה.'}]}
# ---------------- chapter 3
F['m0-b187'] = {'pre': [NP]}
F['m0-b194'] = {'pre': [NP], 'post': [{'code': '\n# check it against the fast version\nA = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])   # (3, 2)\nB = np.array([[1.0, 0.0, 2.0], [0.0, 1.0, 3.0]])     # (2, 3)\nprint(matmul(A, B))\nprint(np.allclose(matmul(A, B), A @ B))       # True: the same numbers', 'say': 'מטריצות קטנות לבדיקה — <span class="ltr">(3, 2)</span> כפול <span class="ltr">(2, 3)</span> — והשוואה לתוצאה של <code class="ltr">@</code>. ‏<code class="ltr">np.allclose</code> בודקת שהמספרים שווים עד שגיאת עיגול.'}]}
F['m0-b212'] = {'pre': [NP]}
# ---------------- chapter 4
F['m0-b235'] = {'pre': [NP]}
# ---------------- chapter 5
for _b in ('m0-b267', 'm0-b276', 'm0-b285', 'm0-b301'): F[_b] = {'pre': [NP]}
# ---------------- chapter 6
F['m0-b318'] = {}
F['m0-b344'] = {'pre': [NP]}
# ---------------- chapter 7
F['m0-b375'] = {}
F['m0-b384'] = {'pre': [NP]}
F['m0-b393'] = {'skiprun': True, 'local': True, 'note': '**רץ רק במחשב — צריך <code class="ltr">pip install torch</code>** (כמה מאות MB; בלי כרטיס מסך זה בסדר). מה לצפות: <span class="ltr">tensor(-4.) tensor(-2.)</span> — אותם מספרים כמו בחישוב הידני של 7.3. ההדמיה של הסעיף מריצה מנוע גזירה זעיר באותה שיטה, בדפדפן.'}
# ---------------- chapter 8
F['m0-b419'] = {}
# ---------------- chapter 9
for _b in ('m0-b452', 'm0-b462', 'm0-b476'): F[_b] = {'pre': [NP]}
F['m0-b467'] = {'pre': [NP], 'post': [{'code': '\nprint(mean.shape, normalized.shape)\nprint(normalized.mean(axis=(0, 1, 2)).round(3), normalized.std(axis=(0, 1, 2)).round(3))', 'say': 'הקוד של הסעיף לא מדפיס כלום — כאן בודקים את התוצאה: ‏mean בצורה (3,), ואחרי הנרמול ממוצע 0 וסטיית תקן 1 בכל ערוץ (‏-0. הוא אפס שלילי זעיר — עיגול).'}]}
# ---------------- chapter 10
F['m0-b516'] = {'pre': [NP]}
# ---------------- chapter 11
F['m0-b546'] = {'pre': [NP], 'post': [{'code': '\n# try it on the 5x5 example of the figure\nimg = np.array([[3, 0, 1, 2, 7], [1, 5, 8, 9, 3], [2, 7, 2, 5, 1], [0, 1, 3, 1, 7], [4, 2, 1, 6, 2]], float)\nk = np.array([[1, 0, -1], [1, 0, -1], [1, 0, -1]], float)\nprint(conv2d(img, k))', 'say': 'הסעיף רק מגדיר את הפונקציה. כאן מריצים אותה על הדוגמה של 5 על 5 מהאיור, עם גרעין "שמאל פחות ימין" — הפלט בגודל 3 על 3, והפינה השמאלית העליונה ‏−5, כמו בהדמיה.'}]}
# ---------------- chapter 12
F['m0-b601'] = {}
F['m0-b608'] = {'pre': [{'code': 'PROJECT_LATER', 'say': 'כל הקוד של סעיף 12.4 — הבדיקה צריכה את <code>predict_proba</code>, את <code>loss_fn</code> ואת <code>X_train</code> שלו. (חלון הגרפים ייפתח קודם; סגור אותו, והבדיקה תודפס.)'}]}
#@@CH@@

p = 'site/content/m0.js'; s = open(p, encoding='utf8').read(); k = s.index('= {') + 2
d = json.loads(s[k:].rstrip().rstrip(';'))
blocks = {}
for ch in d['chapters']:
    for sec in ch['sections']:
        for b in sec['blocks']:
            if b['type'] == 'code': blocks[b['id']] = b
    for e in ch['exercises']:
        for b in e['blocks'] + e['solution']:
            if b['type'] == 'code': blocks[b['id']] = b
LATER = {'PROJECT_LATER': 'm0-b601'}   # 'NAME_LATER': block id whose text replaces a pre placeholder
for _b, _f in F.items():
    for _x in _f.get('pre', []):
        if _x['code'] in LATER: _x['code'] = blocks[LATER[_x['code']]]['text'] + '\n'
def full(bid):
    f = F.get(bid, {}); return ''.join(x['code'] + '\n' for x in f.get('pre', [])) + blocks[bid]['text'] + ''.join('\n' + x['code'] for x in f.get('post', []))
HARNESS = textwrap.dedent('''
    import sys, json, base64, io, contextlib
    import cv2, numpy as np
    SHOWN = {}; CALLS = []
    def _imshow(name, im): SHOWN[name] = np.asarray(im).copy(); CALLS.append('imshow')
    cv2.imshow = _imshow
    _w = cv2.imwrite
    def _iw(path, im, *a): SHOWN[path] = np.asarray(im).copy(); return _w(path, im, *a)
    cv2.imwrite = _iw
    cv2.waitKey = lambda *a, **k: (CALLS.append('waitKey'), -1)[1]
    cv2.destroyAllWindows = lambda *a, **k: None
    cv2.namedWindow = lambda *a, **k: None
    cv2.createTrackbar = lambda *a, **k: None
    cv2.getTrackbarPos = lambda *a, **k: 0
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    def _pshow(*a, **k):
        f = io.BytesIO(); plt.gcf().savefig(f, format='png', dpi=60, bbox_inches='tight'); plt.close('all')
        SHOWN['plt%d' % len(SHOWN)] = cv2.imdecode(np.frombuffer(f.getvalue(), np.uint8), cv2.IMREAD_COLOR); CALLS.append('plt')
    plt.show = _pshow
    import os; sys.path.insert(0, os.getcwd())             # like running the file from its own folder
    src = open(sys.argv[1], encoding='utf8').read(); buf = io.StringIO(); err = None
    try:
        with contextlib.redirect_stdout(buf): exec(compile(src, 'script.py', 'exec'), {'__name__': '__main__'})
    except Exception as e: err = type(e).__name__ + ': ' + str(e)
    figs = []
    for name, im in list(SHOWN.items())[:3]:
        h, w = im.shape[:2]
        if w > 520: im = cv2.resize(im, (520, int(h * 520 / w)), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode('.png', im); figs.append('data:image/png;base64,' + base64.b64encode(b.tobytes()).decode())
    print(json.dumps({'stdout': buf.getvalue(), 'err': err, 'figs': figs, 'calls': CALLS}))
''')
open('/tmp/harness_sa.py', 'w').write(HARNESS)
ids = [b for b in blocks if b in F ]
bad = 0
for bid in ids:
    src = full(bid)
    if F[bid].get('skiprun'): print('SKIP', bid, '(needs libraries that are not installed here)'); continue
    with tempfile.TemporaryDirectory() as td:                      # empty folder, fresh interpreter: like a new PyCharm file
        open(os.path.join(td, 'script.py'), 'w', encoding='utf8').write(src)
        r = subprocess.run([sys.executable, '/tmp/harness_sa.py', 'script.py'], cwd=td, capture_output=True, text=True, timeout=120)
        try: o = json.loads(r.stdout.strip().splitlines()[-1])
        except Exception: o = {'err': 'harness: ' + r.stderr[-300:], 'stdout': '', 'figs': [], 'calls': []}
    shows = o['calls'].count('imshow'); waits = o['calls'].count('waitKey')
    status = 'OK ' if not o['err'] else 'ERR'
    if o['err']: bad += 1
    print(status, bid, '| stdout:', o['stdout'].strip().replace('\n', ' / ')[:70], '| windows:', shows, 'waitKey:', waits, '|', o['err'] or '')
    if not o['err']:
        out = {'stdout': o['stdout'][:4000]}
        if o['figs']: out['figs'] = o['figs']
        blocks[bid]['output'] = out
if bad: sys.exit('some scripts failed')
open(p, 'w', encoding='utf8').write(s[:k] + json.dumps(d, ensure_ascii=False) + ';\n')
open('site/content/m0_codefull.js', 'w', encoding='utf8').write('/* Module 0 — additions that make each code example run on its own (generated by standalone_m0.py). */\n(window.LAYER.m0.codeFull = ' + json.dumps(F, ensure_ascii=False, indent=1) + ');\n')
print('written', len(F))

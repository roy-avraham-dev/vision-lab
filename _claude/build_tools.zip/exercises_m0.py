# Module 0: levels and question explanations for the course exercises, plus supplementary exercises
# that cover the sections the original sets do not reach. Validates every automatic check (starter must fail,
# solution must pass) and every solution script, then writes site/content/m0_exercises.js.
import json, subprocess, sys, tempfile, os

# ---------- the course's own exercises: level (1 warm-up, 2 practice, 3 challenge), section, and what the question asks ----------
META = {}

def T(task, starter, body, solved):
    return {'task': task, 'starter': starter, 'body': body, 'solved': solved}

IMPORTS = 'import cv2\nimport numpy as np\n\n'
SHOW = lambda *n: ''.join(f'cv2.imshow("{x}", {x})\n' for x in n) + 'cv2.waitKey(0)\ncv2.destroyAllWindows()'

X = []

META.update({
 '1.1': (1, '1.6', '**זה תרגיל קוד קצר.** **נתון:** המספרים 1 עד 12. **מה לעשות:** טבלה של 3 על 4, העמודה האחרונה, וסכום כל שורה. **איך תדע שהצלחת:** ‏<span class="ltr">[4 8 12]</span> ו־<span class="ltr">[10 26 42]</span> — הסכום לפי <code class="ltr">axis=1</code> (סעיף 1.8).'),
 '1.2': (1, '1.4', '**זו שאלת חיזוי.** **נתון:** מערך <code class="ltr">uint8</code> כפול 2. **מה לעשות:** לנחש, ואז להריץ. **איך תדע שהצלחת:** כל ערך מעל 255 יורד ב־256.'),
 '1.3': (1, '1.6', '**שורה אחת.** **נתון:** תמונה בצורה <span class="ltr">(100, 200, 3)</span>. **מה לעשות:** לאפס את הערוץ שבאינדקס 1. **איך תדע שהצלחת:** חיתוך עם נקודתיים לשני הממדים הראשונים, ואינדקס בשלישי.'),
 '1.4': (2, '1.9', '**זו שאלה על הנייר.** **נתון:** שלושה זוגות צורות. **מה לעשות:** לכל זוג — תקין או לא, ומה הצורה. **איך תדע שהצלחת:** מיישרים מימין; הבודק בהדמיה של 1.9 מאשר.'),
 '1.5': (2, '1.7', '**שורה אחת, בלי לולאה.** **נתון:** מערך ציונים. **מה לעשות:** כמה מעל הממוצע. **איך תדע שהצלחת:** מסכה, ואז <code class="ltr">.sum()</code>.'),
 '1.6': (3, '1.3', '**זה ניסוי שמריצים במחשב.** **נתון:** מיליון מספרים אקראיים. **מה לעשות:** לסכם בלולאה ובפעולה אחת, ולמדוד. **איך תדע שהצלחת:** יחס של עשרות פעמים; המספר המדויק תלוי במחשב.'),
})
X += [
 # ------------------------------------------------ chapter 1
 {'id': '1.7', 'ch': 1, 'level': 1, 'sec': '1.1',
  'q': ['**זו שאלת אבחון.** לכל הודעה — מה הסיבה, ומה מריצים כדי לתקן?',
        {'table': [['ההודעה', 'איפה'], ['<span class="ltr">\'pip\' is not recognized as an internal or external command</span>', 'שורת הפקודה של חלונות'], ['<span class="ltr">ModuleNotFoundError: No module named \'numpy\'</span>', 'הרצה ב־PyCharm, אחרי ש־pip install numpy הצליח'], ['<span class="ltr">SyntaxError: invalid syntax</span> על <span class="ltr">pip install numpy</span>', 'אחרי <span class="ltr">&gt;&gt;&gt;</span>'], ['<span class="ltr">ModuleNotFoundError: No module named \'cv2\'</span>', 'אחרי <span class="ltr">pip install cv2</span> שנכשל']]}],
  'hints': ['שלוש מתוך ארבע הן "איזה פייתון" או "איפה מקלידים".'],
  'sol': ['(1) ‏pip לא בנתיב: <span class="ltr">python -m pip install numpy</span> (או <span class="ltr">py -m pip …</span>). (2) PyCharm מריץ פייתון אחר (סביבה וירטואלית): להתקין מהטרמינל של PyCharm, או לבחור את הפייתון הנכון ב־<span class="ltr">Settings → Python Interpreter</span>. (3) הקלדת פקודת מערכת בתוך פייתון: לצאת (<span class="ltr">exit()</span>) ולהריץ בשורת הפקודה. (4) שם החבילה שונה משם הייבוא: <span class="ltr">pip install opencv-python</span>.']},
 {'id': '1.8', 'ch': 1, 'level': 2, 'sec': '1.2',
  'q': ['**ציד באגים — מג׳אווה לפייתון.** מישהו תרגם פונקציה מג׳אווה: הממוצע של המספרים הזוגיים ברשימה. היא רצה, אבל מחזירה תוצאה שגויה. מצא את שתי הטעויות ותקן.',
        {'code': 'def average_of_evens(nums):\n    total = 0\n    count = 0\n    for n in nums:\n        if n % 2 == 0:\n            total += n\n        count += 1\n    return total // count\n\nprint(average_of_evens([1, 2, 3, 4, 6]))   # expected 4.0', 'norun': True},
        '**א.** מה הפונקציה מחזירה כרגע, ולמה?', '**ב.** מה היה קורה ברשימה בלי אף מספר זוגי?'],
  'hints': ['באיזה בלוק נמצאת השורה <code class="ltr">count += 1</code>?', 'מה ההבדל בין <code class="ltr">/</code> ל־<code class="ltr">//</code>?'],
  'sol': ['**א.** כרגע: ‏2. ‏<code class="ltr">count += 1</code> מוזחת כמו ה־<code class="ltr">if</code>, ולכן היא בתוך הלולאה ומחוץ לתנאי — סופרת את כל חמשת המספרים: <span class="ltr">12 // 5 = 2</span>. וגם <code class="ltr">//</code> היא חלוקה שלמה — ממוצע צריך <code class="ltr">/</code>. אחרי התיקון: <span class="ltr">12 / 3 = 4.0</span>.', '**ב.** ‏<code class="ltr">ZeroDivisionError</code>. מחזירים משהו מוסכם (למשל <code class="ltr">0.0</code> או <code class="ltr">None</code>) כשאין זוגיים.'],
  'test': T('תקן את average_of_evens.',
            'def average_of_evens(nums):\n    total = 0\n    count = 0\n    for n in nums:\n        if n % 2 == 0:\n            total += n\n        count += 1\n    return total // count\n',
            "assert average_of_evens([1, 2, 3, 4, 6]) == 4.0, f'הממוצע של 2, 4, 6 הוא 4.0; קיבלתי {average_of_evens([1, 2, 3, 4, 6])}'\nassert average_of_evens([2, 3]) == 2.0, 'רק 2 זוגי — הממוצע 2.0'\nassert average_of_evens([1, 2]) == 2.0\nassert abs(average_of_evens([2, 5, 3]) - 2.0) < 1e-9 and abs(average_of_evens([1, 2, 3]) - 2.0) < 1e-9\nassert average_of_evens([2, 3, 4, 5]) == 3.0, 'ממוצע של 2 ו־4 — 3.0, לא חלוקה שלמה'",
            'def average_of_evens(nums):\n    total = 0\n    count = 0\n    for n in nums:\n        if n % 2 == 0:\n            total += n\n            count += 1\n    return total / count\n')},
 {'id': '1.9', 'ch': 1, 'level': 2, 'sec': '1.5',
  'q': ['שילוב של שתי תמונות. השלם את <code class="ltr">blend(a, b, alpha)</code>: שתי תמונות <code class="ltr">uint8</code> באותה צורה, ומחזירה <span class="ltr">alpha·a + (1 − alpha)·b</span>, מעוגל, כ־<code class="ltr">uint8</code>.',
        '**א.** למה הגרסה הנאיבית <code class="ltr">(a + b) // 2</code> (ל־<span class="ltr">alpha = 0.5</span>) שגויה?', '**ב.** למה צריך לעגל לפני ההמרה, ולא לחתוך?'],
  'hints': ['<code class="ltr">a.astype(np.float32)</code> לפני החשבון.', '<code class="ltr">np.round(...).astype(np.uint8)</code>.'],
  'sol': ['**א.** ‏<code class="ltr">a + b</code> מחושב ב־<code class="ltr">uint8</code> וגולש לפני החלוקה: <span class="ltr">200 + 100 = 300 → 44</span>, וחלקי 2 — ‏22 במקום 150.', '**ב.** ‏<code class="ltr">astype(np.uint8)</code> חותך את השבר (127.9 הופך ל־127), כך שהתמונה כולה כהה בממוצע בחצי רמה. ‏<code class="ltr">np.round</code> קודם. (‏<code class="ltr">clip</code> לא נחוץ כאן: שילוב קמור של ערכים בטווח נשאר בטווח.)'],
  'test': T('השלם את blend.',
            'import numpy as np\n\ndef blend(a, b, alpha):\n    return (alpha * a + (1 - alpha) * b).astype(np.uint8)     # TODO: compute in float, round\n',
            "import numpy as np\na = np.array([[200, 255, 0]], dtype=np.uint8); b = np.array([[100, 255, 1]], dtype=np.uint8)\nr = blend(a, b, 0.5)\nassert r.dtype == np.uint8, f'התוצאה צריכה להיות uint8; קיבלתי {r.dtype}'\nassert r.tolist() == [[150, 255, 0]], f'ציפיתי ל־[[150 255 0]]; קיבלתי {r.tolist()} — האם עיגלת?'\nr2 = blend(np.array([10], np.uint8), np.array([11], np.uint8), 0.3)\nassert r2.tolist() == [11], f'0.3*10 + 0.7*11 = 10.7, מעוגל 11; קיבלתי {r2.tolist()}'",
            'import numpy as np\n\ndef blend(a, b, alpha):\n    out = alpha * a.astype(np.float32) + (1 - alpha) * b.astype(np.float32)\n    return np.round(out).astype(np.uint8)\n')},
 {'id': '1.10', 'ch': 1, 'level': 2, 'sec': '1.8',
  'q': ['נרמול לפי ערוץ — הצעד שלפני כל רשת. השלם את <code class="ltr">standardize(img)</code>: תמונה בצורה <span class="ltr">(H, W, 3)</span>; מחזירה <code class="ltr">float32</code> באותה צורה, שבה לכל ערוץ ממוצע 0 וסטיית תקן 1. בלי לולאה.',
        '**א.** מה צורת הממוצע שאתה מחשב, ולמה הוא משתדר עם התמונה?', '**ב.** מה היה קורה עם <code class="ltr">img.mean(axis=2)</code>?'],
  'hints': ['<code class="ltr">img.mean(axis=(0, 1))</code> — הערוצים נשארים.', 'אותו דבר ל־<code class="ltr">std</code>, ואז <span class="ltr">(img − mean) / std</span>.'],
  'sol': ['**א.** ‏<span class="ltr">(3,)</span> — שורות ועמודות נעלמו. ‏<span class="ltr">(H, W, 3)</span> מול <span class="ltr">(3,)</span>: ‏3 מול 3, והשאר חסרים — משתדר.', '**ב.** ממוצע לכל <i>פיקסל</i>, בצורה <span class="ltr">(H, W)</span>. מול <span class="ltr">(H, W, 3)</span> — ‏W מול 3 — שגיאה (או, בתמונה שהרוחב שלה 3, תוצאה שגויה בשקט). ו־<code class="ltr">keepdims=True</code> היה נותן משהו אחר לגמרי: נרמול של כל פיקסל בין הערוצים שלו.'],
  'test': T('השלם את standardize.',
            'import numpy as np\n\ndef standardize(img):\n    x = img.astype(np.float32)\n    return (x - x.mean()) / x.std()     # TODO: per channel\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nimg = np.stack([rng.integers(0, 50, (20, 30)), rng.integers(100, 255, (20, 30)), rng.integers(0, 255, (20, 30))], axis=2).astype(np.uint8)\nr = standardize(img)\nassert r.shape == (20, 30, 3) and r.dtype == np.float32, f'צורה {r.shape}, טיפוס {r.dtype}'\nm = r.mean(axis=(0, 1)); sd = r.std(axis=(0, 1))\nassert np.allclose(m, 0, atol=1e-4), f'הממוצע של כל ערוץ צריך להיות 0; קיבלתי {np.round(m, 3)}'\nassert np.allclose(sd, 1, atol=1e-3), f'סטיית התקן של כל ערוץ צריכה להיות 1; קיבלתי {np.round(sd, 3)}'",
            'import numpy as np\n\ndef standardize(img):\n    x = img.astype(np.float32)\n    return (x - x.mean(axis=(0, 1))) / x.std(axis=(0, 1))\n')},
 {'id': '1.11', 'ch': 1, 'level': 2, 'sec': '1.10',
  'q': ['**זו שאלת חיזוי.** כמה איברים בכל מערך? כתוב תשובה לכל שורה, ואז הרץ.',
        {'code': 'import numpy as np\nprint(len(np.arange(0, 1, 0.25)))\nprint(len(np.linspace(0, 1, 5)))\nprint(len(np.arange(1, 1.3, 0.1)))\nprint(np.zeros((2, 3)).size, np.eye(4).sum())\nprint(np.arange(12).reshape(3, -1).shape)'},
        '**א.** איזו שורה הפתיעה, ולמה?', '**ב.** איך היית כותב את השלישית כך שתמיד תיתן בדיוק שלוש נקודות?'],
  'hints': ['‏<code class="ltr">arange</code> עוצר כשהערך <i>הבא</i> לא קטן מהסוף — ו־<span class="ltr">1 + 3·0.1</span> בנקודה צפה הוא לא בדיוק 1.3.'],
  'sol': ['‏4, ‏5, ‏<b>4</b>, ‏6 ו־4.0, ‏<span class="ltr">(3, 4)</span>. **א.** השלישית: ‏<span class="ltr">1 + 3 · 0.1</span> יוצא <span class="ltr">1.2999999999999998</span>, שקטן מ־1.3 — ולכן הוא נכנס, ומקבלים ארבעה איברים. ‏<code class="ltr">np.eye(4).sum()</code> הוא 4.0 — ארבעה אחדים באלכסון. ‏<code class="ltr">-1</code> ב־<code class="ltr">reshape</code> מחושב: <span class="ltr">12 / 3 = 4</span>.', '**ב.** ‏<code class="ltr">np.linspace(1, 1.2, 3)</code> — מספר הנקודות קבוע, והקצוות כלולים.']},
 {'id': '1.12', 'ch': 1, 'level': 3, 'sec': '1.9',
  'q': ['**אתגר — כל המרחקים בבת אחת.** במודול 4 תשייך זיהויים בפריים הנוכחי לזיהויים בפריים הקודם לפי מרחק. השלם את <code class="ltr">pairwise_dist(P, Q)</code>: ‏<span class="ltr">P</span> בצורה <span class="ltr">(N, 2)</span> ו־<span class="ltr">Q</span> בצורה <span class="ltr">(M, 2)</span> (נקודות <span class="ltr">x, y</span>); מחזירה מטריצה <span class="ltr">(N, M)</span> שבה האיבר <span class="ltr">[i, j]</span> הוא המרחק בין <span class="ltr">P[i]</span> ל־<span class="ltr">Q[j]</span>. <b>בלי לולאה</b>.',
        '**א.** מה הצורות של <code class="ltr">P[:, None]</code>, של <code class="ltr">Q[None]</code> ושל ההפרש ביניהם?', '**ב.** לכל נקודה ב־<span class="ltr">P</span>, איך מוצאים את הקרובה ביותר ב־<span class="ltr">Q</span> בשורה אחת?', '**ג.** כמה זיכרון לוקח ההפרש ל־<span class="ltr">N = M = 10,000</span> ב־<code class="ltr">float64</code>?'],
  'hints': ['‏<span class="ltr">(N, 1, 2)</span> מול <span class="ltr">(1, M, 2)</span> משתדר ל־<span class="ltr">(N, M, 2)</span>.', 'מרחק: שורש של סכום הריבועים לאורך הציר האחרון.'],
  'sol': ['**א.** ‏<span class="ltr">(N, 1, 2)</span>, ‏<span class="ltr">(1, M, 2)</span>, וההפרש <span class="ltr">(N, M, 2)</span> — כל זוג, כל קואורדינטה. ואז <code class="ltr">np.sqrt((d ** 2).sum(axis=2))</code>.', '**ב.** ‏<code class="ltr">pairwise_dist(P, Q).argmin(axis=1)</code> — לכל שורה, העמודה עם המרחק הקטן ביותר.', '**ג.** ‏<span class="ltr">10,000 · 10,000 · 2 · 8</span> בתים = 1.6 GB. שידור חוסך כתיבת לולאות — לא זיכרון. לנקודות רבות מחשבים בבלוקים, או בנוסחה <span class="ltr">|p|² + |q|² − 2p·q</span> שבונה רק את מטריצת <span class="ltr">(N, M)</span>.'],
  'test': T('השלם את pairwise_dist.',
            'import numpy as np\n\ndef pairwise_dist(P, Q):\n    return np.sqrt(((P - Q) ** 2).sum(axis=1))     # TODO: all pairs, not row by row\n',
            "import numpy as np\nP = np.array([[0, 0], [3, 4], [1, 1]], float); Q = np.array([[0, 0], [6, 8]], float)\nD = pairwise_dist(P, Q)\nassert D.shape == (3, 2), f'צורה (3, 2) — שורה לכל נקודה ב־P; קיבלתי {D.shape}'\nassert np.allclose(D, [[0, 10], [5, 5], [2 ** 0.5, 74 ** 0.5]]), f'קיבלתי {np.round(D, 3).tolist()}'\nrng = np.random.default_rng(0); A = rng.random((50, 2)); B = rng.random((70, 2))\nref = np.array([[np.hypot(*(a - b)) for b in B] for a in A])\nassert np.allclose(pairwise_dist(A, B), ref)",
            'import numpy as np\n\ndef pairwise_dist(P, Q):\n    d = P[:, None, :] - Q[None, :, :]\n    return np.sqrt((d ** 2).sum(axis=2))\n')},
]

META.update({
 '2.1': (1, '2.2', '**חישוב ביד.** **נתון:** חיבור, כפל בסקלר ואורך. **מה לעשות:** לחשב בלי מחשב. **איך תדע שהצלחת:** <span class="ltr">(5, 11)</span> ו־10 — ובדיקה ב־NumPy.'),
 '2.2': (1, '2.4', '**חישוב ביד.** **נתון:** שני וקטורים. **מה לעשות:** מכפלה סקלרית, ומה היא אומרת על הזווית. **איך תדע שהצלחת:** אפס — מאונכים.'),
 '2.3': (2, '2.2', '**חישוב ביד.** **נתון:** מיקום ומהירות. **מה לעשות:** מיקום בעוד 10 פריימים, וכמה זז. **איך תדע שהצלחת:** ‏<span class="ltr">p + 10v</span>, ואז האורך של <span class="ltr">10v</span> (סעיף 2.3).'),
 '2.4': (2, '2.4', '**זה תרגיל קוד קצר.** **נתון:** הנוסחה של דמיון קוסינוס. **מה לעשות:** פונקציה, ובדיקה על <span class="ltr">(1, 0)</span> ו־<span class="ltr">(1, 1)</span>. **איך תדע שהצלחת:** כ־0.707 — הקוסינוס של 45 מעלות.'),
 '2.5': (3, '2.3', '**חישוב, אפשר עם NumPy.** **נתון:** שלושה פיקסלים בסדר BGR. **מה לעשות:** מרחקים בין כל זוג, ומי דומים. **איך תדע שהצלחת:** מרחק אחד קטן (כ־23) ושניים גדולים; והצבע — לפי הערוץ הגבוה, בסדר הנכון.'),
})
X += [
 # ------------------------------------------------ chapter 2
 {'id': '2.6', 'ch': 2, 'level': 1, 'sec': '2.1',
  'q': ['**זו שאלה על הנייר.** מה האורך של הוקטור בכל מקרה?',
        {'table': [['מה', 'אורך הוקטור'], ['פיקסל צבעוני', '?'], ['תמונת אפור של 28 על 28, פרוסה לשורה', '?'], ['חלון צבעוני של 8 על 8', '?'], ['מיקום ומהירות של רכב בתמונה, יחד', '?'], ['שיכון של SigLIP 2 בסיסי (מודול 7)', '?']]},
        '**א.** באיזה מהם הגיוני לחשב מרחק אוקלידי, ובאיזה דמיון קוסינוס?'],
  'hints': ['חלון צבעוני: שורות כפול עמודות כפול ערוצים.'],
  'sol': ['‏3; ‏784; ‏<span class="ltr">8 · 8 · 3 = 192</span>; ‏4 — <span class="ltr">(x, y, vx, vy)</span>, המצב של מסנן קלמן במודול 5; ‏768. **א.** מיקומים ומרחקים בפיקסלים — אוקלידי: האורך הוא בדיוק מה שמעניין. שיכונים — קוסינוס: האורך שלהם חסר משמעות, רק הכיוון. צבעים — תלוי: אם צל צריך להיחשב "אותו צבע", קוסינוס (תרגיל 2.9★).']},
 {'id': '2.7', 'ch': 2, 'level': 2, 'sec': '2.5',
  'q': ['מונה כניסות ויציאות, כמו במודול 5. קו וירטואלי עובר דרך הנקודה <span class="ltr">p0</span>, ו־<span class="ltr">u</span> הוא וקטור (לא בהכרח באורך 1) שניצב לקו ומצביע "פנימה". השלם את <code class="ltr">count_crossings(track, p0, u)</code>: ‏<span class="ltr">track</span> הוא מערך <span class="ltr">(T, 2)</span> של מיקומים לאורך זמן. מחזירה זוג <span class="ltr">(ins, outs)</span>: כמה פעמים המסלול עבר מהצד השלילי לחיובי, וכמה הפוך.',
        '**א.** למה מספיק לבדוק את <i>הסימן</i> של <span class="ltr">(p − p0) · u</span>, ולא צריך לנרמל את u?', '**ב.** מה יקרה עם רכב שעומד בדיוק על הקו ורועד בפיקסל אחד הלוך וחזור?'],
  'hints': ['<code class="ltr">side = (track - p0) @ u</code> — מספר לכל מיקום.', 'חציה פנימה: <span class="ltr">side[t] &lt; 0</span> ו־<span class="ltr">side[t+1] &gt; 0</span>.'],
  'sol': ['**א.** נרמול מכפיל את כל הערכים באותו מספר חיובי — הסימן לא משתנה. צריך לנרמל רק כשהגודל עצמו חשוב (כמה רחוק מהקו).', '**ב.** כל רעידה נספרת כחציה — עשרות "כניסות" ו"יציאות". הפתרון: היסטרזיס — לספור כניסה רק כשהמסלול עבר מ־<span class="ltr">side &lt; −m</span> ל־<span class="ltr">side &gt; +m</span>, עם מרווח של כמה פיקסלים.'],
  'test': T('השלם את count_crossings.',
            'import numpy as np\n\ndef count_crossings(track, p0, u):\n    return 0, 0     # TODO\n',
            "import numpy as np\ntrack = np.array([[0, -5], [1, -2], [2, 3], [3, 6], [4, 1], [5, -4], [6, -6]], float)\nr = count_crossings(track, np.array([0.0, 0.0]), np.array([0.0, 2.0]))\nassert tuple(r) == (1, 1), f'נכנס פעם אחת ויצא פעם אחת; קיבלתי {r}'\nr2 = count_crossings(track, np.array([0.0, 0.0]), np.array([0.0, -1.0]))\nassert tuple(r2) == (1, 1)\nr3 = count_crossings(np.array([[0, -1], [0, 1], [0, -1], [0, 1]], float), np.array([0.0, 0.0]), np.array([0.0, 1.0]))\nassert tuple(r3) == (2, 1), f'פנימה, החוצה, פנימה: (2, 1); קיבלתי {r3}'\nassert tuple(count_crossings(track, np.array([0.0, 10.0]), np.array([0.0, 1.0]))) == (0, 0), 'קו שהמסלול לא מגיע אליו'",
            'import numpy as np\n\ndef count_crossings(track, p0, u):\n    side = (track - p0) @ u\n    ins = int(((side[:-1] < 0) & (side[1:] > 0)).sum())\n    outs = int(((side[:-1] > 0) & (side[1:] < 0)).sum())\n    return ins, outs\n')},
 {'id': '2.8', 'ch': 2, 'level': 2, 'sec': '2.6',
  'q': ['המרה לאפור בשורה אחת. השלם את <code class="ltr">to_gray(img)</code>: תמונת BGR בצורה <span class="ltr">(H, W, 3)</span> מטיפוס <code class="ltr">uint8</code>; מחזירה <span class="ltr">(H, W)</span> מטיפוס <code class="ltr">uint8</code>, עם המשקלות של הסעיף ועיגול.',
        '**א.** הבדיקה משווה ל־<code class="ltr">cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)</code>. בכמה רמות לכל היותר אתה שונה ממנה, ולמה לא אפס?', '**ב.** מה יוצא אם מחליפים את סדר המשקלות (RGB)? על איזה צבע זה הכי בולט?'],
  'hints': ['<code class="ltr">img.astype(np.float32) @ np.array([0.114, 0.587, 0.299])</code>.', 'סיום: <code class="ltr">np.round(...).astype(np.uint8)</code>.'],
  'sol': ['**א.** לכל היותר 1. ‏OpenCV מחשבת במספרים שלמים עם משקלות מעוגלים (בערך <span class="ltr">0.114 · 2¹⁴</span> וכו׳), ולכן בחלק מהפיקסלים העיגול נופל לצד השני.', '**ב.** כחול ואדום מתחלפים: כחול טהור הופך ל־76 במקום 29, ואדום טהור ל־29 במקום 76. הכי בולט על אדום וכחול רוויים — הכדור הכתום יוצא כהה מדי.'],
  'test': T('השלם את to_gray.',
            'import numpy as np\n\ndef to_gray(img):\n    return img.mean(axis=2).astype(np.uint8)     # TODO: the weighted sum\n',
            "import numpy as np, cv2\nrng = np.random.default_rng(0)\nimg = rng.integers(0, 256, (40, 60, 3)).astype(np.uint8)\ng = to_gray(img)\nassert g.shape == (40, 60) and g.dtype == np.uint8, f'צורה (40, 60) וטיפוס uint8; קיבלתי {g.shape}, {g.dtype}'\nref = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)\nd = np.abs(g.astype(int) - ref).max()\nassert d <= 1, f'ההפרש הגדול מ־OpenCV הוא {d} רמות — האם המשקלות בסדר BGR?'\nassert to_gray(np.array([[[255, 0, 0]]], np.uint8))[0, 0] == 29, 'כחול טהור צריך לצאת 29'",
            'import numpy as np\n\ndef to_gray(img):\n    w = np.array([0.114, 0.587, 0.299])\n    return np.round(img.astype(np.float32) @ w).astype(np.uint8)\n')},
 {'id': '2.9', 'ch': 2, 'level': 3, 'sec': '2.4',
  'q': ['**אתגר — צבע שלא מתבלבל מצל.** בהדמיה של 2.3, סף על מרחק אוקלידי לא תפס את החצי של הכדור שבצל. השלם את <code class="ltr">color_mask(img, target, thr)</code>: מחזירה מסכה בוליאנית <span class="ltr">(H, W)</span> של הפיקסלים שדמיון הקוסינוס שלהם עם <span class="ltr">target</span> (וקטור BGR) גדול מ־<span class="ltr">thr</span>. בלי לולאה.',
        '**א.** בבדיקה, פיקסל בדיוק בחצי הבהירות של המטרה. מה המרחק האוקלידי שלו ממנה, ומה דמיון הקוסינוס?', '**ב.** איזה פיקסל יעבור את הסף בטעות, ולמה? (רמז: מה הכיוון של פיקסל כמעט שחור?)'],
  'hints': ['מכפלה סקלרית לכל פיקסל: <code class="ltr">img @ target</code> נותן <span class="ltr">(H, W)</span>.', 'אורך לכל פיקסל: <code class="ltr">np.linalg.norm(img, axis=2)</code>; הוסף <span class="ltr">1e-9</span> כדי לא לחלק באפס.'],
  'sol': ['**א.** למטרה <span class="ltr">(14, 136, 237)</span> וחצי שלה <span class="ltr">(7, 68, 118.5)</span>: מרחק אוקלידי כ־137 — לא הרבה פחות מהמרחק לדשא (כ־165), ולכן כל סף שתופס אותו תופס כמעט גם את הדשא; דמיון קוסינוס 1.0 בדיוק — אותו כיוון.', '**ב.** פיקסלים כהים מאוד: ב־<span class="ltr">(1, 2, 3)</span> הכיוון כמעט אקראי (רעש של רמה אחת משנה אותו הרבה), ובטעות הוא יכול להיות קרוב לכיוון של המטרה. מוסיפים תנאי שני: <code class="ltr">np.linalg.norm(img, axis=2) &gt; 40</code>. זה בדיוק הרעיון של HSV במודול 1: גוון (כיוון) ובהירות (אורך) בנפרד, ו־V מינימלי כדי שהגוון יהיה אמין.'],
  'test': T('השלם את color_mask.',
            'import numpy as np\n\ndef color_mask(img, target, thr):\n    d = np.linalg.norm(img.astype(np.float32) - target, axis=2)\n    return d < 60     # TODO: cosine similarity instead of distance\n',
            "import numpy as np\nt = np.array([14, 136, 237], float)\nimg = np.zeros((2, 3, 3), np.float32)\nimg[0, 0] = t; img[0, 1] = t / 2; img[0, 2] = [51, 124, 77]\nimg[1, 0] = [200, 10, 10]; img[1, 1] = t * 1.05; img[1, 2] = [20, 140, 230]\nm = color_mask(img, t, 0.99)\nassert m.shape == (2, 3), f'צורה (2, 3); קיבלתי {m.shape}'\nassert m[0, 1], 'הפיקסל בחצי הבהירות — אותו כיוון — חייב לעבור'\nassert not m[0, 2] and not m[1, 0], 'דשא וכחול לא אמורים לעבור'\nassert m[0, 0] and m[1, 1] and m[1, 2]",
            'import numpy as np\n\ndef color_mask(img, target, thr):\n    x = img.astype(np.float32)\n    cos = (x @ target) / (np.linalg.norm(x, axis=2) * np.linalg.norm(target) + 1e-9)\n    return cos > thr\n')},
]

META.update({
 '3.1': (1, '3.2', '**חישוב ביד.** **נתון:** מטריצה 2×2 ווקטור. **מה לעשות:** הכפל — בשורות ובעמודות. **איך תדע שהצלחת:** אותה תוצאה בשתי הדרכים, <span class="ltr">(−1, −1)</span>.'),
 '3.2': (1, '3.3', '**בלי נוסחה.** **נתון:** סיבוב ב־180 מעלות. **מה לעשות:** לאן נוחתים וקטורי הבסיס — וכתוב כעמודות. **איך תדע שהצלחת:** ‏<span class="ltr">−I</span>; בדוק בנוסחה.'),
 '3.3': (1, '3.4', '**כלל הצורות.** **נתון:** שלושה זוגות. **מה לעשות:** צורת התוצאה, או למה לא חוקי. **איך תדע שהצלחת:** הממדים הפנימיים שווים ונעלמים.'),
 '3.4': (2, '3.4', '**זה תרגיל קוד קצר.** **נתון:** סיבוב 90 ושיקוף. **מה לעשות:** להפעיל בשני הסדרים על <span class="ltr">(1, 0)</span>. **איך תדע שהצלחת:** ‏<span class="ltr">(0, 1)</span> מול <span class="ltr">(0, −1)</span> — ובהדמיה של 3.4 רואים את זה על תמונה.'),
 '3.5': (2, '3.7', '**חישוב ביד.** **נתון:** הגזירה H. **מה לעשות:** דטרמיננטה, ומה היא אומרת. **איך תדע שהצלחת:** 1 — השטח נשמר.'),
 '3.6': (3, '3.3', '**זה תרגיל שמריצים במחשב.** **נתון:** ריבוע וארבע טרנספורמציות. **מה לעשות:** לצייר לפני ואחרי. **איך תדע שהצלחת:** כל צורה מתאימה לתיאור — מקבילית בגזירה, היפוך בשיקוף.'),
})
X += [
 # ------------------------------------------------ chapter 3
 {'id': '3.7', 'ch': 3, 'level': 1, 'sec': '3.1',
  'q': ['**זו שאלת חיזוי.** כתוב מה כל שורה תדפיס, ואז הרץ.',
        {'code': 'import numpy as np\nA = np.arange(12).reshape(3, 4)\nprint(A.shape, A[1, 2], A[2])\nprint(A[:, 1])\nprint(A[1:3, 0:2])\nprint(A[1:3][0:2])'},
        '**א.** למה שתי השורות האחרונות שונות?'],
  'hints': ['‏<code class="ltr">A[1:3]</code> הוא כבר מערך של שתי שורות. מה זה <code class="ltr">[0:2]</code> עליו?'],
  'sol': ['‏<span class="ltr">(3, 4) 6 [8 9 10 11]</span>; ‏<span class="ltr">[1 5 9]</span>; ‏<span class="ltr">[[4 5] [8 9]]</span>; ‏<span class="ltr">[[4 5 6 7] [8 9 10 11]]</span>. **א.** ‏<code class="ltr">A[1:3, 0:2]</code> חותך שורות <b>ועמודות</b> בבת אחת. ‏<code class="ltr">A[1:3][0:2]</code> הוא שני חיתוכים של <b>שורות</b>: קודם שורות 1 ו־2, ואז "השורות 0 ו־1" של התוצאה — שוב אותן שתי שורות, עם כל העמודות. בלי שגיאה. לכן ב־NumPy תמיד פסיק, לא סוגריים כפולים.']},
 {'id': '3.8', 'ch': 3, 'level': 2, 'sec': '3.5',
  'q': ['השחלוף שבגרדיאנט של פרק 12. ‏<span class="ltr">X</span> בצורה <span class="ltr">(n, d)</span> — ‏n דוגמאות של d תכונות — ו־<span class="ltr">e</span> בצורה <span class="ltr">(n,)</span> — שגיאה לכל דוגמה. השלם את <code class="ltr">grad(X, e)</code> שמחזירה וקטור <span class="ltr">(d,)</span>: לכל תכונה j, הממוצע על הדוגמאות של <span class="ltr">X[i, j] · e[i]</span>. בשורה אחת, בלי לולאה.',
        '**א.** מה הצורות בדרך, ולמה צריך דווקא <code class="ltr">X.T</code>?', '**ב.** מה היה יוצא מ־<code class="ltr">X @ e</code>?'],
  'hints': ['‏<span class="ltr">(d, n) @ (n,) → (d,)</span>.'],
  'sol': ['**א.** ‏<code class="ltr">X.T @ e / n</code>: ‏<span class="ltr">(d, n) @ (n,) → (d,)</span>. השורה ה־j של <span class="ltr">Xᵀ</span> היא העמודה ה־j של X — כל הערכים של התכונה j — ומכפלה סקלרית שלה עם e היא בדיוק הסכום שמבוקש.', '**ב.** ‏<span class="ltr">(n, d) @ (n,)</span> — ‏d מול n — שגיאה. (אלא אם <span class="ltr">n = d</span>: אז יצא וקטור בצורה <span class="ltr">(n,)</span>, שגוי, בלי שגיאה.)'],
  'test': T('השלם את grad.',
            'import numpy as np\n\ndef grad(X, e):\n    return np.zeros(X.shape[1])     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nX = rng.normal(size=(50, 3)); e = rng.normal(size=50)\nref = np.array([np.mean([X[i, j] * e[i] for i in range(50)]) for j in range(3)])\ng = grad(X, e)\nassert np.shape(g) == (3,), f'צורה (3,) — אחד לכל תכונה; קיבלתי {np.shape(g)}'\nassert np.allclose(g, ref), f'ציפיתי ל־{np.round(ref, 4)}; קיבלתי {np.round(g, 4)}'",
            'import numpy as np\n\ndef grad(X, e):\n    return X.T @ e / len(e)\n')},
 {'id': '3.9', 'ch': 3, 'level': 2, 'sec': '3.8',
  'q': ['סיבוב או לא? השלם את <code class="ltr">is_rotation(R)</code>: מקבלת מטריצה ריבועית (2×2 או 3×3) ומחזירה <span class="ltr">True</span> אם היא סיבוב: <span class="ltr">RᵀR = I</span> (עד שגיאת עיגול) <b>וגם</b> <span class="ltr">det(R) = 1</span>.',
        '**א.** איזו מטריצה מקיימת את התנאי הראשון ולא את השני?', '**ב.** למה לא בודקים <code class="ltr">==</code> אלא <code class="ltr">np.allclose</code>?'],
  'hints': ['‏<code class="ltr">np.allclose(R.T @ R, np.eye(len(R)))</code>.', '‏<code class="ltr">np.isclose(np.linalg.det(R), 1)</code>.'],
  'sol': ['**א.** שיקוף: <span class="ltr">FᵀF = I</span> (העמודות באורך 1 ומאונכות), אבל <span class="ltr">det = −1</span>. אורתוגונלית — אבל מהפכת. מצלמה עם מטריצה כזו "רואה במראה".', '**ב.** ‏<span class="ltr">cos²θ + sin²θ</span> בנקודה צפה יוצא לפעמים <span class="ltr">0.9999999999999999</span>, ו־<code class="ltr">==</code> נכשל על סיבוב אמיתי.'],
  'test': T('השלם את is_rotation.',
            'import numpy as np\n\ndef is_rotation(R):\n    return np.allclose(R.T @ R, np.eye(len(R)))     # TODO: also the determinant\n',
            "import numpy as np\nt = np.deg2rad(37)\nR2 = np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])\nassert is_rotation(R2), 'סיבוב ב־37 מעלות הוא סיבוב'\nassert not is_rotation(np.array([[-1.0, 0], [0, 1]])), 'שיקוף: RᵀR = I, אבל det = −1 — לא סיבוב'\nassert not is_rotation(np.array([[2.0, 0], [0, 0.5]])), 'הגדלה — לא סיבוב'\nRz = np.array([[np.cos(t), -np.sin(t), 0], [np.sin(t), np.cos(t), 0], [0, 0, 1]])\nassert is_rotation(Rz) and not is_rotation(-Rz), 'ב־3×3: מינוס סיבוב הוא det = −1'",
            'import numpy as np\n\ndef is_rotation(R):\n    return np.allclose(R.T @ R, np.eye(len(R))) and np.isclose(np.linalg.det(R), 1.0)\n')},
 {'id': '3.10', 'ch': 3, 'level': 3, 'sec': '3.6',
  'q': ['**אתגר — לסובב תמונה בעצמך, במשיכה.** השלם את <code class="ltr">warp_pull(img, A)</code>: תמונה <span class="ltr">(H, W)</span> ומטריצה <span class="ltr">2 × 2</span>. לכל פיקסל ביעד, מחשבים את המיקום שלו ביחס למרכז, מפעילים <span class="ltr">A⁻¹</span>, ולוקחים את הפיקסל הקרוב ביותר במקור (עיגול). פיקסל שנופל מחוץ לתמונה — 0. בלי לולאה על פיקסלים. (השתמש בקואורדינטות של מערך: <span class="ltr">u = x − cx</span>, ‏<span class="ltr">v = y − cy</span>, בלי להפוך את y.)',
        '**א.** הבדיקה מסובבת ריבוע ב־90 מעלות ומשווה ל־<code class="ltr">np.rot90</code>. לאיזה כיוון — ולמה?', '**ב.** מה היה קורה אילו השתמשת ב־A במקום בהפוכה?'],
  'hints': ['רשת קואורדינטות: <code class="ltr">ys, xs = np.mgrid[0:H, 0:W]</code>; מרכז <span class="ltr">((W − 1) / 2, (H − 1) / 2)</span>.', 'כל הנקודות כמטריצה <span class="ltr">(2, N)</span>: <code class="ltr">P = np.stack([xs.ravel() - cx, ys.ravel() - cy])</code>, ואז <code class="ltr">np.linalg.inv(A) @ P</code>.'],
  'sol': ['**א.** במערך, y גדל למטה, ולכן מטריצת הסיבוב "החיובית" מסובבת <b>עם</b> כיוון השעון על המסך — ו־<code class="ltr">np.rot90</code> (נגד כיוון השעון) צריך <span class="ltr">k = −1</span>, או סיבוב במינוס 90. זה בדיוק ההבדל בין מתמטיקה (y למעלה) לתמונות (y למטה) מסעיף 3.3.', '**ב.** בסיבוב ב־90 התוצאה הייתה מסובבת לכיוון ההפוך (<span class="ltr">A⁻¹ = Aᵀ</span> הוא הסיבוב ההפוך). ובהגדלה — התמונה הייתה <i>מוקטנת</i> במקום מוגדלת. המשיכה שואלת "מאיפה באתי", ולכן משתמשת בהפוכה.'],
  'test': T('השלם את warp_pull.',
            'import numpy as np\n\ndef warp_pull(img, A):\n    return img.copy()     # TODO: inverse mapping, nearest neighbour\n',
            "import numpy as np\nimg = np.arange(49).reshape(7, 7)\nR90 = np.array([[0.0, -1.0], [1.0, 0.0]])\nr = warp_pull(img, R90)\nassert r.shape == (7, 7), f'צורה (7, 7); קיבלתי {r.shape}'\nassert np.array_equal(r, np.rot90(img, -1)), 'סיבוב ב־90 (במערך: עם כיוון השעון) צריך להיות זהה ל־np.rot90(img, -1)'\nassert np.array_equal(warp_pull(img, np.eye(2)), img), 'מטריצת היחידה לא משנה כלום'\nz = warp_pull(img, np.array([[0.5, 0.0], [0.0, 0.5]]))\nassert z[0, 0] == 0 and z[3, 3] == img[3, 3], 'הקטנה פי 2: הפינות מחוץ למקור — 0; המרכז נשאר'",
            'import numpy as np\n\ndef warp_pull(img, A):\n    H, W = img.shape\n    cy, cx = (H - 1) / 2, (W - 1) / 2\n    ys, xs = np.mgrid[0:H, 0:W]\n    P = np.stack([xs.ravel() - cx, ys.ravel() - cy])\n    S = np.linalg.inv(A) @ P\n    sx = np.round(S[0] + cx).astype(int); sy = np.round(S[1] + cy).astype(int)\n    ok = (sx >= 0) & (sx < W) & (sy >= 0) & (sy < H)\n    out = np.zeros(H * W, dtype=img.dtype)\n    out[ok] = img[sy[ok], sx[ok]]\n    return out.reshape(H, W)\n')},
]

META.update({
 '4.1': (1, '4.2', '**חישוב ביד.** **נתון:** הגדלה פי 2 ואז הזזה. **מה לעשות:** מטריצה 3×3 והפעלה על <span class="ltr">(1, 1)</span>. **איך תדע שהצלחת:** ‏<span class="ltr">(7, −1)</span>; ובסדר ההפוך יוצא אחרת.'),
 '4.2': (1, '4.4', '**בלי חישוב ארוך.** **נתון:** ארבע נקודות הומוגניות. **מה לעשות:** לחלק ברכיב האחרון. **איך תדע שהצלחת:** שלוש מהן <span class="ltr">(1, 2)</span>.'),
 '4.3': (2, '4.5', '**חישוב ביד.** **נתון:** ‏f, גובה ומרחק. **מה לעשות:** גובה בפיקסלים בשני מרחקים. **איך תדע שהצלחת:** ‏72 ו־36 — מרחק כפול, גובה חצי.'),
 '4.4': (3, '4.4', '**זו שאלת הבנה.** **נתון:** אפינית והומוגרפיה. **מה לעשות:** לספור דרגות חופש ומשוואות. **איך תדע שהצלחת:** שתי משוואות לכל התאמה; שש ושמונה נעלמים.'),
})
X += [
 # ------------------------------------------------ chapter 4
 {'id': '4.5', 'ch': 4, 'level': 1, 'sec': '4.1',
  'q': ['**זו שאלת הבנה.** האם יש מטריצה 2×2 שמעבירה את <span class="ltr">(1, 1)</span> ל־<span class="ltr">(4, 2)</span> וגם את <span class="ltr">(2, 2)</span> ל־<span class="ltr">(5, 3)</span>? ואם מוסיפים t — ‏<span class="ltr">A p + t</span>?'],
  'hints': ['‏<span class="ltr">(2, 2) = 2 · (1, 1)</span>. מה לינאריות אומרת על <span class="ltr">A(2, 2)</span>?'],
  'sol': ['לא: <span class="ltr">A(2, 2) = 2 · A(1, 1) = (8, 4) ≠ (5, 3)</span>. עם t — כן, למשל <span class="ltr">A = I</span> ו־<span class="ltr">t = (3, 1)</span>: ההבדל בין שתי הנקודות נשמר (<span class="ltr">(1, 1)</span> לפני ואחרי), וזו הזזה טהורה. מטריצה לבד לא יכולה, כי היא חייבת להשאיר את הראשית במקום.']},
 {'id': '4.6', 'ch': 4, 'level': 2, 'sec': '4.2',
  'q': ['השלם את <code class="ltr">rotate_about(c, deg)</code>: מחזירה מטריצה 3×3 שמסובבת ב־deg מעלות (נגד כיוון השעון, במוסכמה של המתמטיקה) סביב הנקודה c.',
        '**א.** הבדיקה משווה את שתי השורות העליונות ל־<code class="ltr">cv2.getRotationMatrix2D(c, -deg, 1)</code>. למה עם מינוס?', '**ב.** מה הדטרמיננטה של הבלוק 2×2 השמאלי העליון, ולמה?'],
  'hints': ['‏<span class="ltr">T(c) @ R @ T(−c)</span>, מימין לשמאל.'],
  'sol': ['**א.** OpenCV מגדירה זווית חיובית כנגד כיוון השעון <i>על המסך</i>, שבו y גדל למטה. במוסכמה של המתמטיקה (y למעלה), זה הכיוון ההפוך — ולכן הזווית שלנו היא מינוס הזווית שלה. אותה מטריצה בדיוק, שתי מוסכמות.', '**ב.** 1 — זה בלוק סיבוב. ההזזות לא משנות שטחים.'],
  'test': T('השלם את rotate_about.',
            'import numpy as np\n\ndef rotate_about(c, deg):\n    t = np.deg2rad(deg)\n    return np.array([[np.cos(t), -np.sin(t), 0], [np.sin(t), np.cos(t), 0], [0, 0, 1.0]])     # TODO: about c, not about (0, 0)\n',
            "import numpy as np, cv2\nM = rotate_about((320, 240), 30)\nassert M.shape == (3, 3), f'מטריצה 3×3; קיבלתי {M.shape}'\nassert np.allclose(M @ [320, 240, 1], [320, 240, 1]), f'המרכז חייב להישאר במקום; קיבלתי {np.round(M @ [320, 240, 1], 2)}'\nassert np.allclose(M[:2], cv2.getRotationMatrix2D((320, 240), -30, 1)), 'שתי השורות העליונות צריכות להיות זהות למטריצה של OpenCV עם -30'\nassert np.allclose(rotate_about((0, 0), 90) @ [1, 0, 1], [0, 1, 1])",
            'import numpy as np\n\ndef T(tx, ty):\n    return np.array([[1, 0, tx], [0, 1, ty], [0, 0, 1.0]])\n\ndef rotate_about(c, deg):\n    t = np.deg2rad(deg)\n    R = np.array([[np.cos(t), -np.sin(t), 0], [np.sin(t), np.cos(t), 0], [0, 0, 1.0]])\n    return T(*c) @ R @ T(-c[0], -c[1])\n')},
 {'id': '4.7', 'ch': 4, 'level': 2, 'sec': '4.3',
  'q': ['שלוש התאמות → טרנספורמציה אפינית. השלם את <code class="ltr">affine_from_3(src, dst)</code>: ‏src ו־dst מערכים <span class="ltr">(3, 2)</span>; מחזירה מטריצה <span class="ltr">2 × 3</span> ‏M כך ש־<span class="ltr">M @ (x, y, 1) = (u, v)</span> לכל התאמה. בנה מערכת של 6 משוואות ופתור עם <code class="ltr">np.linalg.solve</code>.',
        '**א.** מה השורות של מטריצת המערכת עבור התאמה אחת?', '**ב.** מה קורה אם שלוש נקודות המקור על קו אחד?'],
  'hints': ['לכל התאמה <span class="ltr">(x, y) → (u, v)</span>: השורה <span class="ltr">[x, y, 1, 0, 0, 0]</span> עם u, והשורה <span class="ltr">[0, 0, 0, x, y, 1]</span> עם v.', 'הנעלמים: <span class="ltr">a, b, c, d, e, f</span>, ואז <code class="ltr">reshape(2, 3)</code>.'],
  'sol': ['**א.** שתי שורות: <span class="ltr">[x, y, 1, 0, 0, 0] · h = u</span> ו־<span class="ltr">[0, 0, 0, x, y, 1] · h = v</span> — הראשונה בונה את השורה העליונה של M, השנייה את התחתונה.', '**ב.** מטריצת המערכת סינגולרית (שתי עמודות שלה תלויות), ו־<code class="ltr">solve</code> זורקת <code class="ltr">LinAlgError</code>. גאומטרית: שלוש נקודות על קו לא קובעות מה קורה מחוץ לקו.'],
  'test': T('השלם את affine_from_3.',
            'import numpy as np\n\ndef affine_from_3(src, dst):\n    return np.hstack([np.eye(2), np.zeros((2, 1))])     # TODO\n',
            "import numpy as np, cv2\nsrc = np.float32([[0, 0], [199, 0], [0, 129]]); dst = np.float32([[50, 40], [240, 60], [70, 180]])\nM = affine_from_3(src, dst)\nassert np.shape(M) == (2, 3), f'צורה (2, 3); קיבלתי {np.shape(M)}'\nassert np.allclose(M, cv2.getAffineTransform(src, dst), atol=1e-4), 'שונה מ־cv2.getAffineTransform'\nassert np.allclose(M @ [199, 129, 1], [260, 200], atol=1e-3), 'הפינה הרביעית צריכה לצאת (260, 200)'",
            'import numpy as np\n\ndef affine_from_3(src, dst):\n    A, b = [], []\n    for (x, y), (u, v) in zip(src, dst):\n        A.append([x, y, 1, 0, 0, 0]); b.append(u)\n        A.append([0, 0, 0, x, y, 1]); b.append(v)\n    return np.linalg.solve(np.array(A, float), np.array(b, float)).reshape(2, 3)\n')},
 {'id': '4.8', 'ch': 4, 'level': 2, 'sec': '4.4',
  'q': ['להפעיל הומוגרפיה על הרבה נקודות. השלם את <code class="ltr">apply_h(H, pts)</code>: ‏pts מערך <span class="ltr">(N, 2)</span>; מחזירה <span class="ltr">(N, 2)</span> — כל נקודה אחרי H, אחרי חלוקה ב־w. בלי לולאה.',
        '**א.** מה קורה לנקודה שבה <span class="ltr">w = 0</span>?', '**ב.** ‏OpenCV עושה את זה ב־<code class="ltr">cv2.perspectiveTransform</code>. מה צורת הקלט שהיא מצפה לו?'],
  'hints': ['הוסף עמודה של אחדים: <code class="ltr">np.hstack([pts, np.ones((len(pts), 1))])</code> — צורה <span class="ltr">(N, 3)</span>.', 'כל השורות בבת אחת: <code class="ltr">P @ H.T</code>; ואז חלוקה בעמודה האחרונה עם <code class="ltr">[:, 2:]</code>.'],
  'sol': ['**א.** נקודה "באינסוף" — הקו שהיא עליו מקביל באופן שהומוגרפיה שולחת לאופק. בפועל חלוקה באפס נותנת <code class="ltr">inf</code>; בקוד אמיתי בודקים <span class="ltr">|w|</span> קטן.', '**ב.** ‏<span class="ltr">(N, 1, 2)</span> מטיפוס <code class="ltr">float32</code> — "N נקודות של ערוץ אחד עם שני רכיבים". ‏<code class="ltr">cv2.perspectiveTransform(pts.reshape(-1, 1, 2).astype(np.float32), H)</code>.'],
  'test': T('השלם את apply_h.',
            'import numpy as np\n\ndef apply_h(H, pts):\n    return pts @ H[:2, :2].T + H[:2, 2]     # TODO: the last row and the division by w\n',
            "import numpy as np, cv2\nH = np.array([[0.9, 0.1, 5.0], [-0.05, 1.1, 2.0], [0.001, 0.002, 1.0]])\npts = np.array([[0, 0], [100, 50], [320, 240], [10, 400]], float)\nr = apply_h(H, pts)\nassert np.shape(r) == (4, 2), f'צורה (4, 2); קיבלתי {np.shape(r)}'\nref = cv2.perspectiveTransform(pts.reshape(-1, 1, 2), H).reshape(-1, 2)\nassert np.allclose(r, ref), f'ציפיתי ל־{np.round(ref, 2).tolist()}; קיבלתי {np.round(r, 2).tolist()} — חילקת ב־w?'",
            'import numpy as np\n\ndef apply_h(H, pts):\n    P = np.hstack([pts, np.ones((len(pts), 1))])\n    Q = P @ H.T\n    return Q[:, :2] / Q[:, 2:]\n')},
 {'id': '4.9', 'ch': 4, 'level': 3, 'sec': '4.4',
  'q': ['**אתגר — הומוגרפיה מארבע פינות, בעצמך.** השלם את <code class="ltr">homography_4(src, dst)</code>: ‏src ו־dst מערכים <span class="ltr">(4, 2)</span>; מחזירה H בצורה <span class="ltr">3 × 3</span> עם <span class="ltr">H[2, 2] = 1</span>. בנה מערכת של 8 משוואות ב־8 נעלמים.',
        '**א.** איך הופכים <span class="ltr">u = (h₁x + h₂y + h₃) / (h₇x + h₈y + 1)</span> למשוואה לינארית בנעלמים?', '**ב.** מה קורה כשיש יותר מארבע התאמות, וחלקן עם רעש?'],
  'hints': ['כופלים במכנה: <span class="ltr">h₁x + h₂y + h₃ − u·h₇x − u·h₈y = u</span>.', 'שורה ל־u: <span class="ltr">[x, y, 1, 0, 0, 0, −ux, −uy]</span>; שורה ל־v: <span class="ltr">[0, 0, 0, x, y, 1, −vx, −vy]</span>.'],
  'sol': ['**א.** כופלים את שני הצדדים במכנה ומעבירים אגפים: <span class="ltr">h₁x + h₂y + h₃ − u x h₇ − u y h₈ = u</span>. ‏u, x, y ידועים — המשוואה לינארית ב־h. ושוב ל־v. ארבע התאמות — שמונה משוואות.', '**ב.** עם יותר משמונה משוואות אין פתרון מדויק — פותרים בריבועים פחותים (פרק 5.2), כמו <code class="ltr">cv2.findHomography</code>. ואם חלק מההתאמות שגויות לגמרי (התאמות של תכונות בין תמונות), מוסיפים RANSAC: בוחרים שוב ושוב ארבע אקראיות, ושומרים את ה־H שהכי הרבה נקודות מסכימות איתו.'],
  'test': T('השלם את homography_4.',
            'import numpy as np\n\ndef homography_4(src, dst):\n    return np.eye(3)     # TODO\n',
            "import numpy as np, cv2\nsrc = np.float32([[70, 52], [250, 80], [236, 170], [88, 180]]); dst = np.float32([[0, 0], [199, 0], [199, 99], [0, 99]])\nH = homography_4(src, dst)\nassert np.shape(H) == (3, 3) and abs(H[2, 2] - 1) < 1e-9, f'מטריצה 3×3 עם H[2, 2] = 1'\nassert np.allclose(H, cv2.getPerspectiveTransform(src, dst), atol=1e-6), 'שונה מ־cv2.getPerspectiveTransform'\np = H @ [236, 170, 1]\nassert np.allclose(p[:2] / p[2], [199, 99], atol=1e-4), 'הפינה הימנית התחתונה צריכה להגיע ל־(199, 99)'",
            'import numpy as np\n\ndef homography_4(src, dst):\n    A, b = [], []\n    for (x, y), (u, v) in zip(src, dst):\n        A.append([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.append(u)\n        A.append([0, 0, 0, x, y, 1, -v * x, -v * y]); b.append(v)\n    h = np.linalg.solve(np.array(A, float), np.array(b, float))\n    return np.append(h, 1.0).reshape(3, 3)\n')},
]

META.update({
 '5.1': (1, '5.1', '**זה תרגיל קוד קצר.** **נתון:** שלוש משוואות. **מה לעשות:** מטריצה, וקטור, ‏<code class="ltr">solve</code>. **איך תדע שהצלחת:** ‏<span class="ltr">(5, 3, −2)</span> — והצבה בחזרה בשלוש המשוואות.'),
 '5.2': (2, '5.2', '**זה תרגיל קוד.** **נתון:** קו ידוע ורעש. **מה לעשות:** ליצור נתונים ולשחזר את הקו. **איך תדע שהצלחת:** שיפוע וחיתוך קרובים ל־3 ול־2 — לא שווים בדיוק, בגלל הרעש.'),
 '5.3': (2, '5.2', '**ניסוי, ממשיך את 5.2.** **נתון:** נקודה אחת חריגה מאוד. **מה לעשות:** להריץ שוב ולהשוות. **איך תדע שהצלחת:** הקו זז משמעותית — וההדמיה של 5.2 מראה את RANSAC מתקן.'),
 '5.4': (3, '5.4', '**זה תרגיל שמריצים במחשב.** **נתון:** תמונת אפור. **מה לעשות:** SVD ושחזור מ־5, 20 ו־50 ערכים. **איך תדע שהצלחת:** ‏5 — כתמים, 20 — מזוהה, 50 — כמעט כמו המקור; ההדמיה של 5.4 עושה את אותו דבר.'),
})
X += [
 # ------------------------------------------------ chapter 5
 {'id': '5.5', 'ch': 5, 'level': 1, 'sec': '5.1',
  'q': ['**בלי מחשב.** לכל מערכת — פתרון יחיד, אף פתרון, או אינסוף? (רמז: דטרמיננטה, ואז הצבה.)',
        {'table': [['המערכת', 'כמה פתרונות?'], ['<span class="ltr">x + y = 2</span>, ‏<span class="ltr">x − y = 0</span>', '?'], ['<span class="ltr">x + 2y = 3</span>, ‏<span class="ltr">2x + 4y = 6</span>', '?'], ['<span class="ltr">x + 2y = 3</span>, ‏<span class="ltr">2x + 4y = 7</span>', '?'], ['<span class="ltr">3x = 6</span>, ‏<span class="ltr">y = 1</span>', '?']]}],
  'hints': ['‏<span class="ltr">det = ad − bc</span>. אם הוא 0 — האם המשוואה השנייה היא כפולה של הראשונה, כולל הצד הימני?'],
  'sol': ['(1) ‏<span class="ltr">det = −2</span>: יחיד, <span class="ltr">(1, 1)</span>. (2) ‏<span class="ltr">det = 0</span>, והשנייה פי 2 מהראשונה בדיוק — אותו קו: אינסוף. (3) ‏<span class="ltr">det = 0</span>, אבל <span class="ltr">7 ≠ 2 · 3</span> — קווים מקבילים: אף פתרון. (4) ‏<span class="ltr">det = 3</span>: יחיד, <span class="ltr">(2, 1)</span>.']},
 {'id': '5.6', 'ch': 5, 'level': 1, 'sec': '5.3',
  'q': ['**חזה, ואז בדוק.** מה הערכים העצמיים, ומה כיווני הווקטורים העצמיים?',
        {'code': 'import numpy as np\nfor A in ([[3, 0], [0, -1]], [[1, 1], [0, 1]], [[2, 1], [1, 2]], [[0, -1], [1, 0]]):\n    vals, vecs = np.linalg.eig(np.array(A, float))\n    print(A, np.round(vals, 3), np.round(vecs, 3).tolist())'},
        '**א.** באיזו מהן אין וקטור עצמי ממשי, ולמה?', '**ב.** בשלישית: מה הקשר בין הוקטורים העצמיים, ולמה?'],
  'hints': ['אלכסונית — הערכים על האלכסון. ‏<span class="ltr">[[0, −1], [1, 0]]</span> — לאן נוחת <span class="ltr">(1, 0)</span>?'],
  'sol': ['(1) ‏3 ו־‏−1, על הצירים. (2) גזירה: ‏1 פעמיים, ורק כיוון אחד — האופקי. (3) ‏3 ו־1, בכיוונים <span class="ltr">(1, 1)/√2</span> ו־<span class="ltr">(1, −1)/√2</span>. (4) סיבוב ב־90: ‏<span class="ltr">±i</span> — מרוכבים. **א.** הרביעית: כל חץ מסתובב ב־90 מעלות, אף אחד לא נשאר על הקו שלו. **ב.** מאונכים — המטריצה סימטרית.']},
 {'id': '5.7', 'ch': 5, 'level': 2, 'sec': '5.2',
  'q': ['ריבועים פחותים בלי <code class="ltr">lstsq</code>. השלם את <code class="ltr">fit_line(x, y)</code>: מחזירה <span class="ltr">(a, c)</span> של הקו <span class="ltr">y = a x + c</span>, בעזרת המשוואות הנורמליות <span class="ltr">AᵀA p = Aᵀ y</span> ו־<code class="ltr">np.linalg.solve</code>.',
        '**א.** מה הצורות של <span class="ltr">A</span>, ‏<span class="ltr">AᵀA</span> ו־<span class="ltr">Aᵀy</span> ל־50 נקודות?', '**ב.** למה ספריות בכל זאת משתמשות ב־<code class="ltr">lstsq</code> (שמבוסס על SVD) ולא בשורה הזו?'],
  'hints': ['‏<code class="ltr">A = np.column_stack([x, np.ones_like(x)])</code>.', '‏<code class="ltr">np.linalg.solve(A.T @ A, A.T @ y)</code>.'],
  'sol': ['**א.** ‏<span class="ltr">(50, 2)</span>, ‏<span class="ltr">(2, 2)</span>, ‏<span class="ltr">(2,)</span> — מערכת קטנה, לא משנה כמה נקודות.', '**ב.** ‏<span class="ltr">AᵀA</span> "מרבע" את מספר המצב של A: אם A כמעט סינגולרית (נקודות כמעט על אותו x), ‏<span class="ltr">AᵀA</span> גרועה פי הרבה, והפתרון מאבד ספרות. ‏<code class="ltr">lstsq</code> עובדת על A ישירות.'],
  'test': T('השלם את fit_line.',
            'import numpy as np\n\ndef fit_line(x, y):\n    return 0.0, float(np.mean(y))     # TODO\n',
            "import numpy as np\nx = np.array([0, 1, 2, 3], float); y = np.array([10.1, 11.9, 14.2, 15.8])\na, c = fit_line(x, y)\nassert abs(a - 1.94) < 1e-9 and abs(c - 10.09) < 1e-9, f'הנתונים של הסעיף: (1.94, 10.09); קיבלתי ({a:.4f}, {c:.4f})'\nrng = np.random.default_rng(0); xx = np.linspace(0, 10, 50); yy = 3 * xx + 2 + rng.normal(0, 0.5, 50)\nA = np.column_stack([xx, np.ones_like(xx)])\nassert np.allclose(fit_line(xx, yy), np.linalg.lstsq(A, yy, rcond=None)[0]), 'שונה מ־lstsq'",
            'import numpy as np\n\ndef fit_line(x, y):\n    A = np.column_stack([x, np.ones_like(x)])\n    a, c = np.linalg.solve(A.T @ A, A.T @ y)\n    return a, c\n')},
 {'id': '5.8', 'ch': 5, 'level': 2, 'sec': '5.3',
  'q': ['הציר הראשי של ענן. השלם את <code class="ltr">main_axis(pts)</code>: ‏pts מערך <span class="ltr">(N, 2)</span>; מחזירה וקטור יחידה בכיוון שבו הענן מתפזר הכי הרבה — הווקטור העצמי של מטריצת השונות עם הערך העצמי הגדול.',
        '**א.** למה <code class="ltr">np.linalg.eigh</code> ולא <code class="ltr">eig</code>? ובאיזה סדר היא מחזירה?', '**ב.** הבדיקה מקבלת גם את הווקטור ההפוך. למה?'],
  'hints': ['‏<code class="ltr">C = np.cov(pts.T)</code> — ‏<span class="ltr">(2, 2)</span>.', '‏<code class="ltr">vals, vecs = np.linalg.eigh(C)</code> — מהקטן לגדול; העמודה האחרונה.'],
  'sol': ['**א.** ‏C סימטרית, ו־<code class="ltr">eigh</code> מנצלת את זה: ערכים ממשיים, וקטורים מאונכים, ו<b>סדר עולה</b> — הגדול אחרון, <code class="ltr">vecs[:, -1]</code>.', '**ב.** וקטור עצמי מוגדר עד סימן: אם v מקיים <span class="ltr">Cv = λv</span>, גם ‎−v. "ציר" אין לו כיוון.'],
  'test': T('השלם את main_axis.',
            'import numpy as np\n\ndef main_axis(pts):\n    return np.array([1.0, 0.0])     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(1)\nt = np.deg2rad(35); R = np.array([[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]])\npts = (rng.normal(size=(500, 2)) * [3, 0.6]) @ R.T + [5, -2]\nv = np.asarray(main_axis(pts), float)\nassert abs(np.linalg.norm(v) - 1) < 1e-6, 'וקטור יחידה'\nang = np.degrees(np.arctan2(v[1], v[0])) % 180\nassert abs(ang - 35) < 3, f'הציר צריך להיות בכ־35 מעלות; קיבלתי {ang:.1f}'",
            'import numpy as np\n\ndef main_axis(pts):\n    vals, vecs = np.linalg.eigh(np.cov(pts.T))\n    return vecs[:, -1]\n')},
 {'id': '5.9', 'ch': 5, 'level': 3, 'sec': '5.2',
  'q': ['**אתגר — RANSAC לקו.** השלם את <code class="ltr">ransac_line(x, y, iters, thr, rng)</code>: בכל איטרציה בוחרים שתי נקודות שונות אקראיות (<code class="ltr">rng.choice(n, 2, replace=False)</code>), בונים מהן קו, וסופרים כמה נקודות במרחק אנכי קטן מ־thr ממנו. שומרים את הקו עם הכי הרבה נקודות כאלה, ובסוף מחזירים <span class="ltr">(a, c)</span> של ריבועים פחותים <b>רק</b> על הנקודות שהסכימו איתו.',
        '**א.** בבדיקה, 30% מהנקודות חריגות. מה נותן <code class="ltr">lstsq</code> רגיל, ומה RANSAC?', '**ב.** כמה איטרציות צריך? (רמז: מה הסיכוי ששתי נקודות אקראיות יהיו "טובות"?)'],
  'hints': ['זוג עם אותו x — דלג (שיפוע אינסופי).', 'מסכה: <code class="ltr">np.abs(y - (a * x + c)) &lt; thr</code>; בסוף — <code class="ltr">np.polyfit(x[best], y[best], 1)</code> או lstsq.'],
  'sol': ['**א.** בבדיקה (זרע 0): ‏<code class="ltr">lstsq</code> נותן <span class="ltr">(2.06, 11.19)</span> במקום <span class="ltr">(3, 2)</span> — 18 חריגים משכו את הקו. RANSAC: <span class="ltr">(3.02, 1.94)</span>, עם 43 נקודות שהסכימו — כמו בלי חריגים.', '**ב.** אם 70% מהנקודות טובות, הסיכוי ששתיים אקראיות טובות הוא <span class="ltr">0.7² = 0.49</span>. אחרי N איטרציות, הסיכוי שאף זוג לא היה טוב: <span class="ltr">0.51ᴺ</span> — ב־10 איטרציות 0.1%. להומוגרפיה (4 נקודות) ועם 50% טובות: <span class="ltr">0.5⁴ = 0.0625</span>, וצריך כ־100 איטרציות לאותה ודאות. לכן ל־RANSAC יש פרמטר של מספר איטרציות.'],
  'test': T('השלם את ransac_line.',
            'import numpy as np\n\ndef ransac_line(x, y, iters, thr, rng):\n    A = np.column_stack([x, np.ones_like(x)])\n    return tuple(np.linalg.lstsq(A, y, rcond=None)[0])     # TODO: RANSAC\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nx = np.linspace(0, 10, 60); y = 3 * x + 2 + rng.normal(0, 0.3, 60)\nbad = rng.choice(60, 18, replace=False); y[bad] = rng.uniform(-10, 40, 18) + 15 * (x[bad] < 5)\nA = np.column_stack([x, np.ones_like(x)]); ls = np.linalg.lstsq(A, y, rcond=None)[0]\na, c = ransac_line(x, y, 200, 1.0, np.random.default_rng(1))\nassert abs(a - 3) < 0.1 and abs(c - 2) < 0.5, f'ציפיתי לכ־(3, 2); קיבלתי ({a:.3f}, {c:.3f}) — lstsq רגיל נותן ({ls[0]:.3f}, {ls[1]:.3f})'",
            'import numpy as np\n\ndef ransac_line(x, y, iters, thr, rng):\n    best = None\n    for _ in range(iters):\n        i, j = rng.choice(len(x), 2, replace=False)\n        if x[i] == x[j]:\n            continue\n        a = (y[j] - y[i]) / (x[j] - x[i]); c = y[i] - a * x[i]\n        ok = np.abs(y - (a * x + c)) < thr\n        if best is None or ok.sum() > best.sum():\n            best = ok\n    A = np.column_stack([x[best], np.ones(best.sum())])\n    return tuple(np.linalg.lstsq(A, y[best], rcond=None)[0])\n')},
]

META.update({
 '6.1': (1, '6.2', '**ביד, בלי מחשב.** **נתון:** שלוש פונקציות. **מה לעשות:** לגזור לפי הכללים. **איך תדע שהצלחת:** ‏<span class="ltr">12x² − 2</span>, ‏<span class="ltr">eˣ + 1/x</span>, ‏<span class="ltr">2x − 6</span>; ההדמיה של 6.2 בודקת מספרית.'),
 '6.2': (1, '6.3', '**ביד.** **נתון:** ‏<span class="ltr">(x − 3)²</span>. **מה לעשות:** איפה הנגזרת אפס, מה סוג הנקודה, ולאן זזים מ־5. **איך תדע שהצלחת:** ‏3, מינימום, שמאלה.'),
 '6.3': (2, '6.4', '**ביד.** **נתון:** פונקציה של שני משתנים. **מה לעשות:** שתי נגזרות חלקיות, ואז להציב. **איך תדע שהצלחת:** ‏<span class="ltr">(4, 9)</span> — ותרגיל 6.4 בודק.'),
 '6.4': (2, '6.1', '**זה תרגיל קוד קצר.** **נתון:** הנגזרת המספרית של 6.1. **מה לעשות:** להפעיל אותה על כל משתנה בנפרד. **איך תדע שהצלחת:** כמעט <span class="ltr">(4, 9)</span>; תרגיל 6.8 עושה את זה באופן כללי.'),
 '6.5': (3, '6.5', '**זה תרגיל שמריצים במחשב.** **נתון:** תמונת אפור. **מה לעשות:** הפרשים בשני הכיוונים, חיתוך לאותה צורה, ואורך. **איך תדע שהצלחת:** הקצוות כקווים בהירים — כמו בלשונית "אורך" בהדמיה של 6.5.'),
})
X += [
 # ------------------------------------------------ chapter 6
 {'id': '6.6', 'ch': 6, 'level': 1, 'sec': '6.1',
  'q': ['**חזה, ואז הרץ.** הנגזרת של <span class="ltr">sin x</span> ב־<span class="ltr">x = 1</span> היא <span class="ltr">cos 1 ≈ 0.5403023</span>. באיזה h כל שיטה הכי מדויקת?',
        {'code': 'import numpy as np\nf, x, true = np.sin, 1.0, np.cos(1.0)\nfor h in (1e-1, 1e-3, 1e-5, 1e-8, 1e-12):\n    fwd = (f(x + h) - f(x)) / h\n    cen = (f(x + h) - f(x - h)) / (2 * h)\n    print(f"h={h:.0e}  forward err={abs(fwd - true):.1e}  central err={abs(cen - true):.1e}")'},
        '**א.** בכמה קטנה השגיאה של כל שיטה כש־h קטן פי 100 (מ־<span class="ltr">1e−1</span> ל־<span class="ltr">1e−3</span>)?', '**ב.** למה ב־<span class="ltr">1e−12</span> השגיאה גדלה?'],
  'hints': ['חד־צדדי: שגיאה ∝ h. מרכזי: ∝ h².'],
  'sol': ['**א.** חד־צדדי — פי 100 בערך (שגיאה ∝ h); מרכזי — פי 10,000 (∝ h²). החד־צדדי הכי מדויק סביב <span class="ltr">1e−8</span>, המרכזי סביב <span class="ltr">1e−5</span>.', '**ב.** ‏<span class="ltr">sin(1 + 1e−12)</span> ו־<span class="ltr">sin(1)</span> שונים רק בספרה ה־13 בערך, ו־<code class="ltr">float64</code> מחזיק כ־16 ספרות: אחרי החיסור נשארות שלוש ספרות משמעותיות, והחלוקה ב־h הקטן מגדילה את השגיאה. שגיאת העיגול גדלה כ־<span class="ltr">1/h</span>.']},
 {'id': '6.7', 'ch': 6, 'level': 2, 'sec': '6.3',
  'q': ['הכלל של 6.3 בלולאה. השלם את <code class="ltr">descend(df, x0, lr, steps)</code>: מתחיל ב־x0 ומבצע steps צעדים של <span class="ltr">x ← x − lr · df(x)</span>. מחזירה את הרשימה של כל ה־x (כולל ההתחלה).',
        '**א.** ב־<span class="ltr">(x − 3)²</span> מ־5 עם <span class="ltr">lr = 0.1</span>: באיזה יחס המרחק מ־3 קטן בכל צעד?', '**ב.** מה קורה עם <span class="ltr">lr = 1.1</span>? הסבר מהנוסחה.'],
  'hints': ['‏<span class="ltr">x − 3</span> אחרי צעד: <span class="ltr">(x − 3) − lr · 2(x − 3) = (1 − 2·lr)(x − 3)</span>.'],
  'sol': ['**א.** פי <span class="ltr">1 − 2 · 0.1 = 0.8</span> בכל צעד: ‏2, ‏1.6, ‏1.28, … — מתקרב בקצב קבוע (גאומטרי).', '**ב.** ‏<span class="ltr">1 − 2.2 = −1.2</span>: המרחק מוכפל ב־1.2 ומחליף סימן — הכדור קופץ מצד לצד, כל פעם רחוק יותר. מתבדר. זה "קצב למידה גדול מדי" של פרק 8.4.'],
  'test': T('השלם את descend.',
            'def descend(df, x0, lr, steps):\n    return [x0]     # TODO\n',
            "xs = descend(lambda x: 2 * (x - 3), 5.0, 0.1, 30)\nassert len(xs) == 31, f'31 ערכים: ההתחלה ועוד 30 צעדים; קיבלתי {len(xs)}'\nassert abs(xs[1] - 4.6) < 1e-12 and abs(xs[2] - 4.28) < 1e-12, f'5 → 4.6 → 4.28; קיבלתי {xs[:3]}'\nassert abs(xs[-1] - 3) < 0.01, f'אחרי 30 צעדים צריך להיות ליד 3; קיבלתי {xs[-1]}'\nbig = descend(lambda x: 2 * (x - 3), 5.0, 1.1, 10)\nassert abs(big[-1] - 3) > abs(big[0] - 3), 'עם lr = 1.1 המרחק מ־3 צריך לגדול'",
            'def descend(df, x0, lr, steps):\n    xs = [x0]\n    for _ in range(steps):\n        xs.append(xs[-1] - lr * df(xs[-1]))\n    return xs\n')},
 {'id': '6.8', 'ch': 6, 'level': 2, 'sec': '6.4',
  'q': ['גרדיאנט מספרי לכל פונקציה. השלם את <code class="ltr">numeric_grad(f, p, h=1e-5)</code>: ‏p וקטור NumPy באורך n; מחזירה וקטור באורך n שבו הרכיב ה־i הוא הנגזרת החלקית לפי <span class="ltr">p[i]</span>, בהפרש מרכזי.',
        '**א.** כמה פעמים קוראים ל־f? מה זה אומר על רשת עם מיליון משקלות?', '**ב.** למה צריך <code class="ltr">p.astype(float)</code> או <code class="ltr">.copy()</code> לפני ששינית רכיב?'],
  'hints': ['לכל i: וקטור <span class="ltr">e</span> של אפסים עם h במקום i; ‏<span class="ltr">(f(p + e) − f(p − e)) / 2h</span>.'],
  'sol': ['**א.** ‏<span class="ltr">2n</span> קריאות. ברשת של מיליון משקלות — שני מיליון מעברים קדימה לגרדיאנט אחד. לכן גרדיאנט מספרי משמש רק לבדיקה, על רשת קטנה; האימון משתמש בהפצה לאחור (פרק 7), שעולה בערך כמו מעבר קדימה אחד.', '**ב.** אם משנים את p במקום (<code class="ltr">p[i] += h</code>) — משנים את המערך של הקורא, ואם p של מספרים שלמים, ‏<span class="ltr">1e−5</span> בכלל לא נכנס (מתעגל לאפס). ‏<span class="ltr">p + e</span> יוצר מערך חדש, ו־e מטיפוס float.'],
  'test': T('השלם את numeric_grad.',
            'import numpy as np\n\ndef numeric_grad(f, p, h=1e-5):\n    return np.zeros(len(p))     # TODO\n',
            "import numpy as np\nf = lambda p: p[0] ** 2 * p[1] + 5 * p[1]\ng = numeric_grad(f, np.array([2.0, 1.0]))\nassert np.allclose(g, [4, 9], atol=1e-6), f'תרגיל 6.3: (4, 9); קיבלתי {np.round(g, 6)}'\nf2 = lambda p: p[0] ** 2 + 3 * p[0] * p[1] + p[1] ** 2\nassert np.allclose(numeric_grad(f2, np.array([1.0, 2.0])), [8, 7], atol=1e-6), 'הדוגמה של 6.4: (8, 7)'\nf3 = lambda p: np.sum(np.arange(1, 6) * p ** 2)\nassert np.allclose(numeric_grad(f3, np.ones(5)), 2 * np.arange(1, 6), atol=1e-5), 'חמישה משתנים'",
            'import numpy as np\n\ndef numeric_grad(f, p, h=1e-5):\n    p = np.asarray(p, float)\n    g = np.zeros(len(p))\n    for i in range(len(p)):\n        e = np.zeros(len(p)); e[i] = h\n        g[i] = (f(p + e) - f(p - e)) / (2 * h)\n    return g\n')},
 {'id': '6.9', 'ch': 6, 'level': 2, 'sec': '6.5',
  'q': ['תרגיל 6.5★ כפונקציה. השלם את <code class="ltr">edge_magnitude(gray)</code>: מקבלת תמונת אפור <span class="ltr">(H, W)</span> (אולי <code class="ltr">uint8</code>), ומחזירה <span class="ltr">(H−1, W−1)</span> מטיפוס float: <span class="ltr">√(gx² + gy²)</span>, כש־gx ההפרש לשכן מימין ו־gy לשכן מתחת — שניהם חתוכים לאותה צורה.',
        '**א.** למה צריך להמיר ל־float לפני החיסור?', '**ב.** בתמונה של ריבוע בהיר על רקע כהה — איפה האורך הכי גדול, ולמה דווקא שם?'],
  'hints': ['‏<code class="ltr">g = gray.astype(float)</code>; ‏<code class="ltr">gx = g[:-1, 1:] - g[:-1, :-1]</code>.', '‏<code class="ltr">gy = g[1:, :-1] - g[:-1, :-1]</code>.'],
  'sol': ['**א.** ב־<code class="ltr">uint8</code>, ‏<span class="ltr">10 − 200</span> גולש ל־66 (פרק 1.4): קצה מבהיר לכהה נראה קטן במקום גדול, או להפך.', '**ב.** בפינה הימנית־התחתונה, <span class="ltr">(5, 5)</span>: שם גם gx וגם gy לא אפס, והאורך <span class="ltr">√2 · 200 ≈ 282.8</span>. על הצלעות — רק אחד מהם, 200. ובשלוש הפינות האחרות? ההפרש החד־צדדי (לשכן מימין ומתחת) "מפספס" את אחד הכיוונים — הפינות לא סימטריות. עוד סיבה ש־Sobel משתמש בהפרש מרכזי.'],
  'test': T('השלם את edge_magnitude.',
            'import numpy as np\n\ndef edge_magnitude(gray):\n    gx = gray[:, 1:] - gray[:, :-1]\n    return np.abs(gx)     # TODO: gy, float, same shape\n',
            "import numpy as np\nimg = np.zeros((8, 8), np.uint8); img[2:6, 2:6] = 200\nm = edge_magnitude(img)\nassert m.shape == (7, 7), f'צורה (7, 7); קיבלתי {m.shape}'\nassert abs(m[5, 5] - 200 * 2 ** 0.5) < 1e-6, f'בפינה (5, 5): שני ההפרשים 200 — האורך 282.8; קיבלתי {m[5, 5]}'\nassert m[5, 3] == 200, f'הצלע התחתונה: מבהיר לכהה, 200 (לא 56 — המרת ל־float?); קיבלתי {m[5, 3]}'\nassert m[3, 3] == 0 and m[0, 6] == 0",
            'import numpy as np\n\ndef edge_magnitude(gray):\n    g = gray.astype(float)\n    gx = g[:-1, 1:] - g[:-1, :-1]\n    gy = g[1:, :-1] - g[:-1, :-1]\n    return np.sqrt(gx ** 2 + gy ** 2)\n')},
 {'id': '6.10', 'ch': 6, 'level': 3, 'sec': '6.4',
  'q': ['**אתגר — למה דווקא הגרדיאנט.** השיפוע של f בנקודה p בכיוון וקטור יחידה u הוא <span class="ltr">(f(p + h·u) − f(p − h·u)) / 2h</span>. השלם את <code class="ltr">steepest(f, p, n=360)</code>: בודקת n כיוונים במעגל, ומחזירה את וקטור היחידה עם השיפוע הגדול ביותר — <b>בלי</b> לחשב גרדיאנט.',
        '**א.** הבדיקה משווה את התוצאה לגרדיאנט המנורמל. למה הם צריכים לצאת זהים?', '**ב.** מה השיפוע בכיוון הזה, ומה הקשר לאורך הגרדיאנט?'],
  'hints': ['כיוונים: <span class="ltr">u = (cos t, sin t)</span> ל־<code class="ltr">t in np.linspace(0, 2π, n, endpoint=False)</code>.'],
  'sol': ['**א.** השיפוע בכיוון u שווה <span class="ltr">∇f · u = |∇f| cos θ</span> (הטלה, פרק 2.5). הוא מקסימלי כש־<span class="ltr">θ = 0</span> — u באותו כיוון כמו הגרדיאנט. החיפוש על 360 כיוונים מוצא את זה בלי שום נוסחה.', '**ב.** השיפוע המקסימלי הוא בדיוק <span class="ltr">|∇f|</span> — האורך של הגרדיאנט. ובכיוון ההפוך — <span class="ltr">−|∇f|</span>, הירידה התלולה. ובכיוון ניצב — אפס: קו הגובה.'],
  'test': T('השלם את steepest.',
            'import numpy as np\n\ndef steepest(f, p, n=360):\n    return np.array([1.0, 0.0])     # TODO: search the circle\n',
            "import numpy as np\nf = lambda q: q[0] ** 2 + 3 * q[0] * q[1] + q[1] ** 2\nu = steepest(f, np.array([1.0, 2.0]))\ng = np.array([8.0, 7.0]); g /= np.linalg.norm(g)\nassert abs(np.linalg.norm(u) - 1) < 1e-9, 'וקטור יחידה'\nassert np.dot(u, g) > 0.9998, f'צריך להצביע כמו הגרדיאנט (8, 7)/|..| = {np.round(g, 3)}; קיבלתי {np.round(u, 3)}'\nf2 = lambda q: np.exp(-(q[0] - 1) ** 2 - (q[1] + 1) ** 2)\nu2 = steepest(f2, np.array([0.0, 0.0]))\nassert np.dot(u2, np.array([1, -1]) / 2 ** 0.5) > 0.9998, 'בגבעה שבמרכז (1, −1): הכיוון אל הפסגה'",
            'import numpy as np\n\ndef steepest(f, p, n=360, h=1e-5):\n    best, best_u = -np.inf, None\n    for t in np.linspace(0, 2 * np.pi, n, endpoint=False):\n        u = np.array([np.cos(t), np.sin(t)])\n        s = (f(p + h * u) - f(p - h * u)) / (2 * h)\n        if s > best:\n            best, best_u = s, u\n    return best_u\n')},
]

META.update({
 '7.1': (1, '7.1', '**ביד.** **נתון:** שתי פונקציות מורכבות. **מה לעשות:** לזהות חוליה פנימית וחיצונית, ולהכפיל. **איך תדע שהצלחת:** ‏<span class="ltr">2e^(2x)</span> ו־<span class="ltr">6x(x² + 1)²</span>.'),
 '7.2': (1, '7.3', '**ביד.** **נתון:** הניורון של 7.3 עם מספרים אחרים. **מה לעשות:** מעבר קדימה ואחורה. **איך תדע שהצלחת:** ‏<span class="ltr">L = 9</span>, שתי נגזרות <span class="ltr">−6</span>; ההדמיה של 7.3 מריצה את אותו דבר.'),
 '7.3': (2, '7.4', '**ביד.** **נתון:** ניורון עם סיגמואיד. **מה לעשות:** שרשרת של שלוש נגזרות, ואז מספרים. **איך תדע שהצלחת:** ‏<span class="ltr">−0.25</span> — ותרגיל 7.4 בודק.'),
 '7.4': (2, '7.3', '**זה תרגיל קוד קצר.** **נתון:** התשובה של 7.3. **מה לעשות:** נגזרת מספרית לפי w. **איך תדע שהצלחת:** כמעט <span class="ltr">−0.25</span>.'),
 '7.5': (3, '7.5', '**חישוב קצר.** **נתון:** שלוש חזקות. **מה לעשות:** לחשב ולפרש. **איך תדע שהצלחת:** מיליונית, ‏1.63 ו־131 — נעלם ומתפוצץ; ההדמיה של 7.5 מראה את זה לשכבה.'),
})
X += [
 # ------------------------------------------------ chapter 7
 {'id': '7.6', 'ch': 7, 'level': 1, 'sec': '7.2',
  'q': ['**ציור על הנייר.** צייר גרף חישוב ל־<span class="ltr">L = (σ(w₂ · relu(w₁ · x)) − y)²</span> — ניורון של שתי שכבות. כמה צמתי פעולה יש, ומה הנגזרת המקומית של כל אחד?'],
  'hints': ['מבפנים החוצה: כפל, ReLU, כפל, סיגמואיד, חיסור, ריבוע.'],
  'sol': ['שישה צמתי פעולה: <span class="ltr">u = w₁x</span> (מקומי: x לפי w₁), ‏<span class="ltr">h = relu(u)</span> (1 אם <span class="ltr">u &gt; 0</span>, אחרת 0), ‏<span class="ltr">v = w₂h</span> (h לפי w₂, ‏w₂ לפי h), ‏<span class="ltr">a = σ(v)</span> (‏<span class="ltr">a(1 − a)</span>), ‏<span class="ltr">e = a − y</span> (1), ‏<span class="ltr">L = e²</span> (‏2e). ‏<span class="ltr">∂L/∂w₁ = 2e · a(1 − a) · w₂ · [u &gt; 0] · x</span> — חמש חוליות. ואם <span class="ltr">u &lt; 0</span>, הגרדיאנט ל־w₁ הוא אפס — "ניורון מת" (7.4).']},
 {'id': '7.7', 'ch': 7, 'level': 2, 'sec': '7.3',
  'q': ['המעבר לאחור של 7.3 כפונקציה, עם הסיגמואיד של תרגיל 7.3. השלם את <code class="ltr">grads(x, y, w, b)</code>: ‏<span class="ltr">a = σ(wx + b)</span>, ‏<span class="ltr">L = (a − y)²</span>; מחזירה <span class="ltr">(L, dL_dw, dL_db)</span> מהשרשרת — לא מנגזרת מספרית.',
        '**א.** כמה פעמים מחושבת הנגזרת <span class="ltr">∂L/∂z</span>, וכמה פעמים משתמשים בה?', '**ב.** ב־<span class="ltr">w = 10, x = 1, y = 0</span> — הניורון "בטוח" ש־1 וטועה לגמרי. מה הגרדיאנט, ומה זה אומר?'],
  'hints': ['‏<span class="ltr">dL_da = 2(a − y)</span>, ‏<span class="ltr">dL_dz = dL_da · a(1 − a)</span>.'],
  'sol': ['**א.** פעם אחת — ומשמשת את w (כפול x) ואת b (כפול 1). זה היתרון של מעבר לאחור.', '**ב.** ‏<span class="ltr">a ≈ 0.99995</span>, ו־<span class="ltr">a(1 − a) ≈ 4.5 · 10⁻⁵</span>: הגרדיאנט זעיר (כ־<span class="ltr">9 · 10⁻⁵</span>) דווקא כשהטעות הכי גדולה. סיגמואיד רוויה — עם הפסד ריבועי הניורון כמעט לא לומד מהטעות הכי חמורה. בפרק 10.5 ו־12 — אנטרופיה צולבת מבטלת את הגורם הזה.'],
  'test': T('השלם את grads.',
            'import numpy as np\n\ndef grads(x, y, w, b):\n    return 0.0, 0.0, 0.0     # TODO\n',
            "import numpy as np\nL, gw, gb = grads(1, 1, 0, 0)\nassert abs(L - 0.25) < 1e-12 and abs(gw + 0.25) < 1e-12 and abs(gb + 0.25) < 1e-12, f'תרגיל 7.3: (0.25, −0.25, −0.25); קיבלתי ({L}, {gw}, {gb})'\nf = lambda w, b: (1 / (1 + np.exp(-(w * 2.0 + b))) - 0.3) ** 2\nL, gw, gb = grads(2.0, 0.3, 0.7, -0.4)\nh = 1e-6\nassert abs(gw - (f(0.7 + h, -0.4) - f(0.7 - h, -0.4)) / (2 * h)) < 1e-6, 'dL/dw לא מתאים לנגזרת המספרית'\nassert abs(gb - (f(0.7, -0.4 + h) - f(0.7, -0.4 - h)) / (2 * h)) < 1e-6, 'dL/db לא מתאים לנגזרת המספרית'",
            'import numpy as np\n\ndef grads(x, y, w, b):\n    z = w * x + b\n    a = 1 / (1 + np.exp(-z))\n    L = (a - y) ** 2\n    dL_dz = 2 * (a - y) * a * (1 - a)\n    return L, dL_dz * x, dL_dz\n')},
 {'id': '7.8', 'ch': 7, 'level': 2, 'sec': '7.4',
  'q': ['שתי שכבות לינאריות הן שכבה אחת. בקוד: ‏<span class="ltr">W₁</span> בצורה <span class="ltr">(4, 3)</span>, ‏<span class="ltr">W₂</span> בצורה <span class="ltr">(2, 4)</span>, הטיות <span class="ltr">b₁, b₂</span>. השלם את <code class="ltr">collapse(W1, b1, W2, b2)</code> שמחזירה <span class="ltr">(W, b)</span> כך ש־<span class="ltr">W x + b = W₂(W₁x + b₁) + b₂</span> לכל x.',
        '**א.** מה הצורה של W?', '**ב.** למה אין <span class="ltr">(W, b)</span> כזה כשיש ReLU באמצע?'],
  'hints': ['פתח סוגריים: <span class="ltr">W₂W₁x + W₂b₁ + b₂</span>.'],
  'sol': ['**א.** ‏<span class="ltr">(2, 3)</span> — ‏<span class="ltr">(2, 4) @ (4, 3)</span>.', '**ב.** ‏ReLU משנה את ההתנהגות לפי הסימן של כל רכיב: באזור אחד של המרחב רכיב "כבוי" ובאחר "דלוק". הפונקציה היא לינארית בכל אזור, אבל עם מטריצה אחרת בכל אחד — כמו המישור המקופל בהדמיה של 7.4. אין מטריצה אחת לכולם.'],
  'test': T('השלם את collapse.',
            'import numpy as np\n\ndef collapse(W1, b1, W2, b2):\n    return W2, b2     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0)\nW1, b1, W2, b2 = rng.normal(size=(4, 3)), rng.normal(size=4), rng.normal(size=(2, 4)), rng.normal(size=2)\nW, b = collapse(W1, b1, W2, b2)\nassert np.shape(W) == (2, 3), f'צורה (2, 3); קיבלתי {np.shape(W)}'\nfor _ in range(5):\n    x = rng.normal(size=3)\n    assert np.allclose(W @ x + b, W2 @ (W1 @ x + b1) + b2), 'שתי השכבות והשכבה האחת צריכות לתת אותה תוצאה'",
            'import numpy as np\n\ndef collapse(W1, b1, W2, b2):\n    return W2 @ W1, W2 @ b1 + b2\n')},
 {'id': '7.9', 'ch': 7, 'level': 2, 'sec': '7.5',
  'q': ['**ניסוי מספרי.** שרשרת של 30 שכבות, שבכל אחת הגורם לגרדיאנט הוא נגזרת האקטיבציה כפול משקל. הרץ והסבר.',
        {'code': 'import numpy as np\nrng = np.random.default_rng(0)\nz = rng.normal(size=30)\nsig = 1 / (1 + np.exp(-z))\nfor name, d in [("sigmoid", sig * (1 - sig)), ("relu", (z > 0) * 1.0)]:\n    for w in (1.0, 2.0, 4.0):\n        plain = np.prod(d * w)\n        resid = np.prod(1 + 0.1 * d * w)\n        print(f"{name:8s} w={w}:  plain {plain:.1e}   residual {resid:.2f}")'},
        '**א.** למה ReLU נותן בדיוק 0 במקרה הרגיל?', '**ב.** למה גם עם חיבורי דילוג המכפלה גדלה כש־w גדל, ומה זה אומר?'],
  'hints': ['‏ReLU: גורם 0 אחד בשרשרת מאפס את כל המכפלה.'],
  'sol': ['**א.** בכ־חצי מהשכבות <span class="ltr">z &lt; 0</span>, והנגזרת של ReLU שם 0 — גורם אחד של אפס מאפס את המכפלה כולה (ברשת אמיתית יש הרבה ניורונים בכל שכבה, והגרדיאנט עובר דרך הדלוקים; כאן — ניורון אחד לשכבה). והסיגמואיד: ‏<span class="ltr">≈10⁻²⁰</span> ב־<span class="ltr">w = 1</span>, ועולה רק עם משקלות גדולים.', '**ב.** ‏<span class="ltr">(1 + ε)³⁰</span> עם ε חיובי עדיין גדל (<span class="ltr">e^(30ε)</span>). חיבורי דילוג פותרים את ההיעלמות, אבל לא פוטרים מאתחול סביר ומנרמול — לכן ב־ResNet יש גם נרמול אצווה.']},
 {'id': '7.10', 'ch': 7, 'level': 3, 'sec': '7.6',
  'q': ['**אתגר — מנוע גזירה אוטומטית בעצמך.** השלם את המחלקה <code class="ltr">Value</code>: מחזיקה מספר (<code class="ltr">data</code>), גרדיאנט (<code class="ltr">grad = 0</code>), ואת ההורים והקצבים המקומיים. תמוך ב־<code class="ltr">+</code>, ‏<code class="ltr">*</code> ו־<code class="ltr">**</code> (עם מעריך מספרי), ובמתודה <code class="ltr">backward()</code> שמסדרת את הצמתים בסדר טופולוגי ועוברת עליהם מהסוף, ומוסיפה <span class="ltr">grad · local</span> לכל הורה.',
        '**א.** למה צריך סדר טופולוגי, ולא סתם רקורסיה מ־L לכל הורה?', '**ב.** למה <code class="ltr">+=</code> ולא <code class="ltr">=</code>?'],
  'hints': ['‏<code class="ltr">__add__(self, o)</code>: ‏<code class="ltr">Value(self.data + o.data, (self, o), (1, 1))</code>. עטוף מספרים רגילים ב־Value.', 'סדר טופולוגי: חיפוש לעומק שמוסיף צומת לרשימה <i>אחרי</i> כל ההורים שלו; ואז <code class="ltr">reversed</code>.'],
  'sol': ['**א.** צומת שיש לו כמה ילדים (משתמשים בו פעמיים) צריך לקבל את <b>כל</b> התרומות לפני שהוא מעביר הלאה. סדר טופולוגי הפוך מבטיח שכל הילדים טופלו לפניו; רקורסיה פשוטה הייתה מעבירה הלאה גרדיאנט חלקי — ופעמיים.', '**ב.** משתנה שמופיע בכמה מסלולים מקבל תרומה מכל אחד, והן מתחברות (כלל השרשרת הרב־משתני). זה גם למה PyTorch מצבר ב־<code class="ltr">.grad</code> וצריך <code class="ltr">zero_grad()</code>.'],
  'test': T('השלם את Value.',
            'class Value:\n    def __init__(self, data, parents=(), local=()):\n        self.data, self.grad, self.parents, self.local = data, 0.0, parents, local\n    def backward(self):\n        pass     # TODO: + , * , ** and backward\n',
            "w, b = Value(0.5), Value(1.0)\nL = (w * 2.0 + b + (-3.0)) ** 2\nL.backward()\nassert abs(L.data - 1.0) < 1e-12, f'L = 1; קיבלתי {L.data}'\nassert abs(w.grad + 4) < 1e-12 and abs(b.grad + 2) < 1e-12, f'w.grad = −4, b.grad = −2; קיבלתי {w.grad}, {b.grad}'\nw2 = Value(3.0)\nM = w2 * w2 + w2 * 2.0\nM.backward()\nassert abs(w2.grad - 8.0) < 1e-12, f'w·w + 2w: הנגזרת 2w + 2 = 8 — שני מסלולים מתחברים; קיבלתי {w2.grad}'",
            'class Value:\n    def __init__(self, data, parents=(), local=()):\n        self.data, self.grad, self.parents, self.local = data, 0.0, parents, local\n    def __add__(self, o):\n        o = o if isinstance(o, Value) else Value(o)\n        return Value(self.data + o.data, (self, o), (1.0, 1.0))\n    def __mul__(self, o):\n        o = o if isinstance(o, Value) else Value(o)\n        return Value(self.data * o.data, (self, o), (o.data, self.data))\n    def __pow__(self, p):\n        return Value(self.data ** p, (self,), (p * self.data ** (p - 1),))\n    def backward(self):\n        order, seen = [], set()\n        def visit(n):\n            if id(n) in seen:\n                return\n            seen.add(id(n))\n            for p in n.parents:\n                visit(p)\n            order.append(n)\n        visit(self)\n        self.grad = 1.0\n        for n in reversed(order):\n            for p, l in zip(n.parents, n.local):\n                p.grad += n.grad * l\n')},
]

META.update({
 '8.1': (1, '8.3', '**ביד.** **נתון:** הטבלה של 8.3. **מה לעשות:** עוד שני צעדים. **איך תדע שהצלחת:** ‏2.017 ו־2.214 — והמרחק מ־3 קטן פי 0.8 בכל צעד.'),
 '8.2': (2, '8.4', '**זה תרגיל שמריצים במחשב.** **נתון:** חמישה קצבים. **מה לעשות:** מסלולים על גרף אחד. **איך תדע שהצלחת:** זחילה, צעד אחד, נדנוד מתכנס, נדנוד נצחי והתבדרות — כמו בהדמיה של 8.4. (הגורם המדויק: <span class="ltr">1 − 2η</span>.)'),
 '8.3': (2, '8.2', '**זה תרגיל קוד.** **נתון:** פונקציה של שני משתנים. **מה לעשות:** גרדיאנט כווקטור ולולאת עדכון. **איך תדע שהצלחת:** מגיעים ל־<span class="ltr">(1, −2)</span>.'),
 '8.4': (3, '8.6', '**ניסוי והסבר.** **נתון:** אותה פונקציה. **מה לעשות:** הקצב הגדול ביותר שעוד מתכנס, ולמה. **איך תדע שהצלחת:** ‏0.25, בגלל הכיוון y (גורם <span class="ltr">1 − 8η</span>); ההדמיה של 8.6 מראה מה תנע ואדם עושים עם זה.'),
})
X += [
 # ------------------------------------------------ chapter 8
 {'id': '8.5', 'ch': 8, 'level': 1, 'sec': '8.5',
  'q': ['**חישוב קצר.** מאגר של 50,000 תמונות, מקבצים של 64, ‏30 תקופות.',
        '**א.** כמה איטרציות בתקופה? וכמה בסך הכול?', '**ב.** אם כל איטרציה לוקחת 0.12 שניות, כמה זמן האימון?', '**ג.** מכפילים את המקבץ ל־128, והאיטרציה לוקחת 0.2 שניות. מה הזמן עכשיו, וכמה צעדי עדכון פחות?'],
  'hints': ['‏<span class="ltr">⌈50,000 / 64⌉</span>.'],
  'sol': ['**א.** ‏<span class="ltr">⌈50,000 / 64⌉ = 782</span> בתקופה; ‏<span class="ltr">782 · 30 = 23,460</span> בסך הכול.', '**ב.** ‏<span class="ltr">23,460 · 0.12 ≈ 2,815</span> שניות — כ־47 דקות.', '**ג.** ‏<span class="ltr">391 · 30 = 11,730</span> איטרציות × 0.2 = כ־39 דקות — מהר יותר, כי הכרטיס מנצל את המקבץ הגדול; אבל חצי מצעדי העדכון. בדרך כלל מגדילים גם את הקצב כשמגדילים את המקבץ.']},
 {'id': '8.6', 'ch': 8, 'level': 1, 'sec': '8.7',
  'q': ['**זו שאלת אבחון.** לכל תיאור — מה הסיבה הסבירה, ומה הצעד הראשון?',
        {'table': [['מה רואים', 'אבחנה?'], ['ההפסד יורד בעשר האיטרציות הראשונות, ואז קופץ ל־nan', '?'], ['ההפסד יורד מ־2.30 ל־2.29 אחרי 5 תקופות', '?'], ['ההפסד יורד מהר בהתחלה, ואז שטוח לגמרי — על נתונים עם עמודת "מחיר" בשקלים ועמודת "חדרים"', '?'], ['ההפסד יורד יפה, אבל רק המשקלות של השכבה האחרונה משתנים (רשת סיגמואיד של 30 שכבות)', '?']]}],
  'hints': ['8.7 — ארבעה דברים שבאמת משתבשים.'],
  'sol': ['(1) קצב גדול מדי (או לוגריתם של אפס, פרק 10) — מקטינים פי 10, ובודקים את ההפסד. (2) קצב קטן מדי, או גרדיאנט נעלם — מגדילים פי 10 ובודקים גודל גרדיאנט. (3) תכונות בסקאלות שונות — נרמול (פרק 9.4), לא קצב אחר. (4) גרדיאנט נעלם — ReLU, אתחול נכון, חיבורי דילוג (פרק 7.5).']},
 {'id': '8.7', 'ch': 8, 'level': 2, 'sec': '8.5',
  'q': ['מקבצים לתקופה אחת. השלם את <code class="ltr">minibatches(n, B, rng)</code>: מחזירה רשימה של מערכי אינדקסים — ערבוב אקראי של <span class="ltr">0..n−1</span>, מחולק לחתיכות של B (האחרונה יכולה להיות קטנה יותר).',
        '**א.** למה מערבבים מחדש בכל תקופה, ולא פעם אחת?', '**ב.** מה עושים עם המקבץ האחרון הקטן?'],
  'hints': ['‏<code class="ltr">idx = rng.permutation(n)</code>; ואז <code class="ltr">[idx[i:i + B] for i in range(0, n, B)]</code>.'],
  'sol': ['**א.** אם הסדר קבוע, אותן דוגמאות תמיד באותו מקבץ, באותו סדר — והרעש של הגרדיאנט "מתואם" בין תקופות. ערבוב מחדש נותן לכל תקופה מקבצים אחרים.', '**ב.** אפשר להשאיר (ממוצע על פחות דוגמאות — רועש יותר), או לזרוק (<code class="ltr">drop_last=True</code> ב־PyTorch) — מקובל כשהוא קטן מאוד, ובמיוחד עם נרמול אצווה, שלא אוהב מקבץ של 1–2.'],
  'test': T('השלם את minibatches.',
            'import numpy as np\n\ndef minibatches(n, B, rng):\n    return [np.arange(n)]     # TODO\n',
            "import numpy as np\nb = minibatches(10, 4, np.random.default_rng(0))\nassert [len(x) for x in b] == [4, 4, 2], f'10 בחתיכות של 4: אורכים 4, 4, 2; קיבלתי {[len(x) for x in b]}'\nassert sorted(np.concatenate(b).tolist()) == list(range(10)), 'כל אינדקס בדיוק פעם אחת'\nassert np.concatenate(b).tolist() != list(range(10)), 'הסדר צריך להיות מעורבב'\nb1 = minibatches(100, 32, np.random.default_rng(1)); b2 = minibatches(100, 32, np.random.default_rng(1))\nassert all(np.array_equal(x, y) for x, y in zip(b1, b2)), 'אותו rng — אותו ערבוב'",
            'import numpy as np\n\ndef minibatches(n, B, rng):\n    idx = rng.permutation(n)\n    return [idx[i:i + B] for i in range(0, n, B)]\n')},
 {'id': '8.8', 'ch': 8, 'level': 2, 'sec': '8.6',
  'q': ['תנע בעמק צר. ‏<span class="ltr">L = 0.5(x − 1)² + 25(y + 2)²</span>, מ־<span class="ltr">(−2, 0)</span>. השלם את <code class="ltr">steps_to_converge(lr, beta, max_steps=2000)</code>: מריצה <span class="ltr">v ← β v + g</span>, ‏<span class="ltr">w ← w − lr · v</span> (עם <span class="ltr">β = 0</span> זו ירידה רגילה), ומחזירה את מספר הצעדים עד ש־<span class="ltr">L &lt; 0.01</span> (או <span class="ltr">None</span>).',
        '**א.** בבדיקה: <span class="ltr">β = 0, lr = 0.035</span> מול <span class="ltr">β = 0.9, lr = 0.012</span>. מה יצא?', '**ב.** למה עם תנע לוקחים קצב קטן יותר?'],
  'hints': ['הגרדיאנט: <span class="ltr">(x − 1, 50(y + 2))</span>.'],
  'sol': ['**א.** בבדיקה: ירידה רגילה — 86 צעדים; תנע — 61. ותנע ממשיך לעבוד גם בקצבים שבהם הרגילה מתבדרת.', '**ב.** בכיוון עקבי, <span class="ltr">v</span> מצטבר עד פי <span class="ltr">1/(1 − β)</span> — פי 10. הצעד האפקטיבי גדול פי 10, ולכן מקטינים את הקצב (כאן פי 3) — ועדיין מתקדמים לאורך העמק מהר יותר.'],
  'test': T('השלם את steps_to_converge.',
            'import numpy as np\n\ndef steps_to_converge(lr, beta, max_steps=2000):\n    return None     # TODO\n',
            "a = steps_to_converge(0.035, 0.0); b = steps_to_converge(0.012, 0.9)\nassert a == 86, f'ירידה רגילה ב־0.035: 86 צעדים; קיבלתי {a}'\nassert b is not None and b < a, f'תנע צריך להגיע מהר יותר; קיבלתי {b}'\nassert steps_to_converge(0.045, 0.0) is None, 'ב־0.045 ירידה רגילה מתבדרת — None'",
            'import numpy as np\n\ndef steps_to_converge(lr, beta, max_steps=2000):\n    w = np.array([-2.0, 0.0]); v = np.zeros(2)\n    L = lambda p: 0.5 * (p[0] - 1) ** 2 + 25 * (p[1] + 2) ** 2\n    for t in range(1, max_steps + 1):\n        g = np.array([w[0] - 1, 50 * (w[1] + 2)])\n        v = beta * v + g\n        w = w - lr * v\n        if not np.all(np.isfinite(w)) or np.abs(w).max() > 1e6:\n            return None\n        if L(w) < 0.01:\n            return t\n    return None\n')},
 {'id': '8.9', 'ch': 8, 'level': 3, 'sec': '8.6',
  'q': ['**אתגר — אדם בעצמך.** השלם את <code class="ltr">adam(grad, w0, lr, steps, b1=0.9, b2=0.999, eps=1e-8)</code>: ‏<span class="ltr">m ← b1·m + (1 − b1)·g</span>, ‏<span class="ltr">s ← b2·s + (1 − b2)·g²</span>, תיקון הטיה <span class="ltr">m̂ = m / (1 − b1ᵗ)</span>, ‏<span class="ltr">ŝ = s / (1 − b2ᵗ)</span>, ו־<span class="ltr">w ← w − lr · m̂ / (√ŝ + eps)</span>. מחזירה את w הסופי.',
        '**א.** בבדיקה, על העמק של 8.8, עם שלושה קצבים שונים פי 10. מה קורה לירידה רגילה באותם קצבים?', '**ב.** מה גודל הצעד של אדם בכל כיוון בצעד הראשון, ולמה?', '**ג.** למה צריך את תיקון ההטיה?'],
  'hints': ['‏t מתחיל ב־1. ‏<code class="ltr">np.sqrt</code> על וקטור — לכל רכיב בנפרד.'],
  'sol': ['**א.** אדם מתכנס בשלושתם; ירידה רגילה מתבדרת כבר ב־0.05 (צריך <span class="ltr">lr &lt; 0.04</span>). אדם לא רגיש לסקאלה של הגרדיאנט — הוא מחלק בה.', '**ב.** בצעד הראשון <span class="ltr">m̂ = g</span> ו־<span class="ltr">√ŝ = |g|</span>, ולכן הצעד הוא <span class="ltr">lr · sign(g)</span> — אותו גודל בכל כיוון, בלי קשר לתלילות. זה "הקצב הנפרד לכל משקל".', '**ג.** m ו־s מתחילים באפס, ולכן בצעדים הראשונים הם קטנים מדי (פי <span class="ltr">1 − b1ᵗ</span>). החלוקה מתקנת — בלעדיה, בצעדים הראשונים ŝ זעיר והצעד ענק.'],
  'test': T('השלם את adam.',
            'import numpy as np\n\ndef adam(grad, w0, lr, steps, b1=0.9, b2=0.999, eps=1e-8):\n    w = np.array(w0, float)\n    for t in range(1, steps + 1):\n        w = w - lr * grad(w)     # TODO: this is plain gradient descent\n    return w\n',
            "import numpy as np\ng = lambda w: np.array([w[0] - 1, 50 * (w[1] + 2)])\nL = lambda w: 0.5 * (w[0] - 1) ** 2 + 25 * (w[1] + 2) ** 2\nfor lr in (0.05, 0.2, 0.5):\n    w = adam(g, [-2.0, 0.0], lr, 400)\n    assert np.all(np.isfinite(w)) and L(w) < 0.01, f'אדם עם lr = {lr} צריך להתכנס; L = {L(w)}'\nw1 = adam(g, [-2.0, 0.0], 0.1, 1)\nassert np.allclose(w1, [-1.9, -0.1], atol=1e-6), f'הצעד הראשון: lr·sign(g) בכל כיוון → (−1.9, −0.1); קיבלתי {np.round(w1, 4)}'",
            'import numpy as np\n\ndef adam(grad, w0, lr, steps, b1=0.9, b2=0.999, eps=1e-8):\n    w = np.array(w0, float); m = np.zeros_like(w); s = np.zeros_like(w)\n    for t in range(1, steps + 1):\n        g = grad(w)\n        m = b1 * m + (1 - b1) * g\n        s = b2 * s + (1 - b2) * g * g\n        mh = m / (1 - b1 ** t); sh = s / (1 - b2 ** t)\n        w = w - lr * mh / (np.sqrt(sh) + eps)\n    return w\n')},
]

META.update({
 '9.1': (1, '9.2', '**ביד.** **נתון:** שמונה מספרים. **מה לעשות:** ממוצע, שונות וסטיית תקן. **איך תדע שהצלחת:** 5, 4, 2 — ו־<code class="ltr">np.std</code> מאשר.'),
 '9.2': (1, '9.3', '**חישוב קצר.** **נתון:** ממוצע וסטיית תקן. **מה לעשות:** להפוך גובה לציון z ולהשתמש בכלל 68–95. **איך תדע שהצלחת:** כ־2.5% (המדויק 2.28%).'),
 '9.3': (2, '9.3', '**זה תרגיל שמריצים במחשב.** **נתון:** מספרים אחידים. **מה לעשות:** שתי היסטוגרמות. **איך תדע שהצלחת:** שטוחה, ופעמון סביב 6 עם סטיית תקן 1 — כמו בלשונית "למה פעמון" של 9.3.'),
 '9.4': (1, '9.6', '**חישוב קצר.** **נתון:** ספירות של מזהה. **מה לעשות:** דיוק ורגישות. **איך תדע שהצלחת:** 50% ו־75%.'),
 '9.5': (3, '9.5', '**זה תרגיל שמריצים במחשב.** **נתון:** הענן של 9.5. **מה לעשות:** פיזור ווקטורים עצמיים מעליו. **איך תדע שהצלחת:** החצים לאורך האלכסונים, ‏<span class="ltr">λ ≈ 7</span> ו־<span class="ltr">λ ≈ 1</span>.'),
})
X += [
 # ------------------------------------------------ chapter 9
 {'id': '9.6', 'ch': 9, 'level': 2, 'sec': '9.1',
  'q': ['התפלגות של סכום שתי קוביות. השלם את <code class="ltr">two_dice()</code>: מחזירה מערך באורך 13, שבו במקום s ההסתברות שסכום שתי קוביות הוגנות הוא s (במקומות 0 ו־1 — אפס). בלי הגרלה — ספור את 36 הצירופים.',
        '**א.** מה הסיכוי ל־7? ול"לפחות 10"?', '**ב.** הגרל 100,000 זוגות ובדוק שהשכיחויות קרובות.'],
  'hints': ['שתי לולאות על 1..6, ו־<code class="ltr">p[a + b] += 1 / 36</code>.'],
  'sol': ['**א.** ‏<span class="ltr">6/36 ≈ 0.167</span>; לפחות 10: <span class="ltr">(3 + 2 + 1)/36 = 1/6</span>.', '**ב.** <code class="ltr">s = np.random.randint(1, 7, (100_000, 2)).sum(1); np.bincount(s, minlength=13) / len(s)</code> — כל ערך בטווח של כ־0.003 מהמדויק.'],
  'test': T('השלם את two_dice.',
            'import numpy as np\n\ndef two_dice():\n    return np.zeros(13)     # TODO\n',
            "import numpy as np\np = two_dice()\nassert len(p) == 13, 'מערך באורך 13'\nassert abs(p.sum() - 1) < 1e-9, f'הסכום צריך להיות 1; קיבלתי {p.sum()}'\nassert p[0] == 0 and p[1] == 0, 'סכום 0 או 1 בלתי אפשרי'\nassert abs(p[7] - 6 / 36) < 1e-9, f'P(7) = 6/36; קיבלתי {p[7]}'\nassert abs(p[2] - 1 / 36) < 1e-9 and abs(p[12] - 1 / 36) < 1e-9, 'P(2) = P(12) = 1/36'\nassert abs(p[10:].sum() - 1 / 6) < 1e-9, 'לפחות 10: 1/6'",
            'import numpy as np\n\ndef two_dice():\n    p = np.zeros(13)\n    for a in range(1, 7):\n        for b in range(1, 7):\n            p[a + b] += 1 / 36\n    return p\n')},
 {'id': '9.7', 'ch': 9, 'level': 2, 'sec': '9.4',
  'q': ['נרמול נכון — עם הסטטיסטיקה של האימון. השלם את <code class="ltr">fit_normalizer(train)</code>: מקבלת אצווה בצורה <span class="ltr">(N, H, W, 3)</span>, ומחזירה פונקציה <code class="ltr">norm(imgs)</code> שמנרמלת כל אצווה (או תמונה בודדת <span class="ltr">(H, W, 3)</span>) עם הממוצע וסטיית התקן <b>לכל ערוץ</b> של האימון.',
        '**א.** למה לא לחשב ממוצע מחדש בכל קריאה?', '**ב.** מה צורת <code class="ltr">mean</code>, ולמה שידור עובד גם לאצווה וגם לתמונה בודדת?'],
  'hints': ['‏<code class="ltr">train.mean(axis=(0, 1, 2))</code>; פונקציה פנימית שמשתמשת במשתנים של החיצונית (סגור).'],
  'sol': ['**א.** אז כל תמונה בשטח מנורמלת לפי עצמה: תמונה כהה ובהירה נראות זהות לרשת, והמספרים שונים ממה שהיא ראתה באימון.', '**ב.** ‏<span class="ltr">(3,)</span>. השידור מיישר מימין: <span class="ltr">(…, 3)</span> מול <span class="ltr">(3,)</span> — לכל מספר ממדים משמאל.'],
  'test': T('השלם את fit_normalizer.',
            'import numpy as np\n\ndef fit_normalizer(train):\n    def norm(imgs):\n        return (imgs - imgs.mean()) / imgs.std()     # TODO: wrong statistics\n    return norm\n',
            "import numpy as np\nrng = np.random.default_rng(0)\ntrain = rng.random((20, 8, 8, 3)) * np.array([50, 100, 200]) + np.array([10, 20, 30])\nnorm = fit_normalizer(train)\nz = norm(train)\nassert np.allclose(z.mean(axis=(0, 1, 2)), 0, atol=1e-9) and np.allclose(z.std(axis=(0, 1, 2)), 1, atol=1e-9), 'על נתוני האימון: ממוצע 0 וסטיית תקן 1 לכל ערוץ'\none = np.full((8, 8, 3), 60.0)\nexp = (60 - train.mean(axis=(0, 1, 2))) / train.std(axis=(0, 1, 2))\nassert norm(one).shape == (8, 8, 3) and np.allclose(norm(one)[0, 0], exp), f'תמונה בודדת מנורמלת בסטטיסטיקה של האימון: ציפיתי {np.round(exp, 3)}, קיבלתי {np.round(norm(one)[0, 0], 3)}'",
            'import numpy as np\n\ndef fit_normalizer(train):\n    mean = train.mean(axis=(0, 1, 2))\n    std = train.std(axis=(0, 1, 2))\n    def norm(imgs):\n        return (imgs - mean) / std\n    return norm\n')},
 {'id': '9.8', 'ch': 9, 'level': 2, 'sec': '9.5',
  'q': ['שער מעקב בשני ממדים. השלם את <code class="ltr">in_gate(pred, meas, S, k=3)</code>: מחזירה <span class="ltr">True</span> אם מרחק מהלנוביס <span class="ltr">√(dᵀ S⁻¹ d)</span> בין המדידה לצפי קטן או שווה ל־k.',
        '**א.** עם <span class="ltr">S = [[4, 3], [3, 4]]</span> וצפי <span class="ltr">(0, 0)</span>: בדוק את <span class="ltr">(3, 3)</span> ואת <span class="ltr">(3, −3)</span>. מה המרחק הרגיל של שתיהן? ומה מרחק מהלנוביס?', '**ב.** מה קורה כש־S היא <span class="ltr">σ² I</span>?'],
  'hints': ['‏<code class="ltr">d = meas - pred</code>; ‏<code class="ltr">d @ np.linalg.inv(S) @ d</code>. (עדיף <code class="ltr">np.linalg.solve(S, d)</code>.)'],
  'sol': ['**א.** שתיהן <span class="ltr">√18 ≈ 4.24</span> פיקסלים. ‏<span class="ltr">(3, 3)</span> לאורך הציר הארוך (שונות 7): <span class="ltr">√(18/7) ≈ 1.60</span> — בשער. ‏<span class="ltr">(3, −3)</span> לאורך הקצר (שונות 1): <span class="ltr">√18 ≈ 4.24</span> — מחוץ.', '**ב.** ‏<span class="ltr">S⁻¹ = I / σ²</span>, והמרחק הוא <span class="ltr">|d| / σ</span> — בדיוק ציון z של 9.3, בשני ממדים.'],
  'test': T('השלם את in_gate.',
            'import numpy as np\n\ndef in_gate(pred, meas, S, k=3):\n    return np.linalg.norm(np.subtract(meas, pred)) <= k     # TODO: plain distance\n',
            "import numpy as np\nS = np.array([[4.0, 3.0], [3.0, 4.0]])\nassert in_gate([0, 0], [3, 3], S), '(3, 3) לאורך הציר הארוך: מרחק מהלנוביס 1.6 — בשער'\nassert not in_gate([0, 0], [3, -3], S), '(3, −3) לאורך הציר הקצר: 4.24 — מחוץ לשער'\nassert in_gate([10, 10], [12, 9], 4 * np.eye(2), k=1.2) and not in_gate([10, 10], [12, 9], 4 * np.eye(2), k=1.1), 'עם S = 4I, המרחק הוא |d|/2 = 1.118'",
            'import numpy as np\n\ndef in_gate(pred, meas, S, k=3):\n    d = np.subtract(meas, pred).astype(float)\n    m = np.sqrt(d @ np.linalg.solve(S, d))\n    return m <= k\n')},
 {'id': '9.9', 'ch': 9, 'level': 3, 'sec': '9.6',
  'q': ['**אתגר — עקומת דיוק־רגישות.** נתונים <code class="ltr">scores</code> (ציוני ביטחון של זיהויים), <code class="ltr">is_tp</code> (האם כל זיהוי פגע במטרה אמיתית) ו־<code class="ltr">n_true</code> (מספר המטרות). השלם את <code class="ltr">pr_curve(scores, is_tp, n_true)</code>: ממיינת לפי ציון יורד ומחזירה שני מערכים — דיוק ורגישות אחרי כל זיהוי ברשימה. ואת <code class="ltr">threshold_for_recall(scores, is_tp, n_true, r)</code>: הסף הגבוה ביותר שנותן רגישות לפחות r (או <span class="ltr">None</span>).',
        '**א.** למה מספיק למיין פעם אחת, ולא לנסות כל סף בנפרד?', '**ב.** למה הרגישות לא בהכרח מגיעה ל־1?'],
  'hints': ['‏<code class="ltr">order = np.argsort(-scores)</code>; ‏<code class="ltr">tp = np.cumsum(is_tp[order])</code>; הדיוק — <code class="ltr">tp / np.arange(1, n + 1)</code>.'],
  'sol': ['**א.** סף שעובר בין שני ציונים סמוכים כולל בדיוק את k הראשונים ברשימה הממוינת. סכום מצטבר נותן את כל k בבת אחת — <span class="ltr">O(n log n)</span> במקום <span class="ltr">O(n²)</span>.', '**ב.** מטרות שאף זיהוי לא פגע בהן (FN) לא מופיעות ברשימה בכלל — אין סף שיציל אותן. הרגישות המרבית היא <span class="ltr">sum(is_tp) / n_true</span>.'],
  'test': T('השלם את pr_curve ו־threshold_for_recall.',
            'import numpy as np\n\ndef pr_curve(scores, is_tp, n_true):\n    return np.array([]), np.array([])     # TODO\n\ndef threshold_for_recall(scores, is_tp, n_true, r):\n    return None     # TODO\n',
            "import numpy as np\nscores = np.array([0.9, 0.8, 0.7, 0.6, 0.5, 0.4]); is_tp = np.array([True, True, False, True, False, True])\nP, R = pr_curve(scores, is_tp, 5)\nassert np.allclose(P, [1, 1, 2/3, 3/4, 3/5, 4/6]), f'דיוק: 1, 1, 0.667, 0.75, 0.6, 0.667; קיבלתי {np.round(P, 3)}'\nassert np.allclose(R, [0.2, 0.4, 0.4, 0.6, 0.6, 0.8]), f'רגישות: 0.2 … 0.8 (מטרה אחת הוחמצה); קיבלתי {np.round(R, 3)}'\nP2, R2 = pr_curve(scores[::-1], is_tp[::-1], 5)\nassert np.allclose(P2, P), 'הסדר בקלט לא משנה — ממיינים'\nassert threshold_for_recall(scores, is_tp, 5, 0.6) == 0.6, 'רגישות 0.6 — הסף הגבוה ביותר 0.6'\nassert threshold_for_recall(scores, is_tp, 5, 0.9) is None, '0.9 בלתי אפשרי — None'",
            'import numpy as np\n\ndef pr_curve(scores, is_tp, n_true):\n    order = np.argsort(-np.asarray(scores))\n    tp = np.cumsum(np.asarray(is_tp)[order])\n    k = np.arange(1, len(order) + 1)\n    return tp / k, tp / n_true\n\ndef threshold_for_recall(scores, is_tp, n_true, r):\n    s = np.sort(np.asarray(scores))[::-1]\n    P, R = pr_curve(scores, is_tp, n_true)\n    ok = np.nonzero(R >= r - 1e-12)[0]\n    return None if len(ok) == 0 else s[ok[0]]\n')},
]

META.update({
 '10.1': (1, '10.2', '**ספירה.** **נתון:** אותה מערכת, שווא 1%. **מה לעשות:** עץ של 10,000 פריימים. **איך תדע שהצלחת:** ‏<span class="ltr">90/189 ≈ 48%</span> — הכפתור "תרגיל 10.1" בהדמיה של 10.2 מראה את העץ.'),
 '10.2': (1, '10.4', '**ביד.** **נתון:** שני וקטורי ציונים. **מה לעשות:** סופטמקס והפסד. **איך תדע שהצלחת:** ‏⅓ ו־1.10; ‏0.99991 ו־<span class="ltr">9 · 10⁻⁵</span>.'),
 '10.3': (2, '10.4', '**הסבר.** **נתון:** הטריק של החסרת המקסימום. **מה לעשות:** להוכיח שהוא לא משנה, ולהראות מה קורה בלעדיו. **איך תדע שהצלחת:** ‏<span class="ltr">e^(−c)</span> מתקצר; בלעדיו — inf ו־nan (לשונית 🐞 בהדמיה של 10.4).'),
 '10.4': (3, '10.6', '**חישוב והסבר.** **נתון:** ארבעה ערכי p. **מה לעשות:** הפסד רגיל מול מומקד. **איך תדע שהצלחת:** פי 4, 11, 100, 10,000 — כמו הטבלה בהדמיה של 10.6.'),
})
X += [
 # ------------------------------------------------ chapter 10
 {'id': '10.5', 'ch': 10, 'level': 1, 'sec': '10.1',
  'q': ['**חישוב קצר.** מזהה רכבים רץ על 1,000 תמונות. ב־200 מהן יש רכב. הוא התריע על 180 מהתמונות עם רכב, ועל 40 מהתמונות בלי.',
        '**א.** ‏<span class="ltr">P(התראה | רכב)</span> ו־<span class="ltr">P(רכב | התראה)</span>.', '**ב.** ‏<span class="ltr">P(התראה | אין רכב)</span>.', '**ג.** מעבירים את המזהה לכביש מדברי שבו רק ב־2% מהתמונות יש רכב. איזו מהשתיים בסעיף א׳ תשתנה?'],
  'hints': ['המכנה של <span class="ltr">P(A | B)</span> הוא מספר המקרים של B.'],
  'sol': ['**א.** ‏<span class="ltr">180/200 = 90%</span>; ‏<span class="ltr">180/220 ≈ 82%</span>.', '**ב.** ‏<span class="ltr">40/800 = 5%</span>.', '**ג.** ‏<span class="ltr">P(התראה | רכב)</span> היא תכונה של המזהה ולא משתנה. ‏<span class="ltr">P(רכב | התראה)</span> צונחת: מתוך 1,000 — ‏18 התראות אמת ו־49 שווא, ‏<span class="ltr">18/67 ≈ 27%</span>.']},
 {'id': '10.6', 'ch': 10, 'level': 2, 'sec': '10.3',
  'q': ['סבירות מרבית לגאוסיאן, במספרים. השלם את <code class="ltr">nll(x, mu, s)</code> — מינוס סכום הלוג של צפיפות הפעמון (9.3) על כל המדידות — ואת <code class="ltr">best_mu(x, s)</code>, שמחפשת ברשת <code class="ltr">np.linspace(x.min(), x.max(), 2001)</code> את ה־μ עם ההפסד הקטן ביותר.',
        '**א.** בבדיקה: האם <code class="ltr">best_mu</code> יוצא הממוצע? והאם הוא תלוי ב־s?', '**ב.** ובחיפוש על s (עם μ קבוע בממוצע) — לאיזה ערך הוא מתכנס?'],
  'hints': ['‏<span class="ltr">−log N = 0.5·log(2π s²) + (x − μ)² / (2 s²)</span>, סכום על x.'],
  'sol': ['**א.** כן, עד דיוק הרשת — ובלי תלות ב־s: s רק מכפיל את סכום הריבועים בקבוע ומוסיף קבוע.', '**ב.** ל־<code class="ltr">x.std()</code> — עם חלוקה ב־n (‏<code class="ltr">ddof=0</code>). זה מה שסבירות מרבית נותנת; ‏<span class="ltr">n − 1</span> (9.2) הוא תיקון של הטיה, לא סבירות מרבית.'],
  'test': T('השלם את nll ו־best_mu.',
            'import numpy as np\n\ndef nll(x, mu, s):\n    return 0.0     # TODO\n\ndef best_mu(x, s):\n    return x[0]     # TODO\n',
            "import numpy as np\nx = np.array([100, 103, 98, 101, 98.0])\nassert abs(nll(x, 97, 2) - 15.935) < 1e-2, f'nll(x, 97, 2) צריך להיות כ־15.935; קיבלתי {nll(x, 97, 2)}'\nassert abs(nll(x, 100, 2) - 10.310) < 1e-2, f'nll(x, 100, 2) צריך להיות כ־10.31; קיבלתי {nll(x, 100, 2)}'\nfor s in (0.5, 2, 8):\n    assert abs(best_mu(x, s) - x.mean()) < 0.01, f'עם s = {s} המינימום צריך להיות בממוצע 100; קיבלתי {best_mu(x, s)}'\nss = np.linspace(0.5, 5, 4501); k = np.argmin([nll(x, x.mean(), s) for s in ss])\nassert abs(ss[k] - x.std()) < 0.002, f'החיפוש על s צריך להגיע ל־x.std() = {x.std():.3f}; קיבלתי {ss[k]:.3f}'",
            'import numpy as np\n\ndef nll(x, mu, s):\n    return np.sum(0.5 * np.log(2 * np.pi * s ** 2) + (x - mu) ** 2 / (2 * s ** 2))\n\ndef best_mu(x, s):\n    grid = np.linspace(x.min(), x.max(), 2001)\n    return grid[np.argmin([nll(x, m, s) for m in grid])]\n')},
 {'id': '10.7', 'ch': 10, 'level': 2, 'sec': '10.5',
  'q': ['אנטרופיה צולבת יציבה, לאצווה. השלם את <code class="ltr">cross_entropy(Z, y)</code>: ‏Z בצורה <span class="ltr">(n, K)</span> של לוגיטים, y — מערך של n מספרי מחלקות. מחזירה <b>ממוצע</b> ההפסד, ואת הגרדיאנט לפי Z (צורה <span class="ltr">(n, K)</span>, כבר מחולק ב־n). חשב את הלוג ישירות: <span class="ltr">log p = Z − max − log Σ e^(Z − max)</span>, לכל שורה.',
        '**א.** למה הבדיקה עם לוגיט 1000 לא מחזירה nan?', '**ב.** למה כל שורה של הגרדיאנט מסתכמת ל־0?'],
  'hints': ['‏<code class="ltr">m = Z.max(axis=1, keepdims=True)</code>; ‏<code class="ltr">logp = Z - m - np.log(np.exp(Z - m).sum(axis=1, keepdims=True))</code>; ‏<code class="ltr">logp[np.arange(n), y]</code>.'],
  'sol': ['**א.** אחרי החסרת המקסימום, כל חזקה היא לכל היותר <span class="ltr">e⁰ = 1</span>, והלוג של הסכום הוא לפחות 0 — שום דבר לא גולש, ושום הסתברות לא מתעגלת ל־0 לפני הלוג.', '**ב.** ‏<span class="ltr">Σ p = 1</span> ו־<span class="ltr">Σ y = 1</span>; ולכן <span class="ltr">Σ (p − y) = 0</span>. הוספת קבוע לכל הלוגיטים לא משנה את ההפסד.'],
  'test': T('השלם את cross_entropy.',
            'import numpy as np\n\ndef cross_entropy(Z, y):\n    n = len(y)\n    return 0.0, np.zeros_like(Z)     # TODO\n',
            "import numpy as np\nZ = np.array([[2.0, 0.5, -1.0], [1.0, 1.0, 1.0]]); y = np.array([0, 2])\nL, G = cross_entropy(Z, y)\nassert abs(L - (0.2413 + np.log(3)) / 2) < 1e-3, f'ממוצע של 0.241 ו־1.099 = 0.670; קיבלתי {L}'\nassert np.allclose(G[0], np.array([0.7856 - 1, 0.1753, 0.0391]) / 2, atol=1e-3), f'שורה 0 של הגרדיאנט: (p − y)/n; קיבלתי {np.round(G[0], 4)}'\nassert np.allclose(G.sum(axis=1), 0), 'כל שורה של הגרדיאנט מסתכמת ל־0'\nL2, G2 = cross_entropy(np.array([[1000.0, 0.0, -1000.0]]), np.array([1]))\nassert np.isfinite(L2) and abs(L2 - 1000) < 1e-6, f'לוגיט 1000: ההפסד 1000, לא nan/inf; קיבלתי {L2}'\nh = 1e-5; Zp = Z.copy(); Zp[1, 0] += h; Zm = Z.copy(); Zm[1, 0] -= h\nassert abs((cross_entropy(Zp, y)[0] - cross_entropy(Zm, y)[0]) / (2 * h) - G[1, 0]) < 1e-6, 'הגרדיאנט תואם נגזרת מספרית'",
            'import numpy as np\n\ndef cross_entropy(Z, y):\n    n = len(y)\n    m = Z.max(axis=1, keepdims=True)\n    logp = Z - m - np.log(np.exp(Z - m).sum(axis=1, keepdims=True))\n    L = -logp[np.arange(n), y].mean()\n    G = np.exp(logp)\n    G[np.arange(n), y] -= 1\n    return L, G / n\n')},
 {'id': '10.8', 'ch': 10, 'level': 2, 'sec': '10.2',
  'q': ['עדכון קלמן בממד אחד. השלם את <code class="ltr">fuse(m0, s0, z, sz)</code>: חיזוי (ממוצע m0, סטיית תקן s0) ומדידה (z, ‏sz) — מחזירה את הממוצע וסטיית התקן של המאוחרת.',
        '**א.** בדוק <span class="ltr">fuse(100, 4, 106, 2)</span>.', '**ב.** ממזגים שלוש מדידות של אותה מטרה עומדת, אחת אחרי השנייה, מתוך חיזוי "רחב מאוד" (<span class="ltr">s0 = 1000</span>). למה התוצאה כמעט שווה לממוצע משוקלל לפי <span class="ltr">1/σ²</span> (9.2)?'],
  'hints': ['‏<span class="ltr">K = s0² / (s0² + sz²)</span>; ‏<span class="ltr">m = m0 + K (z − m0)</span>; ‏<span class="ltr">s = √((1 − K) s0²)</span>.'],
  'sol': ['**א.** ‏<span class="ltr">(104.8, 1.789)</span>.', '**ב.** חיזוי רחב מאוד הוא "אין לי מושג" — המדידה הראשונה כמעט מחליפה אותו. מכאן כל עדכון הוא בדיוק שקלול לפי הפוך השונות, והשונות של המאוחרת היא <span class="ltr">1 / Σ(1/σᵢ²)</span>. קלמן הוא ממוצע משוקלל שמתעדכן מדידה אחרי מדידה.'],
  'test': T('השלם את fuse.',
            'import numpy as np\n\ndef fuse(m0, s0, z, sz):\n    return (m0 + z) / 2, (s0 + sz) / 2     # TODO: not Bayes\n',
            "import numpy as np\nm, s = fuse(100, 4, 106, 2)\nassert abs(m - 104.8) < 1e-9 and abs(s - np.sqrt(3.2)) < 1e-9, f'(104.8, 1.789); קיבלתי ({m}, {s})'\nm, s = 0.0, 1000.0\nfor z, sz in [(10, 1), (14, 2), (7, 4)]:\n    m, s = fuse(m, s, z, sz)\nw = np.array([1, 1/4, 1/16]); ref = (w * np.array([10, 14, 7])).sum() / w.sum()\nassert abs(m - ref) < 1e-3 and abs(s - 1 / np.sqrt(w.sum())) < 1e-3, f'שלוש מדידות: ממוצע משוקלל {ref:.3f}, σ {1/np.sqrt(w.sum()):.3f}; קיבלתי ({m:.3f}, {s:.3f})'\nassert s < 1, 'המיזוג צר מכל מדידה בודדת'",
            'import numpy as np\n\ndef fuse(m0, s0, z, sz):\n    K = s0 ** 2 / (s0 ** 2 + sz ** 2)\n    return m0 + K * (z - m0), np.sqrt((1 - K) * s0 ** 2)\n')},
 {'id': '10.9', 'ch': 10, 'level': 3, 'sec': '10.6',
  'q': ['**אתגר — הפסד מומקד לזיהוי.** השלם את <code class="ltr">focal(p, y, gamma=2.0, alpha=0.25)</code>: ‏p — הסתברויות "מטרה" (סיגמואיד) למערך של עוגנים, y — 1 למטרה ו־0 לרקע. ההפסד לכל עוגן: <span class="ltr">−α (1 − p)^γ log p</span> כש־<span class="ltr">y = 1</span>, ו־<span class="ltr">−(1 − α) p^γ log(1 − p)</span> כש־<span class="ltr">y = 0</span>. מחזירה את <b>הסכום</b>, מחולק במספר המטרות (כמו ב־RetinaNet).',
        '**א.** בבדיקה: 1,000 עוגני רקע קלים (הסתברות "מטרה" 0.05) ו־10 מטרות קשות (0.3). מה החלק של הרקע בהפסד, עם <span class="ltr">gamma = 0, alpha = 0.5</span> לעומת ברירת המחדל?', '**ב.** למה מחלקים במספר המטרות ולא במספר העוגנים?'],
  'hints': ['‏<code class="ltr">pt = np.where(y == 1, p, 1 - p)</code> — ההסתברות של התשובה הנכונה; ואז אותה נוסחה לשניהם, עם <code class="ltr">at = np.where(y == 1, alpha, 1 - alpha)</code>.'],
  'sol': ['**א.** עם <span class="ltr">γ = 0, α = 0.5</span> (אנטרופיה צולבת רגילה, חצי) — הרקע כ־81% מההפסד. עם <span class="ltr">γ = 2, α = 0.25</span> — כ־6%. ‏(1 − p)^γ מוריד כל עוגן רקע פי 400, ו־α מחזיר לו קצת משקל (0.75 מול 0.25 למטרות) — ובכל זאת המטרות הן עכשיו רוב ההפסד.', '**ב.** מספר העוגנים ענק וכמעט קבוע, ומספר המטרות משתנה מתמונה לתמונה. חלוקה במספר המטרות שומרת על סקאלה דומה של הגרדיאנט בין תמונה עם מטרה אחת לתמונה עם עשרים — והרקע כבר מנוטרל על ידי γ.'],
  'test': T('השלם את focal.',
            'import numpy as np\n\ndef focal(p, y, gamma=2.0, alpha=0.25):\n    return 0.0     # TODO\n',
            "import numpy as np\np = np.r_[np.full(1000, 0.05), np.full(10, 0.3)]; y = np.r_[np.zeros(1000), np.ones(10)]\nce_bg = focal(p[:1000], y[:1000], 0.0, 0.5); ce_t = focal(p[1000:], y[1000:], 0.0, 0.5) * 10\nassert abs(ce_t - 0.5 * 10 * -np.log(0.3)) < 1e-6, 'γ = 0, α = 0.5: מחצית מאנטרופיה צולבת על המטרות'\nshare0 = ce_bg / (ce_bg + ce_t)\nassert 0.78 < share0 < 0.84, f'עם γ = 0 הרקע צריך להיות כ־81% מההפסד; קיבלתי {share0:.2f}'\nfb = focal(p[:1000], y[:1000]); ft = focal(p[1000:], y[1000:]) * 10\nshare2 = fb / (fb + ft)\nassert 0.04 < share2 < 0.08, f'עם γ = 2, α = 0.25 הרקע צריך לרדת לכ־6%; קיבלתי {share2:.3f}'\nassert abs(focal(p, y) - (fb + ft) / 10) < 1e-9, 'סך הכול מחולק במספר המטרות (10)'\nassert abs(focal(np.array([0.9]), np.array([1.0]), 2, 1.0) - 0.01 * -np.log(0.9)) < 1e-12, 'p = 0.9, γ = 2: ‏0.01 · 0.105'",
            'import numpy as np\n\ndef focal(p, y, gamma=2.0, alpha=0.25):\n    pt = np.where(y == 1, p, 1 - p)\n    at = np.where(y == 1, alpha, 1 - alpha)\n    loss = -at * (1 - pt) ** gamma * np.log(pt)\n    return loss.sum() / max(1, (y == 1).sum())\n')},
]

META.update({
 '11.1': (1, '11.1', '**ביד.** **נתון:** אות וגרעין. **מה לעשות:** שלושה מספרים. **איך תדע שהצלחת:** ‏<span class="ltr">[−2, −2, −2]</span> — כמו בהדמיה של 11.1, עם הגרעין "תרגיל 11.1".'),
 '11.2': (1, '11.4', '**חישוב קצר.** **נתון:** שלוש שכבות. **מה לעשות:** הנוסחה. **איך תדע שהצלחת:** 28, 32, 320 — הכפתורים בהדמיה של 11.4.'),
 '11.3': (2, '11.3', '**זה תרגיל שמריצים במחשב.** **נתון:** <code class="ltr">conv2d</code> וארבעה גרעינים. **מה לעשות:** ארבע תמונות זו לצד זו. **איך תדע שהצלחת:** כמו הלשונית "כל הקטלוג" בהדמיה של 11.3.'),
 '11.4': (2, '11.5', '**זה תרגיל שמריצים במחשב.** **נתון:** תמונה ורעש. **מה לעשות:** ממוצע מול חציון. **איך תדע שהצלחת:** החציון נקי; השגיאה הממוצעת שלו קטנה פי כמה — כמו בהדמיה של 11.5.'),
 '11.5': (3, '11.3', '**הוכחה וקוד.** **נתון:** גאוסיאן <span class="ltr">5×5</span>. **מה לעשות:** להראות שהוא מכפלה חיצונית, ולהשוות שני מעברים לאחד. **איך תדע שהצלחת:** <code class="ltr">np.allclose</code> בין שתי התוצאות (בפנים, הרחק מהשוליים).'),
})
X += [
 # ------------------------------------------------ chapter 11
 {'id': '11.6', 'ch': 11, 'level': 1, 'sec': '11.7',
  'q': ['**חישוב קצר.** רשת קטנה על תמונות <span class="ltr">64×64×3</span>: ‏<code class="ltr">Conv2d(3, 16, 3, padding=1)</code>, ואחריה <code class="ltr">Conv2d(16, 32, 3, stride=2, padding=1)</code>.',
        '**א.** כמה פרמטרים בכל שכבה (כולל הטיה)?', '**ב.** מה צורת הפלט אחרי כל שכבה?', '**ג.** כמה פרמטרים הייתה דורשת שכבה מלאה מהקלט לפלט של השכבה הראשונה?'],
  'hints': ['כל ערוץ פלט: גרעין <span class="ltr">k × k × (ערוצי קלט)</span> ועוד הטיה אחת.'],
  'sol': ['**א.** ‏<span class="ltr">16 · (3·3·3 + 1) = 448</span>; ‏<span class="ltr">32 · (3·3·16 + 1) = 4,640</span>.', '**ב.** ‏<span class="ltr">64×64×16</span> (ריפוד 1 שומר); ‏<span class="ltr">⌊(64 + 2 − 3)/2⌋ + 1 = 32</span> — ‏<span class="ltr">32×32×32</span>.', '**ג.** ‏<span class="ltr">(64·64·3) · (64·64·16) + 64·64·16 ≈ 805</span> מיליון — פי כמעט שני מיליון.']},
 {'id': '11.7', 'ch': 11, 'level': 2, 'sec': '11.6',
  'q': ['הקטנה בלי aliasing. השלם את <code class="ltr">shrink(img, f, blur)</code>: מחזירה כל פיקסל f־י (<code class="ltr">img[::f, ::f]</code>); אם <code class="ltr">blur</code> — קודם ממצעת כל בלוק של <span class="ltr">f×f</span> (ובלוק לא שלם בשוליים — חותכים).',
        '**א.** בבדיקה: פסים מתחלפים 0, 255, 0, 255 ברוחב עמודה. מה יוצא בכל דרך עם <span class="ltr">f = 2</span>?', '**ב.** למה הממוצע של הבלוק הוא "טשטוש" במובן של 11.6?'],
  'hints': ['‏<code class="ltr">h, w = (H // f) * f, (W // f) * f</code>; ‏<code class="ltr">img[:h, :w].reshape(h // f, f, w // f, f).mean(axis=(1, 3))</code>.'],
  'sol': ['**א.** בלי טשטוש — הכול 0: הפסים הלבנים נעלמו, ונראה כאילו התמונה שחורה. עם — הכול 127.5: "אפור", התיאור הנכון של פסים צפופים מדי.', '**ב.** ממוצע הוא קונבולוציה עם גרעין שכל משקליו <span class="ltr">1/f²</span> — מעביר נמוכים (11.3). הוא מוחק בדיוק את התדרים שהדגימה לא יכולה לייצג. (<code class="ltr">INTER_AREA</code> של OpenCV עושה את זה.)'],
  'test': T('השלם את shrink.',
            'import numpy as np\n\ndef shrink(img, f, blur):\n    return img     # TODO\n',
            "import numpy as np\nst = np.tile(np.array([0, 255.0]), (6, 4))   # 6x8 stripes\na = shrink(st, 2, False); b = shrink(st, 2, True)\nassert a.shape == (3, 4) and b.shape == (3, 4), f'צורה (3, 4); קיבלתי {a.shape}, {b.shape}'\nassert np.all(a == 0), 'בלי טשטוש: הכול 0 — aliasing'\nassert np.allclose(b, 127.5), 'עם ממוצע בלוקים: הכול 127.5'\nr = np.arange(35.0).reshape(5, 7); c = shrink(r, 2, True)\nassert c.shape == (2, 3) and np.isclose(c[0, 0], (0 + 1 + 7 + 8) / 4), 'בלוק לא שלם בשוליים — נחתך; הבלוק הראשון ממוצע של 0, 1, 7, 8'",
            'import numpy as np\n\ndef shrink(img, f, blur):\n    if not blur:\n        return img[::f, ::f][:img.shape[0] // f, :img.shape[1] // f]\n    h, w = (img.shape[0] // f) * f, (img.shape[1] // f) * f\n    return img[:h, :w].reshape(h // f, f, w // f, f).mean(axis=(1, 3))\n')},
 {'id': '11.8', 'ch': 11, 'level': 2, 'sec': '11.4',
  'q': ['קונבולוציה עם ריפוד וצעד. השלם את <code class="ltr">conv2d_ps(img, k, p, s)</code>: מרפדת באפסים (<code class="ltr">np.pad</code>), ואז מחליקה את הגרעין בצעדים של s. הפלט בגודל של הנוסחה של 11.4.',
        '**א.** בבדיקה: <span class="ltr">7×7</span>, גרעין <span class="ltr">3×3</span>, ‏<span class="ltr">p = 1, s = 2</span>. מה הצורה?', '**ב.** איך מקבלים את הפלט עם <span class="ltr">s = 2</span> מהפלט עם <span class="ltr">s = 1</span>?'],
  'hints': ['‏<code class="ltr">P = np.pad(img, p)</code>; ‏<code class="ltr">out = (P.shape[0] - kh) // s + 1</code>; החלון: <code class="ltr">P[y * s : y * s + kh, x * s : x * s + kw]</code>.'],
  'sol': ['**א.** ‏<span class="ltr">⌊(7 + 2 − 3)/2⌋ + 1 = 4</span> — ‏<span class="ltr">(4, 4)</span>.', '**ב.** ‏<code class="ltr">full[::2, ::2]</code> — אותם חלונות, רק כל שני. (ולכן צעד 2 "עולה" כמו צעד 1 אם מחשבים בטיפשות — ספריות מחשבות רק את המיקומים הנדרשים.)'],
  'test': T('השלם את conv2d_ps.',
            'import numpy as np\n\ndef conv2d_ps(img, k, p, s):\n    return np.zeros((1, 1))     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0); img = rng.random((7, 7)); k = rng.random((3, 3))\no = conv2d_ps(img, k, 1, 2)\nassert o.shape == (4, 4), f'(4, 4); קיבלתי {o.shape}'\nP = np.pad(img, 1)\nfull = np.array([[np.sum(P[y:y + 3, x:x + 3] * k) for x in range(7)] for y in range(7)])\nassert np.allclose(o, full[::2, ::2]), 'הפלט עם s = 2 הוא כל איבר שני של הפלט עם s = 1'\nassert conv2d_ps(np.ones((32, 32)), np.ones((5, 5)), 0, 1).shape == (28, 28), 'תרגיל 11.2א: 28'\nassert conv2d_ps(np.ones((64, 64)), np.ones((3, 3)), 1, 2).shape == (32, 32), 'תרגיל 11.2ב: 32'",
            'import numpy as np\n\ndef conv2d_ps(img, k, p, s):\n    P = np.pad(img, p)\n    kh, kw = k.shape\n    H = (P.shape[0] - kh) // s + 1\n    W = (P.shape[1] - kw) // s + 1\n    out = np.zeros((H, W))\n    for y in range(H):\n        for x in range(W):\n            out[y, x] = np.sum(P[y * s:y * s + kh, x * s:x * s + kw] * k)\n    return out\n')},
 {'id': '11.9', 'ch': 11, 'level': 3, 'sec': '11.7',
  'q': ['**אתגר — ללמוד גרעין.** נתונים <code class="ltr">img</code> (מנורמל) ו־<code class="ltr">target</code> — הפלט של גרעין <span class="ltr">3×3</span> לא ידוע עליו (‏"valid"). השלם את <code class="ltr">learn_kernel(img, target, lr, steps)</code>: מתחילה מגרעין אפסים, ובכל צעד מחשבת את הפלט, את <span class="ltr">L = mean(err²)</span>, ואת הגרדיאנט לפי כל אחד מתשעת המשקלות — ומעדכנת. מחזירה את הגרעין.',
        '**א.** בלי לולאה על פיקסלים: איך מחשבים את הפלט ואת הגרדיאנט עם 9 פעולות חיתוך?', '**ב.** בבדיקה, הקלט הוא רעש לבן. למה עם תמונה אמיתית (חלקה) האימון איטי בהרבה?'],
  'hints': ['פלט: <span class="ltr">Σ k[i, j] · img[i : i + H, j : j + W]</span>. גרדיאנט: <span class="ltr">g[i, j] = 2 · mean(err · img[i : i + H, j : j + W])</span>.'],
  'sol': ['**א.** החיתוך <code class="ltr">img[i:i + H, j:j + W]</code> הוא "כל הפיקסלים שמתחת ל־<span class="ltr">k[i, j]</span>" בכל המיקומים. הפלט — סכום של 9 כאלה כפול המשקלות; הגרדיאנט — ממוצע של המכפלה עם הטעות, לכל אחד.', '**ב.** ברעש לבן, הפיקסלים השכנים לא מתואמים — העמק "עגול", וירידה במורד מגיעה מהר. בתמונה אמיתית שכנים כמעט שווים: תשעת הכיוונים כמעט תלויים, והעמק צר מאוד (פרק 8.6) — כמו בהדמיה של 11.7.'],
  'test': T('השלם את learn_kernel.',
            'import numpy as np\n\ndef learn_kernel(img, target, lr, steps):\n    k = np.zeros((3, 3))\n    return k     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(1); img = rng.standard_normal((40, 40))\nK = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1.0]])\nH, W = 38, 38\ntarget = sum(K[i, j] * img[i:i + H, j:j + W] for i in range(3) for j in range(3))\nk = learn_kernel(img, target, 0.2, 200)\nassert k.shape == (3, 3), 'גרעין 3×3'\nassert np.allclose(k, K, atol=1e-3), f'צריך לשחזר את סובל; קיבלתי {np.round(k, 3)}'",
            'import numpy as np\n\ndef learn_kernel(img, target, lr, steps):\n    k = np.zeros((3, 3))\n    H, W = target.shape\n    for _ in range(steps):\n        out = sum(k[i, j] * img[i:i + H, j:j + W] for i in range(3) for j in range(3))\n        err = out - target\n        g = np.array([[2 * np.mean(err * img[i:i + H, j:j + W]) for j in range(3)] for i in range(3)])\n        k -= lr * g\n    return k\n')},
]

META.update({
 '12.1': (2, '12.4', '**ניסוי.** **נתון:** הקוד של 12.4. **מה לעשות:** בלי נרמול, מאפיין × 1000. **איך תדע שהצלחת:** ההפסד מתבדר או כמעט לא זז — המתגים בהדמיה של 12.4 מראים את שניהם.'),
 '12.2': (2, '12.4', '**ניסוי.** **נתון:** מרכזים קרובים. **מה לעשות:** להריץ ולמדוד דיוק. **איך תדע שהצלחת:** דיוק של כ־70% — ושום קו לא יעשה הרבה יותר טוב (גרור את הריבועים בהדמיה של 12.4).'),
 '12.3': (2, '12.4', '**קוד.** **נתון:** הלולאה של 12.4. **מה לעשות:** מקבצים של 32. **איך תדע שהצלחת:** עקומה רועשת יותר, אותה תוצאה (המתג בהדמיה).'),
 '12.4': (3, '12.6', '**קוד.** **נתון:** הפרויקט. **מה לעשות:** שלוש מחלקות עם סופטמקס. **איך תדע שהצלחת:** הגרדיאנט <span class="ltr">Xᵀ(P − Y)/n</span> בצורה <span class="ltr">(2, 3)</span>, ושלושה אזורים — כמו בלשונית "שלוש מחלקות" בהדמיה של 12.4.'),
 '12.5': (3, '12.6', '**קוד.** **נתון:** שני מעגלים. **מה לעשות:** שכבה נסתרת ומעבר לאחור ביד. **איך תדע שהצלחת:** בדיקת גרדיאנט עוברת לשתי השכבות, וגבול עגול — הלשונית "שכבה נסתרת" בהדמיה של 12.4.'),
})
X += [
 # ------------------------------------------------ chapter 12
 {'id': '12.6', 'ch': 12, 'level': 1, 'sec': '12.2',
  'q': ['**ביד.** ‏<span class="ltr">w = (2, −1)</span>, ‏<span class="ltr">b = 0.5</span>.',
        '**א.** מה z, ‏p וההפסד של הנקודה <span class="ltr">x = (1, 1)</span> עם <span class="ltr">y = 1</span>? ועם <span class="ltr">y = 0</span>?', '**ב.** מה משוואת קו ההפרדה? באיזה צד שלו נמצאת <span class="ltr">(0, 0)</span>?', '**ג.** מכפילים את w ו־b פי 10. מה קורה לקו, ומה ל־p של <span class="ltr">(1, 1)</span>?'],
  'hints': ['‏<span class="ltr">σ(1.5) ≈ 0.818</span>.'],
  'sol': ['**א.** ‏<span class="ltr">z = 2 − 1 + 0.5 = 1.5</span>, ‏<span class="ltr">p ≈ 0.818</span>. עם <span class="ltr">y = 1</span>: ‏<span class="ltr">−log 0.818 ≈ 0.20</span>; עם <span class="ltr">y = 0</span>: ‏<span class="ltr">−log 0.182 ≈ 1.70</span>.', '**ב.** ‏<span class="ltr">2x₁ − x₂ + 0.5 = 0</span>, כלומר <span class="ltr">x₂ = 2x₁ + 0.5</span>. ב־<span class="ltr">(0, 0)</span>: ‏<span class="ltr">z = 0.5 &gt; 0</span> — בצד של מחלקה 1 (‏<span class="ltr">p ≈ 0.62</span>).', '**ג.** הקו לא זז (<span class="ltr">10z = 0</span> אותו קו). ‏<span class="ltr">z = 15</span>, ‏<span class="ltr">p ≈ 0.9999997</span>: המודל "בטוח יותר". לכן אימון על נתונים שאפשר להפריד מושלם מגדיל את w בלי סוף.']},
 {'id': '12.7', 'ch': 12, 'level': 1, 'sec': '12.3',
  'q': ['**כלל השרשרת במספרים.** נקודה <span class="ltr">x = (2, −1)</span>, ‏<span class="ltr">y = 0</span>, ‏<span class="ltr">w = (0.5, 0.5)</span>, ‏<span class="ltr">b = 0</span>.',
        '**א.** חשב את ארבע החוליות של 12.3, ובדוק שהמכפלה של הראשונות היא <span class="ltr">p − y</span>.', '**ב.** מה הגרדיאנט לפי w ולפי b? ולאן יזוז w בצעד עם <span class="ltr">η = 1</span>?'],
  'hints': ['‏<span class="ltr">z = 0.5</span>, ‏<span class="ltr">σ(0.5) ≈ 0.622</span>.'],
  'sol': ['**א.** ‏<span class="ltr">p ≈ 0.622</span>; ‏<span class="ltr">∂L/∂p = 1/(1 − p) ≈ 2.646</span>; ‏<span class="ltr">∂p/∂z = p(1 − p) ≈ 0.235</span>; מכפלה <span class="ltr">≈ 0.622 = p − 0</span>.', '**ב.** ‏<span class="ltr">∂L/∂w = 0.622 · (2, −1) = (1.245, −0.622)</span>, ‏<span class="ltr">∂L/∂b = 0.622</span>. ‏<span class="ltr">w → (−0.745, 1.122)</span>, ‏<span class="ltr">b → −0.622</span> — הנקודה, ששייכת ל־0, נדחפת לצד של 0 (‏<span class="ltr">z ≈ −3.2</span> עכשיו).']},
 {'id': '12.8', 'ch': 12, 'level': 1, 'sec': '12.1',
  'q': ['**צורות.** בקוד של 12.4 — מה הצורה של כל אחד?', {'table': [['ביטוי', 'צורה?'], ['<code class="ltr">X</code> אחרי <code class="ltr">vstack</code>', '?'], ['<code class="ltr">X_train @ w</code>', '?'], ['<code class="ltr">X_train.T</code>', '?'], ['<code class="ltr">X_train.T @ error</code>', '?'], ['<code class="ltr">X_train.mean(axis=0)</code>', '?'], ['<code class="ltr">test_pred</code>', '?']]}, '**ב.** ולמה בציור הקו מחלקים ב־<code class="ltr">w[1]</code> — ומה קורה אם הוא 0?'],
  'hints': ['‏<span class="ltr">(n, 2) @ (2,) → (n,)</span>.'],
  'sol': ['‏<span class="ltr">(400, 2)</span>; ‏<span class="ltr">(300,)</span>; ‏<span class="ltr">(2, 300)</span>; ‏<span class="ltr">(2,)</span>; ‏<span class="ltr">(2,)</span> — ממוצע לכל עמודה; ‏<span class="ltr">(100,)</span> של <code class="ltr">bool</code>.', '**ב.** מבודדים את <span class="ltr">x₂</span> מ־<span class="ltr">w₀x₁ + w₁x₂ + b = 0</span>. אם <span class="ltr">w₁ = 0</span> הקו אנכי (<span class="ltr">x₁ = −b/w₀</span>) ואי אפשר לכתוב אותו כ־<span class="ltr">x₂ = …</span> — חלוקה באפס. (ההדמיות מציירות אותו לפי הרכיב הגדול של w.)']},
 {'id': '12.9', 'ch': 12, 'level': 2, 'sec': '12.5',
  'q': ['בדיקת גרדיאנט כללית. השלם את <code class="ltr">grad_check(f, grad, theta, h=1e-5)</code>: ‏f מחזירה הפסד (מספר) ל־theta (מערך), ‏grad — את הגרדיאנט האנליטי. מחזירה את השגיאה היחסית המקסימלית בין האנליטי למספרי (הפרש מרכזי לכל רכיב).',
        '**א.** בבדיקה — הרגרסיה הלוגיסטית, עם theta שמחזיק את w ו־b יחד. למה לאחד אותם לווקטור אחד?', '**ב.** הבדיקה מכניסה באג (בלי <span class="ltr">/n</span>). כמה יוצאת השגיאה היחסית, ולמה דווקא המספר הזה?'],
  'hints': ['‏<code class="ltr">e = np.zeros_like(theta); e[i] = h</code>; ‏<code class="ltr">(f(theta + e) - f(theta - e)) / (2 * h)</code>; ‏<code class="ltr">np.abs(a - n) / (np.abs(a) + np.abs(n) + 1e-300)</code>.'],
  'sol': ['**א.** אז פונקציה אחת בודקת כל מודל, בכל מספר פרמטרים — כמו ש־PyTorch מחזיק את כל הפרמטרים ברשימה אחת.', '**ב.** עם n = 50 הגרדיאנט האנליטי גדול פי 50: ‏<span class="ltr">|50n − n| / (50n + n) = 49/51 ≈ 0.96</span>. שגיאה יחסית קרובה ל־1 אומרת "לא רק לא מדויק — במקום אחר לגמרי".'],
  'test': T('השלם את grad_check.',
            'import numpy as np\n\ndef grad_check(f, grad, theta, h=1e-5):\n    return 0.0     # TODO\n',
            "import numpy as np\nrng = np.random.default_rng(0); X = rng.standard_normal((50, 2)); y = (X[:, 0] + X[:, 1] > 0).astype(float)\nsig = lambda z: 1 / (1 + np.exp(-z))\ndef f(t):\n    p = sig(X @ t[:2] + t[2]); return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))\ndef g(t):\n    e = sig(X @ t[:2] + t[2]) - y; return np.r_[X.T @ e / len(y), e.mean()]\nt = np.array([0.3, -0.7, 0.1])\nr = grad_check(f, g, t)\nassert r < 1e-7, f'הגרדיאנט הנכון צריך לעבור (< 1e-7); קיבלתי {r}'\nbad = lambda t: g(t) * len(y)\nr2 = grad_check(f, bad, t)\nassert abs(r2 - 49 / 51) < 1e-3, f'בלי /n: 49/51 ≈ 0.961; קיבלתי {r2}'\nassert np.allclose(t, [0.3, -0.7, 0.1]), 'אסור לשנות את theta המקורי'",
            'import numpy as np\n\ndef grad_check(f, grad, theta, h=1e-5):\n    a = grad(theta)\n    n = np.zeros_like(theta, dtype=float)\n    for i in range(len(theta)):\n        e = np.zeros_like(theta, dtype=float); e[i] = h\n        n[i] = (f(theta + e) - f(theta - e)) / (2 * h)\n    return np.max(np.abs(a - n) / (np.abs(a) + np.abs(n) + 1e-300))\n')},
]

X += [
 {'id': '8.10', 'ch': 8, 'level': 1, 'sec': '8.1',
  'q': ['**חישוב קצר — המדרון בערפל.** בנקודה A הגרדיאנט של ההפסד הוא <span class="ltr">(−4, 2)</span>; בנקודה B, קרוב לתחתית, הוא <span class="ltr">(−0.4, 0.2)</span>. ‏<span class="ltr">η = 0.1</span>.',
        '**א.** לאיזה כיוון יורדים הכי חזק ב־A? מה הצעד, ומה אורכו?', '**ב.** אותו דבר ב־B. מה היחס בין אורכי הצעדים, ולמה לא היה צריך "להגיד" לאלגוריתם להאט?', '**ג.** האם הצעד ב־A מצביע אל המינימום?'],
  'hints': ['הצעד הוא <span class="ltr">−η · ∇L</span>.'],
  'sol': ['**א.** נגד הגרדיאנט: <span class="ltr">(4, −2)</span>. הצעד <span class="ltr">(0.4, −0.2)</span>, באורך <span class="ltr">√0.2 ≈ 0.447</span>.', '**ב.** ‏<span class="ltr">(0.04, −0.02)</span>, אורך <span class="ltr">≈ 0.045</span> — פי 10 קצר. אורך הצעד פרופורציונלי לגרדיאנט, והגרדיאנט קטן ליד התחתית: התחתית עצמה מאטה.', '**ג.** לא בהכרח — הוא מצביע לירידה המקומית התלולה ביותר. בעמק עגול זה אותו דבר; בעמק צר ועקום — לא (8.6).']},
 {'id': '11.10', 'ch': 11, 'level': 1, 'sec': '11.2',
  'q': ['**ביד.** התמונה של האיור:', {'table': [['3', '0', '1', '2', '7'], ['1', '5', '8', '9', '3'], ['2', '7', '2', '5', '1'], ['0', '1', '3', '1', '7'], ['4', '2', '1', '6', '2']]}, 'והגרעין "שמאל פחות ימין": שלוש שורות של <span class="ltr">[1, 0, −1]</span>.',
        '**א.** מה גודל הפלט, בלי ריפוד?', '**ב.** חשב את <span class="ltr">out[1, 1]</span> (החלון שמתחיל בשורה 1, עמודה 1).', '**ג.** כמה כפלים בסך הכול?'],
  'hints': ['החלון: שורות 1–3, עמודות 1–3. הגרעין: העמודה השמאלית פחות הימנית.'],
  'sol': ['**א.** ‏<span class="ltr">3×3</span>: ‏<span class="ltr">5 − 3 + 1 = 3</span> בכל כיוון.', '**ב.** החלון <span class="ltr">[[5, 8, 9], [7, 2, 5], [1, 3, 1]]</span>: שמאל <span class="ltr">5 + 7 + 1 = 13</span>, ימין <span class="ltr">9 + 5 + 1 = 15</span>, ‏<span class="ltr">13 − 15 = −2</span>. (הקוד של 11.2, כשמריצים אותו על הדוגמה, מדפיס בדיוק את זה במרכז.)', '**ג.** ‏<span class="ltr">9 · 9 = 81</span>.']},
]

#@@CH@@

# ---------- validation ----------
def run(src, cwd=None):
    r = subprocess.run([sys.executable, '-c', src], capture_output=True, text=True, timeout=120, cwd=cwd, env=dict(os.environ, MPLBACKEND='Agg'))
    return r.stdout, r.stderr
STUB = 'import cv2\ncv2.imshow = lambda *a, **k: None\ncv2.waitKey = lambda *a, **k: -1\ncv2.destroyAllWindows = lambda *a, **k: None\n'
bad = 0
def wrap(body): return 'try:\n' + '\n'.join('    ' + l for l in body.split('\n')) + "\n    print('PASS')\nexcept Exception as e:\n    print('FAIL:', e)"
for e in X:
    t = e.get('test')
    if t:
        o1, e1 = run(t['starter'] + '\n\n' + wrap(t['body'])); o2, e2 = run(t['solved'] + '\n\n' + wrap(t['body']))
        ok = 'PASS' not in o1 and 'PASS' in o2 and not e2
        print('test', e['id'], 'OK' if ok else 'BAD', '| starter:', (o1.strip().splitlines() or [e1.strip()[-80:]])[-1][:90])
        if not ok: bad += 1; print('   solved ->', o2, e2[-300:])
    for part in ('q', 'sol'):
        for b in e[part]:
            if isinstance(b, dict) and 'code' in b and not b.get('norun'):
                with tempfile.TemporaryDirectory() as td:
                    o, er = run(STUB + b['code'], cwd=td)
                print('code', e['id'], part, 'OK' if not er else 'BAD', '|', o.strip().replace('\n', ' / ')[:90])
                if er: bad += 1; print(er[-400:])
                b['out'] = o
if bad: sys.exit('validation failed')

# ---------- emit ----------
exs, tests, hints, exsec, meta = {}, {}, {}, {}, {}
n = 0
for e in X:
    def blocks(items, tag):
        global n
        out = []
        for it in items:
            n += 1
            if isinstance(it, dict) and 'table' in it:
                out.append({'type': 'table', 'header': True, 'id': f'm0-x{n}', 'rows': [[[{'type': 'p', 'text': c}] for c in r] for r in it['table']]})
            elif isinstance(it, dict):
                out.append({'type': 'code', 'lang': it.get('lang', 'python'), 'text': it['code'], 'id': f'm0-x{n}', 'output': {'stdout': it.get('out', '')}})
            else:
                out.append({'type': 'p', 'text': it, 'id': f'm0-x{n}'})
        return out
    exs.setdefault(e['ch'], []).append({'id': e['id'], 'star': False, 'extra': True, 'blocks': blocks(e['q'], 'q'), 'solution': blocks(e['sol'], 's')})
    if e.get('test'): tests[e['id']] = {'task': e['test']['task'], 'starter': e['test']['starter'], 'test': wrap(e['test']['body'])}
    hints[e['id']] = e['hints']; exsec[e['id']] = e['sec']; meta[e['id']] = {'level': e['level'], 'sec': e['sec']}
for k, (lv, sec, ex) in META.items(): meta[k] = {'level': lv, 'sec': sec, 'explain': ex}; exsec[k] = sec
js = '''/* Module 0 — exercise levels, an explanation of what every question asks, and supplementary exercises
   for the sections the course's own sets do not reach (generated by exercises_m0.py). All of it is an ADDITION. */
(function () {
const L = window.LAYER.m0, M = window.CONTENT.m0;
const EXTRA = %s;
Object.keys(EXTRA).forEach(n => { const c = M.chapters.find(x => x.n === +n); if (c && !c.exercises.some(e => e.extra)) c.exercises.push(...EXTRA[n]); });
L.exMeta = %s;
Object.assign(L.codeTests, %s);
Object.assign(L.hints, %s);
Object.assign(L.exSection, %s);
})();
''' % tuple(json.dumps(x, ensure_ascii=False) for x in (exs, meta, tests, hints, exsec))
open('site/content/m0_exercises.js', 'w', encoding='utf8').write(js)
print('written:', sum(len(v) for v in exs.values()), 'extra exercises,', len(tests), 'new checks')


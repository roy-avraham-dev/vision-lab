import numpy as np
import cv2

def look_at(C, target, up=(0, 0, 1)):
    C = np.asarray(C, float)
    z = np.asarray(target, float) - C
    z /= np.linalg.norm(z)
    x = np.cross(z, up)
    x /= np.linalg.norm(x)
    y = np.cross(z, x)
    R = np.vstack([x, y, z])
    return R, -R @ C

K = np.array([[1000, 0, 640], [0, 1000, 360], [0, 0, 1.0]])
rng = np.random.default_rng(3)
Pw = np.c_[rng.uniform(-5, 5, 10), rng.uniform(5, 25, 10), rng.uniform(0, 4, 10)]   # 10 known points
C_true = np.array([2.0, -10, 3])
R, t = look_at(C_true, [0, 15, 1])
uv, _ = cv2.projectPoints(Pw, cv2.Rodrigues(R)[0], t, K, None)
uv = uv.reshape(-1, 2) + rng.normal(0, 0.5, (10, 2))
uv[:2] += [[60, -40], [-50, 70]]                     # two wrong matches

for name, fn in (("solvePnP", lambda: cv2.solvePnP(Pw, uv, K, None)[1:]),
                 ("solvePnPRansac", lambda: cv2.solvePnPRansac(Pw, uv, K, None, reprojectionError=3.0)[1:3])):
    rv, tv = fn()
    Rm, _ = cv2.Rodrigues(rv)
    C = -Rm.T @ tv.ravel()
    print(f"{name:15s} C = {C.round(3)}   error {np.linalg.norm(C - C_true) * 100:6.1f} cm")
_, rv, tv, inl = cv2.solvePnPRansac(Pw, uv, K, None, reprojectionError=3.0)
print("inliers:", np.sort(inl.ravel()))

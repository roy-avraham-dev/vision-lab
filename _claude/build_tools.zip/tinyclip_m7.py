"""tinyclip.py — the small contrastive model of module 7: data (shapes with captions), two towers, two losses
(softmax = CLIP, sigmoid = SigLIP) with hand-written gradients, and Adam. numpy + cv2 only."""
import numpy as np, cv2

SHAPES = ['circle', 'square', 'triangle', 'cross']
COLORS = {'red': (220, 40, 40), 'green': (40, 190, 60), 'blue': (40, 70, 220), 'yellow': (230, 210, 40)}
SIZES = ['small', 'large']
HOLDOUT = {('triangle', 'blue'), ('circle', 'yellow'), ('square', 'red'), ('cross', 'green')}
TEMPLATES = ['a photo of a {s} {c} {sh}', 'one {s} {sh} colored {c}', 'a {c} {sh} that is {s}', 'there is a {s} {c} {sh}']

def classes():
    return [(sh, c, s) for sh in SHAPES for c in COLORS for s in SIZES]

def draw(sh, c, s, rng):
    img = rng.integers(70, 150, (32, 32, 3)).astype(np.uint8)          # noisy gray background
    r = int(rng.integers(10, 13)) if s == 'large' else int(rng.integers(5, 7))
    cx, cy = (int(v) for v in rng.integers(r + 1, 32 - r - 1, 2))
    col = tuple(int(v) for v in np.clip(np.array(COLORS[c][::-1]) + rng.integers(-20, 21, 3), 0, 255))  # BGR
    if sh == 'circle':
        cv2.circle(img, (cx, cy), r, col, -1)
    elif sh == 'square':
        cv2.rectangle(img, (cx - r, cy - r), (cx + r, cy + r), col, -1)
    elif sh == 'triangle':
        cv2.fillPoly(img, [np.array([(cx, cy - r), (cx - r, cy + r), (cx + r, cy + r)], np.int32)], col)
    else:
        w = max(2, r // 2)
        cv2.rectangle(img, (cx - r, cy - w), (cx + r, cy + w), col, -1); cv2.rectangle(img, (cx - w, cy - r), (cx + w, cy + r), col, -1)
    return img

def make(n, rng, unseen=False, holdout=HOLDOUT):
    """n images, their captions and labels (shape, color, size). unseen=True: only the held-out color/shape pairs."""
    X, caps, labels = [], [], []
    while len(X) < n:
        sh, c, s = SHAPES[rng.integers(4)], list(COLORS)[rng.integers(4)], SIZES[rng.integers(2)]
        if ((sh, c) in holdout) != unseen:
            continue
        X.append(draw(sh, c, s, rng)); labels.append((sh, c, s))
        caps.append(TEMPLATES[rng.integers(len(TEMPLATES))].format(s=s, c=c, sh=sh))
    return np.array(X), caps, labels

def prep(X):
    return np.stack([cv2.resize(x, (24, 24), interpolation=cv2.INTER_AREA) for x in X]).astype(np.float32).reshape(len(X), -1) / 255 - 0.5

def prep_chroma(X):
    out = []
    for x in X:
        xf = x.astype(np.float32) / 255
        chroma = cv2.resize(xf.max(2) - xf.min(2), (24, 24), interpolation=cv2.INTER_AREA)
        thumb = cv2.resize(xf, (8, 8), interpolation=cv2.INTER_AREA)
        out.append(np.concatenate([chroma.ravel() - 0.3, thumb.ravel() - 0.5]))
    return np.array(out, np.float32)

class Vocab:
    def __init__(self, sentences):
        words = sorted({w for s in sentences for w in s.split()})
        self.idx = {w: i + 1 for i, w in enumerate(words)}   # 0 = unknown
    def encode(self, s):
        return [self.idx.get(w, 0) for w in s.split()]

def _norm(z):
    n = np.linalg.norm(z, axis=1, keepdims=True); return z / n, n

def _norm_back(u, n, du):
    return (du - u * (u * du).sum(1, keepdims=True)) / n

class TinyCLIP:
    def __init__(self, vocab, prep=prep, d_in=1728, hidden=256, d=32, d_word=32, seed=0, bias=-5.0, scale=10.0):
        r = np.random.default_rng(seed); self.vocab, self.prep = vocab, prep
        V = len(vocab.idx) + 1
        self.p = {'W1': r.normal(0, np.sqrt(2 / d_in), (d_in, hidden)).astype(np.float32), 'b1': np.zeros(hidden, np.float32),
                  'W2': r.normal(0, np.sqrt(1 / hidden), (hidden, d)).astype(np.float32), 'b2': np.zeros(d, np.float32),
                  'E': r.normal(0, 0.1, (V, d_word)).astype(np.float32),
                  'W3': r.normal(0, np.sqrt(1 / d_word), (d_word, d)).astype(np.float32), 'b3': np.zeros(d, np.float32),
                  't': np.array(np.log(scale), np.float32), 'bias': np.array(bias, np.float32)}
        self.m = {k: np.zeros_like(v) for k, v in self.p.items()}; self.v = {k: np.zeros_like(v) for k, v in self.p.items()}; self.k = 0

    def encode_image(self, X):
        x = self.prep(X).reshape(len(X), -1)
        h = np.maximum(x @ self.p['W1'] + self.p['b1'], 0)
        return _norm(h @ self.p['W2'] + self.p['b2'])[0]

    def encode_text(self, sentences):
        ids = [self.vocab.encode(s) for s in sentences]
        e = np.stack([self.p['E'][i].mean(0) for i in ids])
        return _norm(e @ self.p['W3'] + self.p['b3'])[0]

    def loss_grad(self, X, caps, kind='softmax'):
        p = self.p; B = len(X)
        x = self.prep(X).reshape(B, -1); a = x @ p['W1'] + p['b1']; h = np.maximum(a, 0); zi = h @ p['W2'] + p['b2']; U, nu = _norm(zi)
        ids = [self.vocab.encode(c) for c in caps]; e = np.stack([p['E'][i].mean(0) for i in ids]); zt = e @ p['W3'] + p['b3']; Vt, nv = _norm(zt)
        s = float(np.exp(p['t'])); C = U @ Vt.T
        if kind == 'softmax':
            L = s * C
            def sm(A):
                A = A - A.max(1, keepdims=True); E_ = np.exp(A); return E_ / E_.sum(1, keepdims=True)
            P1, P2 = sm(L), sm(L.T); I = np.eye(B)
            loss = (-np.log(np.diag(P1) + 1e-12).mean() - np.log(np.diag(P2) + 1e-12).mean()) / 2
            G = ((P1 - I) + (P2 - I).T) / (2 * B); gbias = 0.0
        else:
            Z = s * C + p['bias']; Y = 2 * np.eye(B) - 1
            loss = np.logaddexp(0, -Y * Z).sum() / B
            G = -Y / (1 + np.exp(Y * Z)) / B; gbias = G.sum()
        g = {}
        g['t'] = np.array((G * C).sum() * s, np.float32); g['bias'] = np.array(gbias, np.float32)
        dU = s * G @ Vt; dV = s * G.T @ U
        dzi = _norm_back(U, nu, dU); g['W2'] = h.T @ dzi; g['b2'] = dzi.sum(0)
        da = (dzi @ p['W2'].T) * (a > 0); g['W1'] = x.T @ da; g['b1'] = da.sum(0)
        dzt = _norm_back(Vt, nv, dV); g['W3'] = e.T @ dzt; g['b3'] = dzt.sum(0)
        de = dzt @ p['W3'].T; gE = np.zeros_like(p['E'])
        for r_, i in enumerate(ids):
            np.add.at(gE, i, de[r_] / len(i))
        g['E'] = gE
        return float(loss), g

    def adam(self, g, lr=2e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.k += 1
        for k in self.p:
            self.m[k] = b1 * self.m[k] + (1 - b1) * g[k]; self.v[k] = b2 * self.v[k] + (1 - b2) * g[k] ** 2
            mh = self.m[k] / (1 - b1 ** self.k); vh = self.v[k] / (1 - b2 ** self.k)
            self.p[k] = (self.p[k] - lr * mh / (np.sqrt(vh) + eps)).astype(np.float32)
        self.p['t'] = np.minimum(self.p['t'], np.float32(np.log(100)))

def train(m, X, caps, epochs=15, B=128, kind='softmax', seed=0, log=None):
    rng = np.random.default_rng(seed); n = len(X)
    for ep in range(epochs):
        idx = rng.permutation(n); ls = []
        for k in range(0, n - B + 1, B):
            j = idx[k:k + B]
            loss, g = m.loss_grad(X[j], [caps[i] for i in j], kind); m.adam(g); ls.append(loss)
        if log: log(ep, float(np.mean(ls)), float(np.exp(m.p['t'])))
    return m

def zeroshot(m, X, labels, templates=('a {s} {c} {sh}',)):
    cl = classes()
    T = np.stack([m.encode_text([t.format(s=s, c=c, sh=sh) for (sh, c, s) in cl]) for t in templates]).mean(0)
    T = T / np.linalg.norm(T, axis=1, keepdims=True)
    pred = (m.encode_image(X) @ T.T).argmax(1)
    y = np.array([cl.index(l) for l in labels])
    return (pred == y).mean()

import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        pg = await b.new_page(viewport={'width': 1300, 'height': 1000})
        await pg.goto('file:///home/claude/build/site/index.html#/m0/s/8.2'); await pg.wait_for_timeout(600)
        await pg.click('text=פענח את הנוסחה'); await pg.wait_for_timeout(300)
        el = await pg.query_selector('.tex'); await el.scroll_into_view_if_needed()
        await pg.hover('.dec-list .row >> nth=1'); await pg.wait_for_timeout(200)
        await pg.screenshot(path='/home/claude/build/s_dec.png')
        await pg.goto('file:///home/claude/build/site/index.html#/m0/ex/3'); await pg.wait_for_timeout(600)
        await pg.click('#ex-3\\.2 >> text=רמז'); await pg.click('#ex-3\\.2 >> text=הצג פתרון')
        await pg.screenshot(path='/home/claude/build/s_ex.png', full_page=False)
        await pg.goto('file:///home/claude/build/site/index.html#/m0/s/1.2'); await pg.wait_for_timeout(600)
        t = await pg.query_selector('.orig table'); await t.scroll_into_view_if_needed(); await pg.hover('.orig table tr >> nth=2'); await pg.wait_for_timeout(200)
        await pg.screenshot(path='/home/claude/build/s_tbl.png')
        await b.close()
asyncio.run(main())

# Adds section 7.4 (an ADDITION, not in the course material) to module 6, chapter 7: background work in a windowed
# program. Idempotent. Code verified and outputs filled by standalone_m6.py.
import json
C1 = open('/home/claude/build/src_added/s74/c1.py', encoding='utf8').read().strip() + '\n'
C2 = open('/home/claude/build/src_added/s74/c2.py', encoding='utf8').read().strip() + '\n'
P = lambda i, t: {'type': 'p', 'text': t, 'id': 'm6-x74' + i}
def T(i, rows):
    return {'type': 'table', 'header': True, 'id': 'm6-x74' + i, 'rows': [[[{'type': 'p', 'text': 'מה היא עושה'}], [{'type': 'p', 'text': 'שורה'}]]] +
            [[[{'type': 'p', 'text': a}], [{'type': 'code', 'text': b, 'inline': True}]] for b, a in rows]}
blocks = [
 P('p1', 'שתי דוגמאות. הראשונה בפייתון רגיל, בלי ספריית ממשק: "חלון" מדומה שמטפל באירוע כל שישים בשנייה, ומודד את הפער הארוך ביותר בין שני אירועים — פעם כשהסריקה רצה בתוכו, ופעם בתהליכון נפרד. השנייה — אותו רעיון בחלון אמיתי של Qt. שתי הדוגמאות:'),
 P('h1', '**חלק 1: חלון מדומה — קפוא מול מגיב, וביטול:**'),
 {'type': 'code', 'lang': 'python', 'id': 'm6-x74c1', 'text': C1},
 P('e1', '**הסבר שורה אחר שורה:**'),
 T('t1', [('def scan(n_frames, report, should_stop):', 'מנוע מדומה: 20 אלפיות שנייה של עבודה לכל פריים. שני דברים שכל מנוע שרץ ברקע חייב: לבדוק בכל פריים אם ביקשו לעצור, ולדווח התקדמות — לא בכל פריים, אלא כל עשרה.'),
          ('def window_loop(seconds, on_start, poll=None):', 'חלון מדומה: לולאה שמטפלת באירוע כל 1/60 שנייה — כמו ציור, תזוזת עכבר או לחיצה — ומודדת את הפער הארוך ביותר בין שני אירועים. בחלון אמיתי, פער של יותר מעשירית שנייה כבר מורגש, ואחרי כמה שניות מערכת ההפעלה כותבת "לא מגיב".'),
          ('on_start()', 'הלחיצה על "התחל סריקה". מה שהפונקציה הזו עושה קורה <b>בתוך</b> הלולאה של החלון — וכל עוד היא לא חזרה, הלולאה לא ממשיכה.'),
          ('worst = window_loop(1.0, lambda: scan(100', 'נאיבי: הסריקה עצמה היא מה שקורה בלחיצה. מאה פריימים כפול 20 אלפיות — שתי שניות שבהן החלון לא טיפל בשום אירוע.'),
          ('msgs, stop, seen = queue.Queue(), threading.Event(), []', 'שלושה כלים: תור הודעות מהתהליכון לחלון, דגל עצירה (<code class="ltr">Event</code>) שהחלון מרים והתהליכון בודק, ורשימה של מה שהחלון קיבל.'),
          ('def start():', 'נדרש: הלחיצה רק <b>מפעילה</b> תהליכון וחוזרת מיד. התהליכון מריץ את הסריקה, ושולח לתור הודעת התקדמות כל עשרה פריימים והודעת סיום בסוף.'),
          ('def poll():', 'בכל סיבוב של הלולאה החלון קורא את מה שהצטבר בתור — ורק החלון נוגע בתצוגה. התהליכון לעולם לא מצייר בעצמו.'),
          ('res = []', 'ביטול: תהליכון של 1000 פריימים, ואחרי 0.3 שנייה מרימים את הדגל. התהליכון רואה אותו בפריים הבא ויוצא — בלי תוצאות.'),
          ('th.join()', '<code class="ltr">join</code> — מחכים שהתהליכון באמת הסתיים, לפני שממשיכים. כאן ההמתנה קצרה, כי הדגל נבדק בכל פריים.')]),
 P('h2', '**חלק 2: אותו רעיון בחלון אמיתי (Qt):**'),
 {'type': 'code', 'lang': 'python', 'id': 'm6-x74c2', 'text': C2},
 P('e2', '**הסבר שורה אחר שורה:**'),
 T('t2', [('class Worker(QThread):', 'תהליכון של Qt. מה שבתוך <code class="ltr">run</code> רץ בתהליכון החדש.'),
          ('progress = Signal(int, int)', 'אותות (Signal): הדרך הבטוחה להעביר מידע מהתהליכון לחלון. כשמחברים אות לפונקציה של החלון, Qt מריץ את הפונקציה <b>בתהליכון של החלון</b> — בדיוק התור והקריאה מהחלק הראשון, רק אוטומטית.'),
          ('def run(self):', 'הלולאה של העבודה: בדיקת הדגל בכל פריים, ודיווח כל עשרה פריימים דרך האות.'),
          ('class Window(QWidget):', 'החלון: תווית, פס התקדמות, וכפתורי התחלה וביטול.'),
          ('def start(self):', 'הלחיצה: יוצרים תהליכון, מחברים את האותות שלו לפס ולתווית, ו־<code class="ltr">start()</code> — שחוזרת מיד.'),
          ('def stop(self):', 'ביטול: מרימים את הדגל ומחכים לתהליכון (<code class="ltr">wait</code>, כמו <code class="ltr">join</code>).'),
          ('app = QApplication(sys.argv)', 'ההרצה: <code class="ltr">app.exec()</code> היא הלולאה של החלון — זו שהחלק הראשון דימה.')]),
 P('r1', 'אותו מבנה בדיוק — תהליכון, אותות התקדמות, דגל ביטול — נמצא בקוד המוכן של האפליקציה במודול 8, סעיף 8.2.'),
]
p = '/home/claude/build/site/content/m6.js'; s = open(p, encoding='utf8').read(); k = s.index('= {', 40) + 2
d = json.loads(s[k:].rstrip().rstrip(';'))
ch = [c for c in d['chapters'] if c['n'] == 7][0]
old = {b['id']: b.get('output') for x in ch['sections'] if x['id'] == '7.4' for b in x['blocks'] if b['type'] == 'code'}
for b in blocks:
    if b['type'] == 'code' and old.get(b['id']): b['output'] = old[b['id']]
sec = {'id': '7.4', 'title': 'עבודה ברקע בתוכנה עם חלון', 'added': 'אפליקציה עם חלון, שסורקת סרטון בלי לקפוא (מודול 8, אבן דרך 6).',
       'heading': {'type': 'h3', 'text': '7.4 עבודה ברקע בתוכנה עם חלון', 'id': 'm6-x74h'}, 'blocks': blocks}
ch['sections'] = [x for x in ch['sections'] if x['id'] != '7.4'] + [sec]
open(p, 'w', encoding='utf8').write(s[:k] + json.dumps(d, ensure_ascii=False) + ';\n')
print('7.4 written')

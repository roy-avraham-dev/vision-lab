import json,re,sys
tag=sys.argv[1]
d=json.load(open(f'out/{tag}.json'))['blocks']; v=json.load(open(f'out/{tag}_vis.json'))
pat=re.compile(r'(\(\S+ ,|‖‖|(^|\s)[.,:;][^\s.]|\d− |= [a-zA-Z] \(|\s,\S|\(,|[א-ת]\(|\)[א-ת]|ᵀ = |\s\)|\(\s|[⁻¹²ᵀ]+[A-Za-z]\b|\d+ ,\d+\)|\s=\s*$|^\s*=|[a-z][א-ת]|\*\*[^*]+\*\*[^\s.,:)]|\.\.|[^\s(]\*\*\S|\d\)[^\s.,:;)\]]|\] [א-ת]+\.$|^\S+ [א-ת]+ \S+\)| \(\d+ ,|[²³] · )')
for i,b in enumerate(d):
    ts=[]
    if b['type'] in ('p','li','quote','caption','h2','h3'): ts=[b['text']]
    if b['type']=='table': ts=[s['text'] for r in b['rows'] for c in r for s in c if s['type']=='p']
    for t in ts:
        if pat.search(t) and re.search('[א-ת]',t):
            print(f'#{i} [{b["type"]} {b.get("dir","")}] {t}')
            break

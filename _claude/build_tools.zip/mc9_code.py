import numpy as np

K = np.array([[1000, 0, 640], [0, 1000, 360], [0, 0, 1.0]])

def stereo(B):
    # two parallel cameras looking north (world y), at height 1.5, B metres apart
    R = np.array([[1, 0, 0], [0, 0, -1], [0, 1, 0]], float)      # x right, y down, z forward = world (x, -z, y)
    Ps = []
    for cx in (-B / 2, B / 2):
        C = np.array([cx, 0, 1.5])
        Ps.append(K @ np.c_[R, -R @ C])
    return Ps

def triangulate(P1, P2, a, b):
    A = np.array([a[0] * P1[2] - P1[0], a[1] * P1[2] - P1[1], b[0] * P2[2] - P2[0], b[1] * P2[2] - P2[1]])
    X = np.linalg.svd(A)[2][-1]
    return X[:3] / X[3]

def proj(P, X):
    p = P @ np.append(X, 1)
    return p[:2] / p[2]

rng = np.random.default_rng(0)
for B in (0.2, 1.0):
    P1, P2 = stereo(B)
    for Z in (5, 10, 20, 40):
        errs = []
        for _ in range(300):
            X = np.array([rng.uniform(-1, 1), Z, rng.uniform(0.5, 2.5)])
            a = proj(P1, X) + rng.normal(0, 0.5, 2)
            b = proj(P2, X) + rng.normal(0, 0.5, 2)
            errs.append(abs(triangulate(P1, P2, a, b)[1] - Z))
        formula = Z ** 2 / (1000 * B) * 0.5 * np.sqrt(2) * np.sqrt(2 / np.pi)   # |error| of a disparity with noise 0.5*sqrt(2)
        print(f"B={B:.1f}  Z={Z:2d}  simulated {np.mean(errs):7.3f} m   formula {formula:7.3f} m")

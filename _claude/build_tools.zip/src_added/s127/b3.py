# ---- 3. the unknown height (= the scale) from two independent cues
g_lines = [ground(p, K, R) for p in lines_px]
d = g_lines[1][-1] - g_lines[1][0]; d /= np.linalg.norm(d)          # the road direction on the ground
nrm = np.array([-d[1], d[0]])                                        # across the road
offs = [np.median(g @ nrm) for g in g_lines]                         # where each lane line crosses the normal
lane_w = np.median(np.abs(np.diff(sorted(offs))))
widths = [0.5 * (np.linalg.norm(gc[0] - gc[1]) + np.linalg.norm(gc[3] - gc[2])) for gc in (ground(c, K, R) for c in cars_px)]
h_lane = 3.5 / lane_w                       # a lane is about 3.5 m wide
h_car = 1.8 / np.median(widths)             # a car is about 1.8 m wide
h_est = np.mean([h_lane, h_car])
print(f"height from the lanes: {h_lane:.1f} m, from the cars: {h_car:.1f} m (true {h_true:.0f})")
print(f"the two cues differ by {abs(h_lane - h_car) / h_est:.0%}")

# ---- 4. speed: the foot point on the ground, in metres, over one second
g = ground(track_px, K, R) * h_est
speed = np.linalg.norm(g[-1] - g[0]) / 1.0
print(f"speed: {speed * 3.6:.0f} km/h (true 72), error {abs(speed * 3.6 - 72) / 72:.0%}")

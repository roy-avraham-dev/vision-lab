# ---- 1. the vanishing point of the lane lines -> the horizon row
def fit_line(pts):
    """a line a*x + b*y = c through noisy points (total least squares)"""
    m = pts.mean(axis=0)
    _, _, Vt = np.linalg.svd(pts - m)
    a, b = Vt[-1]                       # the normal: the direction of least spread
    return np.array([a, b, a * m[0] + b * m[1]])

L3 = np.array([fit_line(p) for p in lines_px])
v = np.linalg.lstsq(L3[:, :2], L3[:, 2], rcond=None)[0]   # the point closest to all lines
print("vanishing point:", v.round(1))

# ---- 2. for every candidate f: pitch from the horizon, then the cars' shape on the ground
def ground(uv, K, R):
    """pixel -> ground, for a camera at height 1 (so the result is in units of the unknown height)"""
    rays = np.c_[np.asarray(uv, float), np.ones(len(uv))] @ np.linalg.inv(K).T @ R
    return rays[:, :2] * (-1.0 / rays[:, 2:3])

def setup(f):
    pitch = np.degrees(np.arctan2(H / 2 - v[1], f))     # horizon row = cy - f*tan(pitch)
    return camera(f, pitch, 0.0), pitch                 # yaw 0: the ground map comes out rotated, which changes no length

def car_ratio(f):
    (K, R), _ = setup(f)
    ratios = []
    for c in cars_px:
        g = ground(c, K, R)
        length = np.linalg.norm(g[0] - g[3]) + np.linalg.norm(g[1] - g[2])
        width = np.linalg.norm(g[0] - g[1]) + np.linalg.norm(g[3] - g[2])
        ratios.append(length / width)
    return np.median(ratios)

fs = np.arange(400, 3001, 10.0)
r = np.array([car_ratio(f) for f in fs])
f_est = fs[np.argmin(np.abs(r - 2.5))]          # a typical car: 4.5 m long, 1.8 m wide
(K, R), pitch_est = setup(f_est)
print(f"f: {f_est:.0f} (true {f_true:.0f})   pitch: {pitch_est:.1f} deg (true {pitch_true:.1f})")

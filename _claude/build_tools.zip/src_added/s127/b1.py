import numpy as np

W, H = 1280, 720                       # image size
f_true, pitch_true, yaw_true, h_true = 1100.0, 40.0, 25.0, 80.0   # unknown to the system

def camera(f, pitch_deg, yaw_deg):
    """K and R for a camera with no roll: looks along yaw (0 = north), tilted down by pitch."""
    K = np.array([[f, 0, W / 2], [0, f, H / 2], [0, 0, 1.0]])
    p, y = np.radians(pitch_deg), np.radians(yaw_deg)
    fwd = np.array([np.sin(y) * np.cos(p), np.cos(y) * np.cos(p), -np.sin(p)])
    right = np.array([np.cos(y), -np.sin(y), 0.0])
    down = np.cross(fwd, right)
    return K, np.vstack([right, down, fwd])          # rows: camera axes in world coordinates

def project(K, R, C, P):
    q = (np.asarray(P, float) - C) @ R.T @ K.T
    return q[:, :2] / q[:, 2:3]

rng = np.random.default_rng(1)
K0, R0 = camera(f_true, pitch_true, yaw_true)
C0 = np.array([0, 0, h_true])

# the road runs north-east (40 deg from north); three lane lines, 3.6 m apart
road = np.radians(40)
u = np.array([np.sin(road), np.cos(road), 0])        # along the road
n = np.array([np.cos(road), -np.sin(road), 0])       # across the road
base = 95 * np.array([np.sin(np.radians(25)), np.cos(np.radians(25)), 0])   # a point on the road, ahead of the camera
lines_px = []
for k in (-1, 0, 1):
    pts = base + k * 3.6 * n + np.outer(np.linspace(-35, 35, 40), u)
    lines_px.append(project(K0, R0, C0, pts) + rng.normal(0, 0.7, (40, 2)))

# ten cars in the two lanes; each car's footprint (4 corners) as a segmentation outline would give it
cars_px = []
for i in range(10):
    L, Wd = rng.normal(4.5, 0.2), rng.normal(1.8, 0.06)
    c = base + (i % 2 - 0.5) * 3.6 * n + (-24 + 5.5 * i) * u
    corners = [c + a * L / 2 * u + b * Wd / 2 * n for a, b in ((1, 1), (1, -1), (-1, -1), (-1, 1))]
    cars_px.append(project(K0, R0, C0, corners) + rng.normal(0, 0.7, (4, 2)))

# one car drives along the road at 72 km/h (20 m/s); its foot point in 31 frames (one second at 30 fps)
foot0 = base - 0.5 * 3.6 * n - 10 * u
track_px = project(K0, R0, C0, foot0 + np.outer(np.arange(31) / 30 * 20.0, u)) + rng.normal(0, 0.7, (31, 2))



allpx = np.vstack(lines_px + cars_px + [track_px])
print("pixels x:", allpx[:, 0].min().round(), "to", allpx[:, 0].max().round(), " y:", allpx[:, 1].min().round(), "to", allpx[:, 1].max().round())

import threading, queue, time

def scan(n_frames, report, should_stop):
    """a stand-in for the engine: 0.02 s of work per frame"""
    for i in range(n_frames):
        if should_stop():
            return None                                  # cancelled: no results
        time.sleep(0.02)                                 # the detector, the tracker, ...
        if i % 10 == 0:
            report(i + 1, n_frames)
    return f"results for {n_frames} frames"

def window_loop(seconds, on_start, poll=None):
    """a tiny 'window': handles one event every 1/60 s, and measures the longest gap between two events"""
    t0 = last = time.perf_counter()
    worst, started = 0.0, False
    while time.perf_counter() - t0 < seconds:
        if not started:
            on_start()                                   # the user clicked "Start scan"
            started = True
        if poll:
            poll()                                       # read the messages the worker sent
        now = time.perf_counter()
        worst, last = max(worst, now - last), now
        time.sleep(1 / 60)
    return worst

# 1. naive: the scan runs inside the click handler
worst = window_loop(1.0, lambda: scan(100, lambda d, t: None, lambda: False))
print(f"naive:  the window handled no event for {worst:.2f} s")

# 2. a worker thread; the window only reads messages from a queue
msgs, stop, seen = queue.Queue(), threading.Event(), []
def start():
    work = lambda: msgs.put(("done", scan(100, lambda d, t: msgs.put(("progress", d, t)), stop.is_set)))
    threading.Thread(target=work, daemon=True).start()
def poll():
    while not msgs.empty():
        seen.append(msgs.get())
worst = window_loop(2.5, start, poll)
n_prog = sum(1 for m in seen if m[0] == "progress")
print(f"worker: longest gap {worst * 1000:.0f} ms; {n_prog} progress messages; then '{seen[-1][0]}': {seen[-1][1]}")

# 3. cancel: the worker checks the flag in every frame
res = []
th = threading.Thread(target=lambda: res.append(scan(1000, lambda d, t: None, stop.is_set)))
t = time.perf_counter()
th.start()
time.sleep(0.3)
stop.set()                                               # the user clicked "Cancel"
th.join()
print(f"cancel: stopped {(time.perf_counter() - t - 0.3) * 1000:.0f} ms after the click; result = {res[0]}")

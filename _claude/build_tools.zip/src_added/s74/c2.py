import sys, time
from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QProgressBar, QLabel

class Worker(QThread):
    progress = Signal(int, int)
    done = Signal(str)

    def __init__(self):
        super().__init__()
        self.stop_requested = False

    def run(self):                                       # runs in the new thread
        for i in range(200):
            if self.stop_requested:
                return
            time.sleep(0.02)                             # the work of one frame
            if i % 10 == 0:
                self.progress.emit(i + 1, 200)
        self.done.emit("הסריקה הסתיימה")

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.text, self.bar = QLabel("מוכן"), QProgressBar()
        self.go, self.cancel = QPushButton("התחל סריקה"), QPushButton("ביטול")
        lay = QVBoxLayout(self)
        for w in (self.text, self.bar, self.go, self.cancel):
            lay.addWidget(w)
        self.go.clicked.connect(self.start)
        self.cancel.clicked.connect(self.stop)
        self.worker = None

    def start(self):
        self.worker = Worker()
        self.worker.progress.connect(lambda d, t: (self.bar.setMaximum(t), self.bar.setValue(d)))
        self.worker.done.connect(self.text.setText)
        self.worker.start()                              # returns at once: the window keeps handling events
        self.text.setText("סורק…")

    def stop(self):
        if self.worker:
            self.worker.stop_requested = True
            self.worker.wait()                           # the worker notices the flag within one frame
            self.text.setText("בוטל")

app = QApplication(sys.argv)
win = Window()
win.show()
sys.exit(app.exec())

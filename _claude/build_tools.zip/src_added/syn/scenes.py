import sys; sys.path.insert(0, '/home/claude/build/src_added/syn')
from render import *
out = sys.argv[1]; which = sys.argv[2:] or ['s1_nadir', 's2_tilted', 's3_climb', 's4_zoom', 's5_desert']
def parked(i, x, y, col=(235, 235, 235)): return {'id': i, 'type': 'car', 'L': 4.5, 'W': 1.8, 'col': col, 'pos': lambda t, x=x, y=y: (x, y, 0.0, 0.0)}
S = {}
r = np.random.default_rng(11); V = highway_cars(r, 0.0, 34, 0, 700) + [parked(99, 262, 9.6)]
S['s1_nadir'] = dict(seed=1, ground='road', extent=(0, 700, -60, 60), roads=[(0.0, 0, 700)], rocks=[(900, 0, 700, -60, 60)], dur=20, vehicles=V,
                     cam=lambda t: (np.array([200 + 6 * t, 0.0, 80.0]), 90.0, 0.0, 1100.0))
r = np.random.default_rng(12); V = highway_cars(r, 0.0, 30, 100, 600) + [parked(99, 352, -9.6)]
S['s2_tilted'] = dict(seed=2, ground='road', extent=(100, 600, -150, 90), roads=[(0.0, 100, 600)], rocks=[(1500, 100, 600, -150, 90)], dur=20, vehicles=V,
                      cam=lambda t: (np.array([290 + 1.0 * t, -45.0, 70.0]), 45.0, 40.0, 1100.0))
r = np.random.default_rng(13); V = highway_cars(r, 0.0, 34, 0, 800) + [parked(99, 330, 9.6)]
S['s3_climb'] = dict(seed=3, ground='road', extent=(0, 800, -90, 170), roads=[(0.0, 0, 800)], rocks=[(2000, 0, 800, -90, 170)], dur=20, vehicles=V,
                     cam=lambda t: (np.array([300 + 3 * t, -25.0, 50 + 7.5 * t]), 70.0, 0.0, 1100.0))
r = np.random.default_rng(14); V = highway_cars(r, 0.0, 30, 100, 600) + [parked(99, 330, 9.6)]
S['s4_zoom'] = dict(seed=4, ground='road', extent=(100, 600, -160, 120), roads=[(0.0, 100, 600)], rocks=[(1500, 100, 600, -160, 120)], dur=20, vehicles=V,
                    cam=lambda t: (np.array([300.0, -55.0, 90.0]), 60.0, 20.0, 1100.0 * (1 if t < 6 else 2 if t > 9 else 1 + (t - 6) / 3)))
trk = lambda x: 15 * np.sin(np.asarray(x) / 40.0)
xs = np.arange(0, 900, 0.05); ys = trk(xs); arc = np.r_[0, np.cumsum(np.hypot(np.diff(xs), np.diff(ys)))]
def on_track(t, s0=160.0, v=11.1):
    s = s0 + v * t; x = np.interp(s, arc, xs); y = trk(x); hd = np.arctan2(15 / 40 * np.cos(x / 40), 1.0); return x, y, hd, v
V = [{'id': 1, 'type': 'car', 'L': 4.6, 'W': 1.85, 'col': (190, 110, 40), 'pos': on_track}, parked(2, 248, 12)]
S['s5_desert'] = dict(seed=5, ground='sand', extent=(50, 600, -80, 90), rocks=[(650, 50, 280, -80, 90)], track=trk, dur=20, vehicles=V,
                      cam=lambda t: (np.array([170 + 9 * t, 5.0, 70.0]), 90.0, 0.0, 1100.0))
for k in which:
    print(k, render(k, S[k], out), flush=True)

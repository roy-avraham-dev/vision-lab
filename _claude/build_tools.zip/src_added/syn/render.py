# Synthetic drone clips with exact ground truth, for module 8. Flat ground, pinhole camera with no roll.
import numpy as np, cv2, csv, json, subprocess, sys, os
W, H, FPS = 1280, 720, 30
RES = 0.1                                   # metres per map pixel
rng0 = np.random.default_rng(0)

def camera_R(pitch_deg, yaw_deg):
    p, y = np.radians(pitch_deg), np.radians(yaw_deg)
    fwd = np.array([np.sin(y) * np.cos(p), np.cos(y) * np.cos(p), -np.sin(p)])
    right = np.array([np.cos(y), -np.sin(y), 0.0]); down = np.cross(fwd, right)
    return np.vstack([right, down, fwd])

def noise(h, w, scale, rng):
    small = rng.random((max(2, h // scale), max(2, w // scale))).astype(np.float32)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_CUBIC)

def make_map(kind, X0, X1, Y0, Y1, rng):
    w, h = int((X1 - X0) / RES), int((Y1 - Y0) / RES)
    if kind == 'road':
        base = np.array([95, 135, 105], np.float32)       # BGR grass/scrub
        g = 0.75 + 0.35 * noise(h, w, 400, rng) + 0.15 * noise(h, w, 25, rng) + 0.08 * noise(h, w, 4, rng)
    else:
        base = np.array([140, 190, 215], np.float32)       # sand
        g = 0.92 + 0.08 * noise(h, w, 500, rng) + 0.02 * noise(h, w, 6, rng)
    img = np.clip(base[None, None, :] * g[..., None], 0, 255).astype(np.uint8)
    return img, w, h

def to_px(X, Y, X0, Y1): return ((X - X0) / RES, (Y1 - Y) / RES)

def draw_road(img, X0, Y1, y_c, x_a, x_b, lanes=4, lane_w=3.6, dash=(3.0, 9.0)):
    """a straight east-west road at north = y_c (metres), with `lanes` lanes"""
    half = lanes * lane_w / 2
    a = to_px(x_a, y_c + half + 0.6, X0, Y1); b = to_px(x_b, y_c - half - 0.6, X0, Y1)
    cv2.rectangle(img, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])), (88, 90, 92), -1)
    for k in range(lanes + 1):
        yy = y_c - half + k * lane_w; py = int(to_px(0, yy, X0, Y1)[1])
        if k in (0, lanes):                      # solid edge lines
            cv2.line(img, (int(a[0]), py), (int(b[0]), py), (235, 235, 235), 2)
        elif k == lanes // 2:                    # double centre line
            cv2.line(img, (int(a[0]), py - 2), (int(b[0]), py - 2), (60, 200, 230), 2); cv2.line(img, (int(a[0]), py + 2), (int(b[0]), py + 2), (60, 200, 230), 2)
        else:                                    # dashed lane lines
            x = x_a
            while x < x_b:
                p0 = to_px(x, yy, X0, Y1); p1 = to_px(min(x + dash[0], x_b), yy, X0, Y1)
                cv2.line(img, (int(p0[0]), int(p0[1])), (int(p1[0]), int(p1[1])), (235, 235, 235), 2); x += dash[0] + dash[1]

def rocks(img, X0, Y1, n, region, rng):
    xa, xb, ya, yb = region
    for _ in range(n):
        x, y = rng.uniform(xa, xb), rng.uniform(ya, yb); p = to_px(x, y, X0, Y1)
        r = int(rng.uniform(2, 9)); g0 = rng.uniform(45, 110); c = (int(g0 * rng.uniform(0.6, 0.9)), int(g0 * rng.uniform(0.9, 1.15)), int(g0 * rng.uniform(0.95, 1.25)))   # earthy BGR
        cv2.circle(img, (int(p[0]), int(p[1])), r, c, -1, cv2.LINE_AA)

def render(name, scene, out_dir):
    rng = np.random.default_rng(scene['seed'])
    X0, X1, Y0, Y1 = scene['extent']
    mp, mw, mh = make_map(scene['ground'], X0, X1, Y0, Y1, rng)
    for reg in scene.get('rocks', []): rocks(mp, X0, Y1, reg[0], reg[1:], rng)
    for r in scene.get('roads', []): draw_road(mp, X0, Y1, *r)
    if scene.get('track'):                                   # a winding dirt track
        xs = np.arange(X0, X1, 1.0); ys = scene['track'](xs)
        pts = np.array([to_px(x, y, X0, Y1) for x, y in zip(xs, ys)], np.int32)
        cv2.polylines(mp, [pts], False, (110, 150, 175), 40, cv2.LINE_AA)
    mp = cv2.GaussianBlur(mp, (3, 3), 0)
    N = int(scene['dur'] * FPS)
    vid = os.path.join(out_dir, name + '.mp4'); truth = open(os.path.join(out_dir, name + '_truth.csv'), 'w', newline='', encoding='utf-8')
    cam_f = open(os.path.join(out_dir, name + '_camera.csv'), 'w', newline='', encoding='utf-8')
    tw = csv.writer(truth); tw.writerow(['frame', 'time_s', 'vehicle_id', 'type', 'x1', 'y1', 'x2', 'y2', 'foot_x', 'foot_y', 'east_m', 'north_m', 'speed_kmh', 'length_m', 'width_m'])
    cw = csv.writer(cam_f); cw.writerow(['frame', 'time_s', 'cam_east_m', 'cam_north_m', 'height_m', 'pitch_deg', 'yaw_deg', 'focal_px'])
    ff = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '24', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', vid], stdin=subprocess.PIPE)
    vehicles = scene['vehicles']
    for fi in range(N):
        t = fi / FPS; C, pitch, yaw, f = scene['cam'](t)
        K = np.array([[f, 0, W / 2], [0, f, H / 2], [0, 0, 1.0]]); R = camera_R(pitch, yaw)
        M = np.array([[RES, 0, X0 - C[0]], [0, -RES, Y1 - C[1]], [0, 0, -C[2]]])
        Hm = K @ R @ M
        frame = cv2.warpPerspective(mp, Hm, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        cw.writerow([fi, round(t, 4), round(C[0], 3), round(C[1], 3), round(C[2], 3), round(pitch, 3), round(yaw, 3), round(f, 2)])
        for v in vehicles:
            x, y, hd, spd = v['pos'](t)
            u = np.array([np.cos(hd), np.sin(hd), 0]); n = np.array([-np.sin(hd), np.cos(hd), 0])
            c = np.array([x, y, 0.0]); L, Wd = v['L'], v['W']
            corners = np.array([c + a * L / 2 * u + b * Wd / 2 * n for a, b in ((1, 1), (1, -1), (-1, -1), (-1, 1))])
            q = (corners - C) @ R.T @ K.T
            if np.any(q[:, 2] <= 0.5): continue
            px = q[:, :2] / q[:, 2:3]
            x1, y1, x2, y2 = px[:, 0].min(), px[:, 1].min(), px[:, 0].max(), px[:, 1].max()
            if x2 < 0 or y2 < 0 or x1 >= W or y1 >= H: continue
            cv2.fillPoly(frame, [np.round(px * 16).astype(np.int32)], v['col'], cv2.LINE_AA, shift=4)
            wind = [c + a * L / 2 * u + b * Wd / 2 * n for a, b in ((0.1, 0.9), (0.1, -0.9), (-0.25, -0.9), (-0.25, 0.9))]
            qw = (np.array(wind) - C) @ R.T @ K.T; pw = qw[:, :2] / qw[:, 2:3]
            cv2.fillPoly(frame, [np.round(pw * 16).astype(np.int32)], tuple(int(0.45 * k) for k in v['col']), cv2.LINE_AA, shift=4)
            qc = (c - C) @ R.T @ K.T; fc = qc[:2] / qc[2]
            tw.writerow([fi, round(t, 4), v['id'], v['type'], round(max(x1, 0), 1), round(max(y1, 0), 1), round(min(x2, W - 1), 1), round(min(y2, H - 1), 1), round(fc[0], 2), round(fc[1], 2), round(x, 3), round(y, 3), round(spd * 3.6, 2), round(L, 2), round(Wd, 2)])
        if scene.get('sky_above'):
            hy = int(H / 2 - f * np.tan(np.radians(pitch)))
            if hy > 0: frame[:hy] = (230, 215, 195)
        frame = np.clip(frame.astype(np.int16) + np.random.default_rng(fi).normal(0, 2.0, frame.shape).astype(np.int16), 0, 255).astype(np.uint8)
        ff.stdin.write(frame.tobytes())
    ff.stdin.close(); ff.wait(); truth.close(); cam_f.close()
    return vid

def highway_cars(rng, y_c, n, x_a, x_b, lane_w=3.6, lanes=4):
    V = []; half = lanes * lane_w / 2
    for i in range(n):
        lane = int(rng.integers(lanes)); east = lane < lanes // 2            # southern lanes drive east
        yy = y_c - half + (lane + 0.5) * lane_w + rng.normal(0, 0.15)
        truck = rng.random() < 0.12
        L, Wd = (rng.uniform(10, 14), 2.5) if truck else (rng.normal(4.5, 0.25), rng.normal(1.8, 0.06))
        spd = rng.uniform(17, 25) if truck else rng.uniform(19, 30)        # m/s
        x0 = rng.uniform(x_a, x_b); col = (200, 200, 205) if truck else tuple(int(k) for k in rng.choice([[240, 240, 240], [40, 40, 40], [40, 40, 190], [170, 110, 40], [150, 150, 150], [60, 140, 210]]))
        def pos(t, x0=x0, yy=yy, s=spd, e=east):
            span = x_b - x_a; x = x_a + ((x0 - x_a) + (s * t if e else -s * t)) % span
            return x, yy, 0.0 if e else np.pi, s
        V.append({'id': i + 1, 'type': 'truck' if truck else 'car', 'L': L, 'W': Wd, 'col': col, 'pos': pos})
    return V

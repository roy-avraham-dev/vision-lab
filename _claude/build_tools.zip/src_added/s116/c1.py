import numpy as np

# ---- the input: foot points of 30 tracks, in pixels of a stabilised, roughly top-down image
rng = np.random.default_rng(3)
px_per_m_true = 9.0                                  # unknown to the system
road_deg_true = 35.0                                 # unknown too
a = np.radians(road_deg_true)
u_true = np.array([np.cos(a), np.sin(a)])            # along the road (image x right, y down)
n_true = np.array([-np.sin(a), np.cos(a)])           # across the road
lanes_m = np.array([-5.25, -1.75, 1.75, 5.25])       # four lanes, 3.5 m apart; two in each direction
tracks = []
for i in range(30):
    lane = rng.integers(4)
    direction = 1 if lane >= 2 else -1               # the two right lanes drive one way, the two left ones the other
    s0 = rng.uniform(-60, 20)
    t = np.arange(40) / 30                           # 40 frames at 30 fps
    along = direction * (s0 + rng.uniform(15, 25) * t)
    across = lanes_m[lane] + rng.normal(0, 0.25) + 0.1 * np.sin(2 * t + i)   # nobody drives exactly in the middle
    pts_m = np.outer(along, u_true) + np.outer(across, n_true)
    tracks.append(np.array([640, 360]) + pts_m * px_per_m_true + rng.normal(0, 1.0, (40, 2)))

# ---- 1. the road direction: the dominant direction of motion, regardless of its sign
ang = np.array([np.arctan2(*(tr[-1] - tr[0])[::-1]) for tr in tracks])   # angle of each track's displacement
c, s = np.cos(2 * ang).mean(), np.sin(2 * ang).mean()                    # double the angle: 35 and 215 become the same
road = 0.5 * np.arctan2(s, c)
u = np.array([np.cos(road), np.sin(road)]); n = np.array([-u[1], u[0]])
print(f"road direction: {np.degrees(road) % 180:.1f} deg (true {road_deg_true})")

# ---- 2. the lane width: lanes are evenly spaced, so the lateral positions repeat with one period
off = np.array([np.median(tr @ n) for tr in tracks])                     # one number per track: its lateral position
ws = np.arange(5, np.ptp(off), 0.1)                                      # candidate lane widths, in pixels
R = np.array([abs(np.exp(2j * np.pi * off / w).mean()) for w in ws])     # 1 = every track sits exactly on a grid of step w
peaks = [i for i in range(1, len(ws) - 1) if R[i] >= R[i - 1] and R[i] >= R[i + 1] and R[i] > 0.7 * R.max()]
lane_px = ws[peaks[-1]]                      # the widest strong peak: w/2, w/3 also fit the grid, 2w does not
print(f"lane width {lane_px:.1f} px (how well the tracks fit the grid: {R[peaks[-1]]:.2f})")

# ---- 3. the scale
m_per_px = 3.5 / lane_px
print(f"{m_per_px:.4f} m per pixel (true {1 / px_per_m_true:.4f}), error {abs(m_per_px * px_per_m_true - 1):.1%}")

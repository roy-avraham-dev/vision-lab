def speed_report(px_per_s, m_per_px=None, cue_gap=None, motion_ok=True, max_gap=0.10):
    """one of three answers: metres with a range, relative only, or nothing"""
    if not motion_ok:                                       # the camera motion is not reliable (sand, water, blur)
        return {"level": 3, "text": "not measured"}
    if m_per_px is None or cue_gap is None or cue_gap > max_gap:
        moving = px_per_s > 3                               # a few pixels per second = noise of a parked car
        return {"level": 2, "text": ("moving" if moving else "stopped") + f", {px_per_s:.1f} px/s"}
    v = px_per_s * m_per_px * 3.6
    spread = max(cue_gap, 0.03)                             # never claim better than 3%
    return {"level": 1, "text": f"{v:.0f} km/h ({v * (1 - spread):.0f} to {v * (1 + spread):.0f})"}

for case in [dict(px_per_s=181, m_per_px=0.1094, cue_gap=0.04),
             dict(px_per_s=181, m_per_px=0.1094, cue_gap=0.22),
             dict(px_per_s=1.5, m_per_px=None),
             dict(px_per_s=181, motion_ok=False)]:
    print(speed_report(**case))

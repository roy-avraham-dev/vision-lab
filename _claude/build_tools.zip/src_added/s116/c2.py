import numpy as np
import cv2

# the scale was measured once, at frame 0 (part 1). Then the drone descends: the image grows by 0.4% per frame
m_per_px0 = 0.1094                         # from the lanes, at frame 0
rng = np.random.default_rng(5)
ground_pts = rng.uniform(0, 1280, (200, 2)).astype(np.float32)   # texture points on the ground (corners, stones)
true_zoom = 1.004
scale_now, prev = 1.0, ground_pts
for t in range(1, 151):
    c = np.array([640, 360])
    cur = c + (ground_pts - c) * true_zoom ** t + rng.normal(0, 0.5, ground_pts.shape)
    cur[:30] += rng.normal(0, 25, (30, 2))          # 15% bad matches: points on moving cars, repeated texture
    cur = cur.astype(np.float32)
    A, inl = cv2.estimateAffinePartial2D(prev, cur, method=cv2.RANSAC)   # shift + rotation + ONE scale; RANSAC drops the bad matches
    scale_now *= np.sqrt(abs(np.linalg.det(A[:, :2])))                  # how much bigger the picture got in this step
    prev = cur
m_per_px = m_per_px0 / scale_now
true = m_per_px0 / true_zoom ** 150
print(f"after 150 frames the image is {scale_now:.3f} times bigger (true {true_zoom ** 150:.3f})")
print(f"{m_per_px:.4f} m per pixel now (true {true:.4f}), error {abs(m_per_px / true - 1):.2%}")

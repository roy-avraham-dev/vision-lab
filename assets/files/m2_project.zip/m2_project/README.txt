Module 2, chapter 12 project.
Put the three files in one folder and run:  python run_fashion.py
On a CPU, 30 epochs with augmentation take hours. For a first run set "epochs" in cfg to 3 or 4.
On Windows without a GPU, also try num_workers=0 in the DataLoader: on the course's test machine
(CPU only) the run with num_workers=2 did not finish 4 epochs in 30 minutes, and with num_workers=0
it took about 100 seconds per epoch (7 minutes in total, 90.0% validation / 89.4% test accuracy).
The run writes runs/<date>-<time>_<hash>/ with config.json, metrics.csv, best.pt, confusion.csv.

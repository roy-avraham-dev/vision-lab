# run_fashion.py
import os, random
import numpy as np
import torch
from torch import nn


def set_seed(seed):                                  # chapter 10
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class SmallCNN(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
        )
        self.head = nn.Sequential(
            nn.Flatten(), nn.Linear(64 * 7 * 7, 128), nn.ReLU(), nn.Linear(128, num_classes),
        )

    def forward(self, x):
        return self.head(self.features(x))



def main():
    import torch, torch.nn as nn
    from torch.utils.data import DataLoader, random_split
    from torchvision import datasets
    from torchvision.transforms import v2
    from trainer import Trainer

    cfg = {"seed": 0, "lr": 1e-3, "weight_decay": 0.05, "batch_size": 128,
           "epochs": 30, "warmup": 2, "patience": 5, "label_smoothing": 0.1, "model": "SmallCNN"}
    set_seed(cfg["seed"])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    norm = [v2.ToImage(), v2.ToDtype(torch.float32, scale=True), v2.Normalize([0.286], [0.353])]
    train_tf = v2.Compose([v2.RandomHorizontalFlip(), v2.RandomResizedCrop(28, scale=(0.85, 1.0))] + norm)
    test_tf = v2.Compose(norm)

    full = datasets.FashionMNIST("data", train=True, download=True, transform=train_tf)
    test_ds = datasets.FashionMNIST("data", train=False, download=True, transform=test_tf)
    g = torch.Generator().manual_seed(cfg["seed"])
    train_ds, val_idx = random_split(full, [54000, 6000], generator=g)
    val_ds = torch.utils.data.Subset(datasets.FashionMNIST("data", train=True, transform=test_tf), val_idx.indices)

    train_dl = DataLoader(train_ds, cfg["batch_size"], shuffle=True, generator=g, num_workers=2)
    val_dl = DataLoader(val_ds, 512)
    test_dl = DataLoader(test_ds, 512)

    model = SmallCNN()
    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    sched = torch.optim.lr_scheduler.SequentialLR(opt, [
        torch.optim.lr_scheduler.LinearLR(opt, start_factor=0.2, total_iters=cfg["warmup"]),
        torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg["epochs"] - cfg["warmup"]), ], milestones=[cfg["warmup"]])
    loss_fn = nn.CrossEntropyLoss(label_smoothing=cfg["label_smoothing"])

    trainer = Trainer(model, loss_fn, opt, sched, cfg, device)
    best = trainer.fit(train_dl, val_dl, cfg["epochs"])
    print("best val acc", best)
    trainer.report(test_dl, full.classes)

if __name__ == "__main__":
    main()
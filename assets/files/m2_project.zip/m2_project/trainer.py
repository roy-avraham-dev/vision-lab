# trainer.py — the project of module 2, chapter 12 (section 12.3)
import time
import numpy as np
import torch
from metrics import confusion_matrix, per_class_report, EarlyStopping, RunLogger

class Trainer:
    def __init__(self, model, loss_fn, optimizer, scheduler, cfg, device="cpu"):
        self.model = model.to(device)
        self.loss_fn, self.opt, self.sched = loss_fn, optimizer, scheduler
        self.cfg, self.device = cfg, device
        self.use_amp = device == "cuda" and cfg.get("amp", True)
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.use_amp)
        self.logger = RunLogger(cfg.get("runs_dir", "runs"), cfg)
        self.stopper = EarlyStopping(cfg.get("patience", 5), mode="max")

    def _train_epoch(self, dl):
        self.model.train()
        total, n = 0.0, 0
        for xb, yb in dl:
            xb, yb = xb.to(self.device), yb.to(self.device)
            self.opt.zero_grad()
            with torch.autocast(device_type=self.device, enabled=self.use_amp):
                loss = self.loss_fn(self.model(xb), yb)
            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.opt)
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.get("clip", 5.0))
            self.scaler.step(self.opt)
            self.scaler.update()
            total += loss.item() * len(yb)
            n += len(yb)
        return total / n

    @torch.no_grad()
    def predict(self, dl):
        self.model.eval()
        ys, ps, total = [], [], 0.0
        for xb, yb in dl:
            xb, yb = xb.to(self.device), yb.to(self.device)
            logits = self.model(xb)
            total += self.loss_fn(logits, yb).item() * len(yb)
            ys.append(yb.cpu().numpy())
            ps.append(logits.argmax(1).cpu().numpy())
        y, p = np.concatenate(ys), np.concatenate(ps)
        return total / len(y), y, p

    def save(self, path, epoch):
        torch.save({"model": self.model.state_dict(), "opt": self.opt.state_dict(),
                    "sched": self.sched.state_dict() if self.sched else None,
                    "epoch": epoch, "best": self.stopper.best, "cfg": self.cfg}, path)

    def load(self, path):
        ck = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ck["model"])
        self.opt.load_state_dict(ck["opt"])
        if self.sched and ck["sched"]:
            self.sched.load_state_dict(ck["sched"])
        return ck["epoch"]

    def fit(self, train_dl, val_dl, epochs):
        best_path = self.logger.dir / "best.pt"
        for ep in range(epochs):
            t0 = time.time()
            train_loss = self._train_epoch(train_dl)
            val_loss, y, p = self.predict(val_dl)
            val_acc = float((y == p).mean())
            lr = self.opt.param_groups[0]["lr"]
            if self.sched:
                self.sched.step()
            self.logger.log(epoch=ep, train_loss=round(train_loss, 4), val_loss=round(val_loss, 4),
                            val_acc=round(val_acc, 4), lr=lr, sec=round(time.time() - t0, 1))
            print(f"ep {ep:3d}  train {train_loss:.4f}  val {val_loss:.4f} acc {val_acc:.4f}")
            improved, stop = self.stopper.step(val_acc)
            if improved:
                self.save(best_path, ep)
            if stop:
                print(f"early stop at epoch {ep}, best {self.stopper.best:.4f}")
                break
        self.load(best_path)
        return self.stopper.best

    def report(self, test_dl, class_names):
        _, y, p = self.predict(test_dl)
        cm = confusion_matrix(y, p, len(class_names))
        np.savetxt(self.logger.dir / "confusion.csv", cm, fmt="%d", delimiter=",")
        per_class_report(cm, class_names)
        return cm

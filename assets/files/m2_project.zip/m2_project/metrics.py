# metrics.py — the project of module 2, chapter 12 (sections 12.2 and 10.2)
import numpy as np

def confusion_matrix(y_true, y_pred, k):
    cm = np.zeros((k, k), dtype=int)
    np.add.at(cm, (y_true, y_pred), 1)
    return cm

def per_class_report(cm, names):
    tp = np.diag(cm).astype(float)
    precision = tp / np.maximum(cm.sum(axis=0), 1)
    recall = tp / np.maximum(cm.sum(axis=1), 1)
    f1 = 2 * precision * recall / np.maximum(precision + recall, 1e-12)
    print(f"{'class':>8} {'prec':>6} {'rec':>6} {'f1':>6} {'n':>5}")
    for i, nm in enumerate(names):
        print(f"{nm:>8} {precision[i]:6.3f} {recall[i]:6.3f} {f1[i]:6.3f} {cm[i].sum():5d}")
    print(f"{'acc':>8} {tp.sum() / cm.sum():6.3f}   macro-f1 {f1.mean():.3f}")
    return precision, recall, f1


class EarlyStopping:
    def __init__(self, patience=5, min_delta=1e-4, mode="max"):
        self.patience, self.min_delta, self.mode = patience, min_delta, mode
        self.best, self.bad = None, 0

    def step(self, value):
        if self.best is None:
            improved = True
        elif self.mode == "max":
            improved = value > self.best + self.min_delta
        else:
            improved = value < self.best - self.min_delta
        if improved:
            self.best, self.bad = value, 0
        else:
            self.bad += 1
        return improved, self.bad >= self.patience


import json, csv, hashlib, time
from pathlib import Path

def run_hash(cfg):
    s = json.dumps(cfg, sort_keys=True)
    return hashlib.sha1(s.encode()).hexdigest()[:8]

class RunLogger:
    def __init__(self, root, cfg):
        self.dir = Path(root) / f"{time.strftime('%Y%m%d-%H%M%S')}_{run_hash(cfg)}"
        self.dir.mkdir(parents=True, exist_ok=True)
        (self.dir / "config.json").write_text(json.dumps(cfg, indent=2, sort_keys=True))
        self.rows = []

    def log(self, **metrics):
        self.rows.append(metrics)
        with open(self.dir / "metrics.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(self.rows[0].keys()))
            w.writeheader()
            w.writerows(self.rows)
